﻿USE [CD_RAW]
GO
DROP PROCEDURE IF EXISTS [dbo].[LOAD_RAW_TABLES]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[LOAD_RAW_TABLES]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[LOAD_RAW_TABLES] AS' 
END
GO


ALTER PROCEDURE [dbo].[LOAD_RAW_TABLES] 
	@Filein VARCHAR(500) ,
	@FormatFile VARCHAR(500),
	@TableName VARCHAR(150),
	@FirstRow VARCHAR(2),
	@RUNID NVARCHAR(100) = NULL
AS
BEGIN

	SET XACT_ABORT ON
	DECLARE @strSQL2 AS VARCHAR(1000),
		@LOGID_TBL INT,
		@LOGID_SP INT,
		@SP_TABLE_NAME_1 VARCHAR(50) = OBJECT_NAME(@@PROCID),
		@DBNAME_1 VARCHAR(50) = OBJECT_SCHEMA_NAME(@@PROCID),
		@CURRENTTIME DATETIME,
		@SCHEMANAME_1 VARCHAR(50)= DB_NAME(),
		@RUNID_V NVARCHAR(100) = 1

	IF @RUNID IS NOT NULL
		SET @RUNID_V = @RUNID
	SELECT @CURRENTTIME = GETDATE() --take end time of sp
	--START OF INSERT INTO SP
	EXECUTE [CD_ADMIN].[dbo].[INSERT_RUN_LOG] 
		@RUNID =@RUNID_V ,@DBNAME = @DBNAME_1  ,@SCHEMANAME = @SCHEMANAME_1 ,@OBJECTTYPE ='SP' ,@OBJECTNAME = @SP_TABLE_NAME_1,
		@STARTTIME =@CURRENTTIME ,@ENDTIME =null  ,@STATUS = 'In Progress' , @ROWS_AFFECTED = null, @ID = @LOGID_SP  OUTPUT

	IF CHARINDEX('_drops', @Filein) = 0
		BEGIN
			DECLARE @strSQL1 AS VARCHAR(1000) ='TRUNCATE TABLE ' + @TableName
			EXEC(@strSQL1)
		END


	IF ISNULL(@FormatFile,'')=''
		BEGIN
			SET @strSQL2   = 'BULK INSERT ' + @TableName + ' FROM ' +  QUOTENAME(@Filein) + 
			 'WITH (FIRSTROW = ' + @FirstRow + ', MAXERRORS = 1000,rowterminator=''\n'',fieldterminator='','')'
		END

	ELSE
		BEGIN
			SET @strSQL2  = 'BULK INSERT ' + @TableName + ' FROM ' +  QUOTENAME(@Filein) + 
			 ' WITH (FORMATFILE = ' + '''' + @FormatFile + '''' + ', FIRSTROW = ' + @FirstRow + ', MAXERRORS = 1000)' 
		END


	BEGIN TRAN RAW_LOAD
	BEGIN TRY
		EXEC(@strSQL2)
	COMMIT TRAN RAW_LOAD

	SELECT @CURRENTTIME = GETDATE()  --take end time of sp

	EXECUTE [CD_ADMIN].[dbo].[INSERT_RUN_LOG] 
    @LOGID = @LOGID_SP,@ENDTIME =@CURRENTTIME ,@STATUS = 'Completed' , @ROWS_AFFECTED = null, @ID = @LOGID_SP  OUTPUT
	--END OF INSERT INTO SP

	END TRY

	BEGIN CATCH
	DECLARE @allerrors AS VARCHAR(500)=(SELECT CONCAT(ERROR_MESSAGE(), CHAR(13),
		'Error Number: ',ERROR_NUMBER(),CHAR(13),
		'Error Severity: ',ERROR_SEVERITY(),CHAR(13),
		'Error State: ',ERROR_STATE(),CHAR(13),
		'Error Proc: ',ERROR_PROCEDURE(),CHAR(13),
		'Error Line: ',ERROR_LINE()));
	DECLARE @ErrorSeverity INT;
	SELECT @ErrorSeverity = ERROR_SEVERITY() 
	DECLARE @ErrorState INT; 
	SELECT @ErrorState = ERROR_STATE()
	RAISERROR(@allerrors, --Message Text,
			@ErrorSeverity, -- Severity,
			@ErrorState, --State,
			N'number', --First argument,
			5); --Second argument.
		ROLLBACK TRAN

	SELECT @CURRENTTIME = GETDATE()  --take start time of table
	EXECUTE [CD_ADMIN].[dbo].[INSERT_RUN_LOG] @LOGID = @LOGID_SP, @ENDTIME =@CURRENTTIME  ,@STATUS = 'Failed' ,@ROWS_AFFECTED = null, @ID = @LOGID_SP  OUTPUT

	END CATCH
END
GO
