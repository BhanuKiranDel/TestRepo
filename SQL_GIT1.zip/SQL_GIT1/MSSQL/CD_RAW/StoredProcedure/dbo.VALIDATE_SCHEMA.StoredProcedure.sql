﻿USE [CD_RAW]
GO
DROP PROCEDURE IF EXISTS [dbo].[VALIDATE_SCHEMA]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[VALIDATE_SCHEMA]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[VALIDATE_SCHEMA] AS' 
END
GO
ALTER PROCEDURE [dbo].[VALIDATE_SCHEMA] 

@OUTPUT_TABLE nvarchar(30)=NULL,
@COLUMN_NAME nvarchar(30)=NULL,
@COLUMN_LENGTH int=NULL,
--@IS_MENDATORY bit,
@RUNID NVARCHAR(100) = NULL 
--@OUTPUT_FEED_COLUMN nvarchar
AS
BEGIN
	SET XACT_ABORT ON
	DECLARE	@LOGID_TBL INT,
		@LOGID_SP INT,
		@SP_TABLE_NAME_1 VARCHAR(50) = OBJECT_NAME(@@PROCID),
		@DBNAME_1 VARCHAR(50) = OBJECT_SCHEMA_NAME(@@PROCID),
		@CURRENTTIME DATETIME,
		@SCHEMANAME_1 VARCHAR(50)= DB_NAME(),
		@RUNID_V NVARCHAR(100) = 1

	SET NOCOUNT ON;

	BEGIN TRANSACTION INS1;
	BEGIN TRY

	
	IF @RUNID IS NOT NULL
			SET @RUNID_V = @RUNID

	SELECT @CURRENTTIME = GETDATE() --take end time of sp
	--START OF INSERT INTO SP
	EXECUTE [CD_ADMIN].[dbo].[INSERT_RUN_LOG] 
		@RUNID =@RUNID_V ,@DBNAME = @DBNAME_1  ,@SCHEMANAME = @SCHEMANAME_1 ,@OBJECTTYPE ='SP' ,@OBJECTNAME = @SP_TABLE_NAME_1,
		@STARTTIME =@CURRENTTIME ,@ENDTIME =null  ,@STATUS = 'In Progress' , @ROWS_AFFECTED = null, @ID = @LOGID_SP  OUTPUT
		
DECLARE @PASS_CHECK bit='false' ;

IF EXISTS(select top 1 columnTable.name from sys.all_columns columnTable
join sys.tables systemTable on columnTable.object_id=systemTable.object_id
where systemTable.name=@OUTPUT_TABLE 
and columnTable.name=@COLUMN_NAME 
and columnTable.max_length>=@COLUMN_LENGTH)
Set @PASS_CHECK = 'true'
--and columnTable.is_nullable!=@IS_MENDATORY;

select @PASS_CHECK as COLUMN_EXISTS;

COMMIT TRANSACTION INS1
	SELECT @CURRENTTIME = GETDATE()  --take end time of sp

	EXECUTE [CD_ADMIN].[dbo].[INSERT_RUN_LOG] 
    @LOGID = @LOGID_SP,@ENDTIME =@CURRENTTIME ,@STATUS = 'Completed' , @ROWS_AFFECTED = null, @ID = @LOGID_SP  OUTPUT
	--END OF INSERT INTO SP
	END TRY

	BEGIN CATCH
	DECLARE @allerrors AS VARCHAR(500)=(SELECT CONCAT(ERROR_MESSAGE(), CHAR(13),
		'Error Number: ',ERROR_NUMBER(),CHAR(13),
		'Error Severity: ',ERROR_SEVERITY(),CHAR(13),
		'Error State: ',ERROR_STATE(),CHAR(13),
		'Error Proc: ',ERROR_PROCEDURE(),CHAR(13),
		'Error Line: ',ERROR_LINE()));
	DECLARE @ErrorSeverity INT;
	SELECT @ErrorSeverity = ERROR_SEVERITY() 
	DECLARE @ErrorState INT; 
	SELECT @ErrorState = ERROR_STATE()
	RAISERROR(@allerrors, --Message Text,
			@ErrorSeverity, -- Severity,
			@ErrorState, --State,
			N'number', --First argument,
			5); --Second argument.
		ROLLBACK TRANSACTION
	SELECT @CURRENTTIME = GETDATE()  --take start time of table
	EXECUTE [CD_ADMIN].[dbo].[INSERT_RUN_LOG] @LOGID = @LOGID_SP, @ENDTIME =@CURRENTTIME  ,@STATUS = 'Failed' ,@ROWS_AFFECTED = null, @ID = @LOGID_SP  OUTPUT
	--END OF INSERT INTO SP
	END CATCH

END;

GO
