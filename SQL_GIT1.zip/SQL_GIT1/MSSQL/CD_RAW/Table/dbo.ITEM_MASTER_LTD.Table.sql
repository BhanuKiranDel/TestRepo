﻿USE [CD_RAW]
GO
DROP TABLE IF EXISTS [dbo].[ITEM_MASTER_LTD]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ITEM_MASTER_LTD]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[ITEM_MASTER_LTD](
	[ITMNO] [varchar](50) NOT NULL,
	[COLORNO] [varchar](20) NULL,
	[COLOR] [varchar](50) NULL,
	[SIZENO] [varchar](20) NULL,
	[SIZE] [varchar](50) NULL,
	[DEPARTMENTNO] [varchar](20) NULL,
	[DEPARTMENT] [varchar](250) NULL,
	[CLASSNO] [varchar](20) NULL,
	[CLASS] [varchar](250) NULL,
	[COST] [varchar](20) NULL,
	[PRICE] [varchar](20) NULL,
	[DESCRIPTION] [varchar](250) NULL,
	[CHANGEDATE] [varchar](50) NULL,
	[FILENAME] [varchar](100) NULL,
	[SEQ] [varchar](100) NULL,
	[FILEDATE] [varchar](100) NULL,
	[INSERTDATE] [varchar](100) NULL
) ON [PRIMARY]
END
GO
