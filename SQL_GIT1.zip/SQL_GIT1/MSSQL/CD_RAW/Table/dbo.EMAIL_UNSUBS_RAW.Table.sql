﻿USE [CD_RAW]
GO
DROP TABLE IF EXISTS [dbo].[EMAIL_UNSUBS_RAW]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[EMAIL_UNSUBS_RAW]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[EMAIL_UNSUBS_RAW](
	[EMAILTYPE] [varchar](250) NULL,
	[INTSOURCE] [varchar](250) NULL,
	[EMAIL] [varchar](250) NOT NULL,
	[ACCTNO] [varchar](50) NULL,
	[INTDATE] [varchar](50) NOT NULL,
	[DNEFLAG] [varchar](10) NULL,
	[EMAILPREF] [varchar](10) NULL,
	[IPADDRESS] [varchar](25) NULL,
	[FILENAME] [varchar](100) NULL,
	[SEQ] [varchar](100) NULL,
	[FILEDATE] [varchar](100) NULL
) ON [PRIMARY]
END
GO
