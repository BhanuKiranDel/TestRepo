﻿USE [CD_RAW]
GO
DROP TABLE IF EXISTS [dbo].[CUSTOMERS_DAILY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CUSTOMERS_DAILY]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[CUSTOMERS_DAILY](
	[ACCTNO] [varchar](250) NULL,
	[FNAME] [varchar](250) NULL,
	[LNAME] [varchar](250) NULL,
	[ADD1] [varchar](250) NULL,
	[ADD2] [varchar](250) NULL,
	[CITY] [varchar](250) NULL,
	[STATE] [varchar](250) NULL,
	[ZIP] [varchar](250) NULL,
	[EMAIL] [varchar](250) NULL,
	[COUNTRY] [varchar](250) NULL,
	[PHONE] [varchar](250) NULL,
	[PRENAME] [varchar](50) NULL,
	[MNAME] [varchar](50) NULL,
	[SUFNAME] [varchar](50) NULL,
	[COMPANY] [varchar](250) NULL,
	[TITLE] [varchar](250) NULL,
	[BDAY] [varchar](257) NOT NULL
) ON [PRIMARY]
END
GO
