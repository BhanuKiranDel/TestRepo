﻿USE [CD_RAW]
GO
DROP TABLE IF EXISTS [dbo].[JOB_DURATION]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[JOB_DURATION]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[JOB_DURATION](
	[jobname] [varchar](50) NULL,
	[start_time] [datetime] NULL,
	[end_time] [datetime] NULL,
	[duration] [varchar](50) NULL,
	[run_id] [varchar](50) NULL,
	[run_date] [datetime] NULL
) ON [PRIMARY]
END
GO
