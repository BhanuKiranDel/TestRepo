﻿USE [CD_RAW]
GO
DROP TABLE IF EXISTS [dbo].[DIRECT_ITEMS_RAW_API]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DIRECT_ITEMS_RAW_API]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[DIRECT_ITEMS_RAW_API](
	[ACCTNO] [varchar](150) NULL,
	[COUNTRYFLG] [varchar](150) NULL,
	[CATALOG] [varchar](150) NULL,
	[ITMCHANNEL] [varchar](150) NULL,
	[DEPT] [varchar](150) NULL,
	[DEPTRFS] [varchar](150) NULL,
	[DSCNTCODE] [varchar](150) NULL,
	[DSCNTTYPE] [varchar](150) NULL,
	[INITIALDTE] [varchar](150) NULL,
	[ITEMNO] [varchar](150) NULL,
	[ITMDATE] [varchar](150) NULL,
	[LINENUM] [varchar](150) NULL,
	[ORDERTYPE] [varchar](150) NULL,
	[ITEMORDNO] [varchar](150) NULL,
	[ORIGLINENO] [varchar](150) NULL,
	[ORIGORDNO] [varchar](150) NULL,
	[ORIGSHIPTO] [varchar](150) NULL,
	[PAGENUM] [varchar](150) NULL,
	[DEMANDFLAG] [varchar](150) NULL,
	[RECORDTYPE] [varchar](150) NULL,
	[RETAILAMT] [varchar](150) NULL,
	[RETREASON] [varchar](150) NULL,
	[SEQNO] [varchar](150) NULL,
	[SIZE] [varchar](150) NULL,
	[COLOR] [varchar](150) NULL,
	[SKU] [varchar](150) NULL,
	[ITMSTORENO] [varchar](150) NULL,
	[ITMSUBCHAN] [varchar](150) NULL,
	[TRANSNO] [varchar](150) NULL,
	[TRANSTYPE] [varchar](150) NULL,
	[ITMALTLOC] [varchar](150) NULL,
	[MERCHCNCPT] [varchar](150) NULL,
	[RETURNNO] [varchar](150) NULL,
	[SOURCECODE] [varchar](150) NULL,
	[ORGPRICE] [varchar](150) NULL,
	[DISCNTAMT] [varchar](150) NULL,
	[FILENAME] [varchar](150) NULL,
	[SEQ] [varchar](150) NULL,
	[FILEDATE] [varchar](150) NULL
) ON [PRIMARY]
END
GO
