﻿USE [CD_RAW]
GO
DROP TABLE IF EXISTS [dbo].[RETAIL_ITEMS_DAILY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RETAIL_ITEMS_DAILY]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[RETAIL_ITEMS_DAILY](
	[ACCTNO] [varchar](150) NULL,
	[ITMORDNO] [varchar](64) NOT NULL,
	[ITMDATE] [varchar](50) NULL,
	[LINENUM] [varchar](150) NULL,
	[ITMNO] [varchar](150) NULL,
	[ITMQTY] [varchar](20) NULL,
	[ITMPRICE] [varchar](20) NULL,
	[ITMSOURCE] [varchar](150) NULL,
	[ITMDESC] [varchar](250) NULL,
	[ITMSTATUS] [varchar](250) NULL,
	[ITMCOST] [varchar](20) NULL,
	[ITMCANCEL] [varchar](20) NULL,
	[ITMRETURN] [varchar](20) NULL,
	[ITMRTNDATE] [varchar](20) NULL,
	[ITMDISCNT] [varchar](20) NULL,
	[ITMTAX] [varchar](20) NULL,
	[RETREASON] [varchar](150) NULL,
	[ITMCOUPON] [varchar](250) NULL,
	[ISTORENO] [varchar](250) NULL
) ON [PRIMARY]
END
GO
