﻿USE [CD_RAW]
GO
DROP TABLE IF EXISTS [dbo].[DIRECT_ORDERS_DAILY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DIRECT_ORDERS_DAILY]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[DIRECT_ORDERS_DAILY](
	[ACCTNO] [varchar](150) NULL,
	[ORDNO] [varchar](53) NOT NULL,
	[ORDDATE] [varchar](50) NULL,
	[ORDTDOL] [varchar](20) NULL,
	[ORDCHANNEL] [varchar](250) NULL,
	[EMAIL] [varchar](250) NULL,
	[PHONE] [varchar](25) NULL,
	[ORDITEMQTY] [varchar](20) NULL,
	[ORDSOURCE] [varchar](150) NULL,
	[ORDCOGS] [varchar](20) NULL,
	[ORDCANCEL] [varchar](20) NULL,
	[ORDRETURN] [varchar](20) NULL,
	[ORDDISCNT] [varchar](20) NULL,
	[ORDPOSTAGE] [varchar](20) NULL,
	[TAXAMT] [varchar](20) NULL,
	[STORENO] [varchar](150) NULL
) ON [PRIMARY]
END
GO
