﻿USE [CD_RAW]
GO
DROP TABLE IF EXISTS [dbo].[ACCTNUM_PINS_REF]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ACCTNUM_PINS_REF]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[ACCTNUM_PINS_REF](
	[HHID] [varchar](250) NULL,
	[INDID] [varchar](250) NULL,
	[ADDID] [varchar](250) NULL,
	[COMPID] [varchar](250) NULL,
	[ACCTNO] [varchar](50) NULL,
	[rownum] [bigint] NULL
) ON [PRIMARY]
END
GO
