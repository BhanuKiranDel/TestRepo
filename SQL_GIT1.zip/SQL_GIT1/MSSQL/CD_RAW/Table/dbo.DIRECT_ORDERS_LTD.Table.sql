﻿USE [CD_RAW]
GO
DROP TABLE IF EXISTS [dbo].[DIRECT_ORDERS_LTD]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DIRECT_ORDERS_LTD]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[DIRECT_ORDERS_LTD](
	[ACCTNO] [varchar](50) NULL,
	[ORDNO] [varchar](250) NULL,
	[ORDDATE] [varchar](50) NULL,
	[ORDTDOL] [varchar](30) NULL,
	[ORDCHANNEL] [varchar](250) NULL,
	[EMAIL] [varchar](250) NULL,
	[PHONE] [varchar](25) NULL,
	[ORDITEMQTY] [varchar](30) NULL,
	[ORDSOURCE] [varchar](250) NULL,
	[ORDCOGS] [varchar](30) NULL,
	[ORDCANCEL] [varchar](30) NULL,
	[ORDRETURN] [varchar](30) NULL,
	[ORDDISCNT] [varchar](30) NULL,
	[ORDPOSTAGE] [varchar](30) NULL,
	[TAXAMT] [varchar](30) NULL,
	[STORENO] [varchar](250) NULL,
	[FILENAME] [varchar](150) NULL,
	[SEQ] [varchar](150) NULL,
	[FILEDATE] [varchar](150) NULL,
	[INSERTDATE] [varchar](50) NULL
) ON [PRIMARY]
END
GO
