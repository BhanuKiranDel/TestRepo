﻿USE [CD_RAW]
GO
DROP TABLE IF EXISTS [dbo].[PROMO_DAILY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PROMO_DAILY]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[PROMO_DAILY](
	[ACCTNO] [varchar](50) NULL,
	[FNAME] [varchar](250) NULL,
	[LNAME] [varchar](250) NULL,
	[COMPANY] [varchar](250) NULL,
	[TITLE] [varchar](250) NULL,
	[ADD1] [varchar](250) NULL,
	[ADD2] [varchar](250) NULL,
	[CITY] [varchar](250) NULL,
	[STATE] [varchar](250) NULL,
	[ZIP] [varchar](25) NULL,
	[EMAIL] [varchar](250) NULL,
	[PHONE] [varchar](25) NULL,
	[DNMFLAG] [varchar](1) NOT NULL,
	[DNRFLAG] [varchar](1) NOT NULL,
	[DNCFLAG] [varchar](1) NOT NULL,
	[DNEFLAG] [varchar](1) NOT NULL,
	[MAILABLE] [varchar](1) NOT NULL,
	[EMAILFLAG] [varchar](1) NOT NULL,
	[BDAY] [varchar](25) NULL,
	[MAILDATE] [varchar](50) NULL,
	[INHOME] [varchar](50) NULL,
	[CIRCNAME] [nvarchar](4000) NOT NULL,
	[CIRCDESC] [nvarchar](4000) NOT NULL,
	[PROMTYPE] [varchar](3) NOT NULL,
	[MAILKEY] [nvarchar](4000) NOT NULL,
	[MKEYDESC] [varchar](1) NOT NULL,
	[DEMO] [varchar](15) NOT NULL,
	[LDATE] [varchar](50) NULL,
	[FREQ] [varchar](10) NULL,
	[TDOL] [varchar](10) NULL,
	[ADOL] [varchar](10) NULL
) ON [PRIMARY]
END
GO
