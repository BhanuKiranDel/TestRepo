﻿USE [CD_RAW]
GO
DROP TABLE IF EXISTS [dbo].[EMAIL_SENDS_LTD]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[EMAIL_SENDS_LTD]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[EMAIL_SENDS_LTD](
	[EMAILTYPE] [varchar](250) NULL,
	[INTSOURCE] [varchar](250) NULL,
	[EMAIL] [varchar](250) NULL,
	[ACCTNO] [varchar](50) NULL,
	[INTDATE] [varchar](50) NULL,
	[DNEFLAG] [varchar](10) NULL,
	[EMAILPREF] [varchar](20) NULL,
	[IPADDRESS] [varchar](25) NULL,
	[MESSAGEID] [varchar](40) NULL,
	[CAMPAIGNID] [varchar](40) NULL,
	[CAMPNAME] [varchar](250) NULL,
	[FILENAME] [varchar](150) NULL,
	[SEQ] [varchar](50) NULL,
	[FILEDATE] [varchar](50) NULL,
	[INSERTDATE] [varchar](50) NULL
) ON [PRIMARY]
END
GO
