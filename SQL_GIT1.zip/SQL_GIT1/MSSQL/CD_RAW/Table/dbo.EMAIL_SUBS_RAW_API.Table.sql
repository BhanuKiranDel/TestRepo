﻿USE [CD_RAW]
GO
DROP TABLE IF EXISTS [dbo].[EMAIL_SUBS_RAW_API]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[EMAIL_SUBS_RAW_API]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[EMAIL_SUBS_RAW_API](
	[EMAIL] [varchar](250) NULL,
	[DATE_SUB] [varchar](50) NULL,
	[RCODE] [varchar](50) NULL,
	[AFFILIATE_ID] [varchar](50) NULL,
	[EMAIL_CONTACT_PREFERENCE] [varchar](50) NULL,
	[EVENT_DATE] [varchar](50) NULL,
	[EXP_AD] [varchar](50) NULL,
	[FILENAME] [varchar](50) NULL,
	[SEQ] [varchar](50) NULL,
	[FILEDATE] [varchar](50) NULL
) ON [PRIMARY]
END
GO
