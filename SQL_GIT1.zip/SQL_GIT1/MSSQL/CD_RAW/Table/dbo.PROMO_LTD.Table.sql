﻿USE [CD_RAW]
GO
DROP INDEX IF EXISTS [idxCircname] ON [dbo].[PROMO_LTD]
GO
DROP TABLE IF EXISTS [dbo].[PROMO_LTD]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PROMO_LTD]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[PROMO_LTD](
	[FNAME] [varchar](150) NULL,
	[LNAME] [varchar](150) NULL,
	[ADD1] [varchar](150) NULL,
	[ADD2] [varchar](150) NULL,
	[CITY] [varchar](150) NULL,
	[STATE] [varchar](150) NULL,
	[ZIP] [varchar](150) NULL,
	[PLUS4] [varchar](150) NULL,
	[COMPANY] [varchar](150) NULL,
	[PRINUM] [varchar](150) NULL,
	[STREET] [varchar](150) NULL,
	[UNITNUM] [varchar](150) NULL,
	[FNAMEKEY] [varchar](150) NULL,
	[LNAMEKEY] [varchar](150) NULL,
	[COMPKEY] [varchar](150) NULL,
	[STREETKEY] [varchar](150) NULL,
	[EMAIL] [varchar](150) NULL,
	[PHONE] [varchar](150) NULL,
	[PIN] [varchar](150) NULL,
	[INDID] [varchar](150) NULL,
	[HHID] [varchar](150) NULL,
	[ADDID] [varchar](150) NULL,
	[COMPID] [varchar](150) NULL,
	[PINSOURCE] [varchar](150) NULL,
	[PINSEQ] [varchar](150) NULL,
	[ACCTNO] [varchar](150) NULL,
	[TITLE] [varchar](150) NULL,
	[DNMFLAG] [varchar](150) NULL,
	[DNRFLAG] [varchar](150) NULL,
	[DNCFLAG] [varchar](150) NULL,
	[DNEFLAG] [varchar](150) NULL,
	[MAILABLE] [varchar](150) NULL,
	[EMAILFLAG] [varchar](150) NULL,
	[BDAY] [varchar](150) NULL,
	[MAILDATE] [varchar](150) NULL,
	[INHOME] [varchar](150) NULL,
	[CIRCNAME] [varchar](150) NULL,
	[CIRCDESC] [varchar](150) NULL,
	[PROMTYPE] [varchar](150) NULL,
	[MAILKEY] [varchar](150) NULL,
	[MKEYDESC] [varchar](150) NULL,
	[DEMO] [varchar](150) NULL,
	[LDATE] [varchar](150) NULL,
	[FREQ] [varchar](150) NULL,
	[TDOL] [varchar](150) NULL,
	[ADOL] [varchar](150) NULL,
	[FILENAME] [varchar](150) NULL,
	[SEQ] [varchar](150) NULL,
	[FILEDATE] [varchar](150) NULL,
	[PRENAME] [varchar](150) NULL,
	[MNAME] [varchar](150) NULL,
	[FULLNAME] [varchar](150) NULL,
	[SUFNAME] [varchar](150) NULL,
	[GENDER] [varchar](150) NULL,
	[ADD3] [varchar](150) NULL,
	[DOMAIN] [varchar](150) NULL,
	[CVTDATE] [varchar](150) NULL,
	[ADSUFFIX] [varchar](150) NULL,
	[ADDTYPE] [varchar](150) NULL,
	[CRRT] [varchar](150) NULL,
	[CASSCODE] [varchar](150) NULL,
	[CKDIGIT] [varchar](150) NULL,
	[CNTRYCODE] [varchar](150) NULL,
	[CNTYCODE] [varchar](150) NULL,
	[CNTYNAME] [varchar](150) NULL,
	[DELPT] [varchar](150) NULL,
	[DPV] [varchar](150) NULL,
	[DPVFTNOTE] [varchar](150) NULL,
	[DPV_VACANT] [varchar](150) NULL,
	[LACSINDC] [varchar](150) NULL,
	[LOT] [varchar](150) NULL,
	[LOTORDER] [varchar](150) NULL,
	[DPVNOSTAT] [varchar](150) NULL,
	[POSDIR] [varchar](150) NULL,
	[PREDIR] [varchar](150) NULL,
	[UNITTYPE] [varchar](150) NULL,
	[INSERTDATE] [varchar](50) NULL
) ON [PRIMARY]
END
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[PROMO_LTD]') AND name = N'idxCircname')
CREATE NONCLUSTERED INDEX [idxCircname] ON [dbo].[PROMO_LTD]
(
	[CIRCNAME] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
