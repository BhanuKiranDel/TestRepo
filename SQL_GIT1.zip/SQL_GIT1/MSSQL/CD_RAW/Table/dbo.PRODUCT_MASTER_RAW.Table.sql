﻿USE [CD_RAW]
GO
DROP TABLE IF EXISTS [dbo].[PRODUCT_MASTER_RAW]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PRODUCT_MASTER_RAW]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[PRODUCT_MASTER_RAW](
	[SKU_NUMBER] [varchar](150) NULL,
	[DIVISION] [varchar](150) NULL,
	[DIV_DESC] [varchar](150) NULL,
	[DEPT_NUM] [varchar](150) NULL,
	[DEPT_DESC] [varchar](150) NULL,
	[CLASS] [varchar](150) NULL,
	[CLASS_DESC] [varchar](150) NULL,
	[ITEM_NUMBER] [varchar](150) NULL,
	[SKU_COLOR] [varchar](150) NULL,
	[SKU_COLOR_NUM_DESC] [varchar](150) NULL,
	[CAT_COLOR] [varchar](150) NULL,
	[CAT_COLOR_NUM_DESC] [varchar](150) NULL,
	[SKU_SIZE] [varchar](150) NULL,
	[SKU_SIZE_DESC] [varchar](150) NULL,
	[CAT_SIZE] [varchar](150) NULL,
	[ALPHA_SIZE] [varchar](150) NULL,
	[MERCH_SEASON] [varchar](150) NULL,
	[MERCH_SEASON_DESC] [varchar](150) NULL,
	[SUPER_SEASON] [varchar](150) NULL,
	[SUPER_SEASON_DESC] [varchar](150) NULL,
	[STYLE_NUMBER] [varchar](150) NULL,
	[STYLE_DESC] [varchar](150) NULL,
	[ITEM_CONCEPT] [varchar](150) NULL,
	[ITEM_CONCEPT_DESC] [varchar](150) NULL,
	[ITEM_TYPE] [varchar](150) NULL,
	[ITEM_TYPE_DESC] [varchar](150) NULL,
	[SKU_GROUP] [varchar](150) NULL,
	[SKU_GROUP_DESC] [varchar](150) NULL,
	[ITEM_SKU_NLA_CODE] [varchar](150) NULL,
	[ITEM_SKU_NLA_CODE_DESC] [varchar](150) NULL,
	[FIRST_COST] [varchar](150) NULL,
	[LANDED_COST] [varchar](150) NULL,
	[COST_DEFAULT_FLAG] [varchar](150) NULL,
	[MASTER_ITEM_NUM] [varchar](150) NULL,
	[MARKDOWN_FLAG] [varchar](150) NULL,
	[ITEM_FABRIC] [varchar](150) NULL,
	[ITEM_FABRIC_DESC] [varchar](150) NULL,
	[ITEM_LONG] [varchar](150) NULL,
	[ITEM_LONG_DESC] [varchar](150) NULL,
	[ITEM_SILHOUETTE] [varchar](150) NULL,
	[ITEM_SILHOUETTE_DESC] [varchar](150) NULL,
	[FILENAME] [varchar](150) NULL,
	[SEQ] [varchar](150) NULL,
	[FILEDATE] [varchar](150) NULL
) ON [PRIMARY]
END
GO
