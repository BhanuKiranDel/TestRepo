﻿USE [CD_RAW]
GO
DROP TABLE IF EXISTS [dbo].[EMAIL_BOUNCES_LTD]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[EMAIL_BOUNCES_LTD]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[EMAIL_BOUNCES_LTD](
	[EMAILTYPE] [varchar](100) NULL,
	[INTSOURCE] [varchar](100) NULL,
	[EMAIL] [varchar](100) NULL,
	[ACCTNO] [varchar](100) NULL,
	[INTDATE] [varchar](150) NULL,
	[DNEFLAG] [varchar](100) NULL,
	[EMAILPREF] [varchar](100) NULL,
	[IPADDRESS] [varchar](250) NULL,
	[FILENAME] [varchar](100) NULL,
	[SEQ] [varchar](100) NULL,
	[FILEDATE] [varchar](100) NULL,
	[INSERTDATE] [varchar](50) NULL
) ON [PRIMARY]
END
GO
