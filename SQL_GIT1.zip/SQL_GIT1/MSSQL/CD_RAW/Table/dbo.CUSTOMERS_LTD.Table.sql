﻿USE [CD_RAW]
GO
DROP TABLE IF EXISTS [dbo].[CUSTOMERS_LTD]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CUSTOMERS_LTD]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[CUSTOMERS_LTD](
	[FNAME] [varchar](250) NULL,
	[LNAME] [varchar](250) NULL,
	[ADD1] [varchar](250) NULL,
	[ADD2] [varchar](250) NULL,
	[CITY] [varchar](250) NULL,
	[STATE] [varchar](250) NULL,
	[ZIP] [varchar](25) NULL,
	[PLUS4] [varchar](250) NULL,
	[COMPANY] [varchar](250) NULL,
	[PRINUM] [varchar](250) NULL,
	[STREET] [varchar](250) NULL,
	[UNITNUM] [varchar](250) NULL,
	[FNAMEKEY] [varchar](250) NULL,
	[LNAMEKEY] [varchar](250) NULL,
	[COMPKEY] [varchar](250) NULL,
	[STREETKEY] [varchar](250) NULL,
	[EMAIL] [varchar](250) NULL,
	[PHONE] [varchar](25) NULL,
	[PIN] [varchar](250) NULL,
	[INDID] [varchar](250) NULL,
	[HHID] [varchar](250) NULL,
	[ADDID] [varchar](250) NULL,
	[COMPID] [varchar](250) NULL,
	[PINSOURCE] [varchar](250) NULL,
	[PINSEQ] [varchar](250) NULL,
	[ACCTNO] [varchar](50) NULL,
	[COUNTRY] [varchar](250) NULL,
	[PRENAME] [varchar](250) NULL,
	[MNAME] [varchar](250) NULL,
	[SUFNAME] [varchar](250) NULL,
	[TITLE] [varchar](250) NULL,
	[BDAY] [varchar](25) NULL,
	[FILENAME] [varchar](250) NULL,
	[SEQ] [varchar](250) NULL,
	[FILEDATE] [varchar](250) NULL,
	[FULLNAME] [varchar](250) NULL,
	[GENDER] [varchar](250) NULL,
	[ADD3] [varchar](250) NULL,
	[DOMAIN] [varchar](250) NULL,
	[CVTDATE] [varchar](250) NULL,
	[ADSUFFIX] [varchar](250) NULL,
	[ADDTYPE] [varchar](250) NULL,
	[CRRT] [varchar](250) NULL,
	[CASSCODE] [varchar](250) NULL,
	[CKDIGIT] [varchar](250) NULL,
	[CNTRYCODE] [varchar](250) NULL,
	[CNTYCODE] [varchar](250) NULL,
	[CNTYNAME] [varchar](250) NULL,
	[DELPT] [varchar](250) NULL,
	[DPV] [varchar](250) NULL,
	[DPVFTNOTE] [varchar](250) NULL,
	[DPV_VACANT] [varchar](250) NULL,
	[LACSINDC] [varchar](250) NULL,
	[LOT] [varchar](250) NULL,
	[LOTORDER] [varchar](250) NULL,
	[DPVNOSTAT] [varchar](250) NULL,
	[POSDIR] [varchar](250) NULL,
	[PREDIR] [varchar](250) NULL,
	[UNITTYPE] [varchar](250) NULL,
	[INSERTDATE] [varchar](50) NULL
) ON [PRIMARY]
END
GO
