﻿USE [CD_RAW]
GO
DROP TABLE IF EXISTS [dbo].[RETAIL_ITEMS_RAW]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RETAIL_ITEMS_RAW]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[RETAIL_ITEMS_RAW](
	[ACCTNO] [varchar](150) NULL,
	[ITMORDNO] [varchar](150) NULL,
	[LINENUM] [varchar](150) NULL,
	[ITMNO] [varchar](150) NULL,
	[ITMDATE] [varchar](50) NULL,
	[ITMQTY] [varchar](150) NULL,
	[ITMPRICE] [varchar](150) NULL,
	[ITMSOURCE] [varchar](150) NULL,
	[ITMDESC] [varchar](150) NULL,
	[ITMSTATUS] [varchar](150) NULL,
	[ITMCOST] [varchar](150) NULL,
	[ITMCANCEL] [varchar](150) NULL,
	[ITMRETURN] [varchar](150) NULL,
	[ITMRTNDATE] [varchar](150) NULL,
	[ITMDISCNT] [varchar](150) NULL,
	[ITMTAX] [varchar](150) NULL,
	[RETREASON] [varchar](150) NULL,
	[ITMCOUPON] [varchar](150) NULL,
	[ISTORENO] [varchar](150) NULL,
	[FILENAME] [varchar](150) NULL,
	[SEQ] [varchar](150) NULL,
	[FILEDATE] [varchar](150) NULL
) ON [PRIMARY]
END
GO
