﻿USE [CD_RAW]
GO
DROP TABLE IF EXISTS [dbo].[JOB_AUDIT_LOG1]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[JOB_AUDIT_LOG1]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[JOB_AUDIT_LOG1](
	[run_id] [varchar](50) NULL,
	[run_date] [datetime] NULL,
	[jobname] [varchar](50) NULL,
	[start_time] [datetime] NULL,
	[end_time] [datetime] NULL,
	[duration] [bigint] NULL
) ON [PRIMARY]
END
GO
