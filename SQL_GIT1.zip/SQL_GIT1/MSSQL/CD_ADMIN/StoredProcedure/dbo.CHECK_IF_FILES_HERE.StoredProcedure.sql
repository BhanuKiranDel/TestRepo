﻿USE [CD_ADMIN]
GO
DROP PROCEDURE IF EXISTS [dbo].[CHECK_IF_FILES_HERE]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CHECK_IF_FILES_HERE]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CHECK_IF_FILES_HERE] AS' 
END
GO

ALTER PROCEDURE [dbo].[CHECK_IF_FILES_HERE]
@filescount INT OUTPUT
AS
BEGIN

SET XACT_ABORT ON

BEGIN TRANSACTION INS1;
BEGIN TRY;

SELECT @filescount = COUNT(*)
	FROM [dbo].[MANIFEST]
	WHERE filedate = CAST(GETDATE() AS DATE)
	AND friendlyname IN
		(
		'DIRECT_ITEMS',
		'DIRECT_ORDERS',
		'EMAIL_BOUNCES',
		'EMAIL_CLICKS',
		'EMAIL_OPENS',
		'EMAIL_SENDS',
		'EMAIL_SUBS',
		'EMAIL_UNSUBS',
		'RETAIL_ITEMS',
		'RETAIL_ORDERS',
		'CUSTOMER'
		)
	AND STATUS='MERGED' AND INC_ROWINSERT>1
COMMIT TRANSACTION INS1

END TRY
BEGIN CATCH

DECLARE @allerrors AS VARCHAR(500)=(SELECT CONCAT(ERROR_MESSAGE(), CHAR(13),
	'Error Number: ',ERROR_NUMBER(),CHAR(13),
	'Error Severity: ',ERROR_SEVERITY(),CHAR(13),
	'Error State: ',ERROR_STATE(),CHAR(13),
	'Error Proc: ',ERROR_PROCEDURE(),CHAR(13),
	'Error Line: ',ERROR_LINE()));
DECLARE @ErrorSeverity INT;
SELECT @ErrorSeverity = ERROR_SEVERITY() 
DECLARE @ErrorState INT; 
SELECT @ErrorState = ERROR_STATE()
RAISERROR(@allerrors, --Message Text,
		@ErrorSeverity, -- Severity,
		@ErrorState, --State,
		N'number', --First argument,
		5); --Second argument.
	ROLLBACK TRANSACTION

END CATCH

END 





GO
