﻿USE [CD_ADMIN]
GO
DROP PROCEDURE IF EXISTS [dbo].[INSERT_RUN_LOG]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[INSERT_RUN_LOG]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[INSERT_RUN_LOG] AS' 
END
GO

-- =============================================
-- Author:		Parag Wankhade
-- Create date: 
-- Description:	Create log entry if new else update status and endtime based on the ID 
-- =============================================
ALTER  PROCEDURE [dbo].[INSERT_RUN_LOG]
	@LOGID int = NULL,
    @RUNID varchar(50) = NULL, 	
	@DBNAME varchar(20) = NULL,
	@SCHEMANAME varchar(20) = NULL,
	@OBJECTTYPE varchar(30) = NULL,
	@OBJECTNAME varchar(30) = NULL,
    @STARTTIME datetime = NULL,
    @ENDTIME datetime = NULL,
    @STATUS varchar(50),
    @ROWS_AFFECTED int = NULL,
	@ID int OUTPUT
AS
BEGIN
	SET XACT_ABORT ON
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	BEGIN TRANSACTION INS1;
	BEGIN TRY;

	IF NOT EXISTS(SELECT * FROM [dbo].[RUN_LOG] WHERE ID = @LOGID)
	BEGIN
		INSERT INTO [dbo].[RUN_LOG]
			([RUNID]
			,[TIMESTAMP]
			,[DBNAME]
			,[SCHEMANAME]
			,[OBJECTTYPE]
			,[OBJECTNAME]
			,[STARTTIME]
			,[ENDTIME]
			,[STATUS]
			,[ROWSAFFECTED])
		VALUES
			(@RUNID
			,GETDATE()
			,@DBNAME
			,@SCHEMANAME
			,@OBJECTTYPE
			,@OBJECTNAME
			,@STARTTIME
			,@ENDTIME
			,@STATUS
			,@ROWS_AFFECTED)

		SELECT TOP 1 @LOGID = ID FROM [dbo].[RUN_LOG]
		WHERE RUNID = @RUNID AND OBJECTNAME = @OBJECTNAME  AND STARTTIME= @STARTTIME
	END
	ELSE
		UPDATE [dbo].[RUN_LOG]
		SET	[ENDTIME] = @ENDTIME
			,[STATUS] = @STATUS
			,[ROWSAFFECTED] = @ROWS_AFFECTED
		WHERE ID = @LOGID

	SELECT @ID = @LOGID

	COMMIT TRANSACTION INS1
	END TRY

	BEGIN CATCH

	DECLARE @allerrors AS VARCHAR(500)=(SELECT CONCAT(ERROR_MESSAGE(), CHAR(13),
		'Error Number: ',ERROR_NUMBER(),CHAR(13),
		'Error Severity: ',ERROR_SEVERITY(),CHAR(13),
		'Error State: ',ERROR_STATE(),CHAR(13),
		'Error Proc: ',ERROR_PROCEDURE(),CHAR(13),
		'Error Line: ',ERROR_LINE()));
	DECLARE @ErrorSeverity INT;
	SELECT @ErrorSeverity = ERROR_SEVERITY() 
	DECLARE @ErrorState INT; 
	SELECT @ErrorState = ERROR_STATE()
	RAISERROR(@allerrors, --Message Text,
			@ErrorSeverity, -- Severity,
			@ErrorState, --State,
			N'number', --First argument,
			5); --Second argument.
		ROLLBACK TRANSACTION

	END CATCH
END
GO
