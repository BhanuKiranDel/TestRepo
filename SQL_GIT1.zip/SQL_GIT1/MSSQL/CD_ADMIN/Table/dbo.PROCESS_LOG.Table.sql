﻿USE [CD_ADMIN]
GO
DROP TABLE IF EXISTS [dbo].[PROCESS_LOG]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PROCESS_LOG]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[PROCESS_LOG](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[moment] [datetime] NULL,
	[runID] [varchar](50) NOT NULL,
	[connection_node] [bigint] NULL,
	[project] [varchar](50) NULL,
	[job] [varchar](255) NULL,
	[log_type] [varchar](100) NULL,
	[origin] [varchar](255) NULL,
	[priority] [int] NULL,
	[status] [varchar](255) NULL,
	[description] [varchar](max) NULL,
	[error_code] [int] NULL,
	[row_count] [int] NULL,
	[row_processed] [int] NULL,
	[row_rejected] [int] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
