﻿USE [CD_ADMIN]
GO
DROP TABLE IF EXISTS [dbo].[HIGH_DATES]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[HIGH_DATES]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[HIGH_DATES](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[RUN_DATE] [nvarchar](10) NOT NULL,
	[DB] [nvarchar](50) NULL,
	[TABLE_NAME] [nvarchar](50) NULL,
	[DATE_TYPE] [nvarchar](50) NULL,
	[HIGH_DATE] [nvarchar](10) NULL
) ON [PRIMARY]
END
GO
