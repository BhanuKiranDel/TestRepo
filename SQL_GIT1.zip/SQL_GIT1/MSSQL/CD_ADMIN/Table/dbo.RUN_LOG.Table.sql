﻿USE [CD_ADMIN]
GO
DROP TABLE IF EXISTS [dbo].[RUN_LOG]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RUN_LOG]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[RUN_LOG](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[RUNID] [varchar](50) NOT NULL,
	[TIMESTAMP] [datetime] NULL,
	[DBNAME] [varchar](20) NULL,
	[SCHEMANAME] [varchar](20) NULL,
	[OBJECTTYPE] [varchar](30) NOT NULL,
	[OBJECTNAME] [varchar](30) NOT NULL,
	[STARTTIME] [datetime] NOT NULL,
	[ENDTIME] [datetime] NULL,
	[STATUS] [varchar](20) NULL,
	[ROWSAFFECTED] [int] NULL
) ON [PRIMARY]
END
GO
