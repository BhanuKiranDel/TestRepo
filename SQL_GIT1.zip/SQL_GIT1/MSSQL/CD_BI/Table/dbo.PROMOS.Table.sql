﻿USE [CD_BI]
GO
DROP INDEX IF EXISTS [idxCircname] ON [dbo].[PROMOS]
GO
DROP TABLE IF EXISTS [dbo].[PROMOS]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PROMOS]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[PROMOS](
	[HHID] [varchar](50) NULL,
	[INDID] [varchar](50) NULL,
	[ADDID] [varchar](50) NULL,
	[COMPID] [varchar](50) NULL,
	[ACCTNO] [varchar](50) NULL,
	[PRENAME] [varchar](250) NULL,
	[FNAME] [varchar](250) NULL,
	[MNAME] [varchar](250) NULL,
	[LNAME] [varchar](250) NULL,
	[SUFNAME] [varchar](250) NULL,
	[COMPANY] [varchar](250) NULL,
	[TITLE] [varchar](250) NULL,
	[ADD1] [varchar](250) NULL,
	[ADD2] [varchar](250) NULL,
	[CITY] [varchar](250) NULL,
	[STATE] [varchar](250) NULL,
	[ZIP] [varchar](25) NULL,
	[PLUS4] [varchar](250) NULL,
	[DELPT] [varchar](10) NULL,
	[CKDIGIT] [varchar](10) NULL,
	[CRRT] [varchar](10) NULL,
	[CASSCODE] [varchar](10) NULL,
	[CNTRYCODE] [varchar](10) NULL,
	[CNTYCODE] [varchar](10) NULL,
	[CNTYNAME] [varchar](25) NULL,
	[DPV] [varchar](10) NULL,
	[DPVFTNOTE] [varchar](25) NULL,
	[DPV_VACANT] [varchar](25) NULL,
	[LACSINDC] [varchar](10) NULL,
	[LOT] [varchar](10) NULL,
	[LOTORDER] [varchar](10) NULL,
	[DPVNOSTAT] [varchar](25) NULL,
	[EMAIL] [varchar](250) NULL,
	[PHONE] [varchar](25) NULL,
	[DNMFLAG] [varchar](10) NULL,
	[DNRFLAG] [varchar](10) NULL,
	[DNCFLAG] [varchar](10) NULL,
	[DNEFLAG] [varchar](10) NULL,
	[MAILABLE] [varchar](10) NULL,
	[EMAILFLAG] [varchar](10) NULL,
	[GENDER] [varchar](25) NULL,
	[BDAY] [varchar](25) NULL,
	[MAILDATE] [datetime] NULL,
	[INHOME] [datetime] NULL,
	[CIRCNAME] [varchar](250) NULL,
	[CIRCDESC] [varchar](250) NULL,
	[PROMTYPE] [varchar](250) NULL,
	[MAILKEY] [varchar](250) NULL,
	[MKEYDESC] [varchar](250) NULL,
	[DEMO] [varchar](250) NULL,
	[LDATE] [datetime] NULL,
	[FREQ] [int] NULL,
	[TDOL] [money] NULL,
	[ADOL] [money] NULL
) ON [PRIMARY]
END
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[PROMOS]') AND name = N'idxCircname')
CREATE NONCLUSTERED INDEX [idxCircname] ON [dbo].[PROMOS]
(
	[CIRCNAME] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
