﻿USE [CD_BI]
GO
DROP TABLE IF EXISTS [dbo].[CUSTOMERS_HHID]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CUSTOMERS_HHID]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[CUSTOMERS_HHID](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[HHID] [varchar](250) NULL,
	[INDID] [varchar](250) NULL,
	[ADDID] [varchar](250) NULL,
	[COMPID] [varchar](250) NULL,
	[ACCTNO] [varchar](50) NULL,
	[STATE] [varchar](250) NULL,
	[ZIP] [varchar](25) NULL,
	[CNTRYCODE] [varchar](250) NULL,
	[EMAIL] [varchar](250) NULL,
	[PHONE] [varchar](25) NULL,
	[DNMFLAG] [varchar](1) NOT NULL,
	[DNRFLAG] [varchar](1) NOT NULL,
	[DNCFLAG] [varchar](1) NOT NULL,
	[DNEFLAG] [varchar](1) NOT NULL,
	[MAILABLE] [varchar](1) NOT NULL,
	[EMAILFLAG] [varchar](1) NOT NULL,
	[GENDER] [varchar](250) NULL,
	[BDAY] [varchar](25) NULL,
	[ODATE] [datetime] NULL,
	[LDATE] [datetime] NULL,
	[FREQ] [int] NULL,
	[TDOL] [money] NULL,
	[ADOL] [money] NULL,
	[LPCHANNEL] [varchar](25) NULL,
	[CPCHANNEL] [varchar](max) NULL,
	[RLDATE] [datetime] NULL,
	[RFREQ] [int] NULL,
	[RTDOL] [money] NULL,
	[RADOL] [money] NULL,
	[WLDATE] [datetime] NULL,
	[WFREQ] [int] NULL,
	[WTDOL] [money] NULL,
	[WADOL] [money] NULL,
	[PLDATE] [datetime] NULL,
	[PFREQ] [int] NULL,
	[PTDOL] [money] NULL,
	[PADOL] [money] NULL,
	[MONACT] [int] NULL,
	[FSTMCHNL] [varchar](25) NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
