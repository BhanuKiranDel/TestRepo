﻿USE [CD_BASE]
GO
DROP PROCEDURE IF EXISTS [dbo].[BUILD_CUSTOMERS]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BUILD_CUSTOMERS]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[BUILD_CUSTOMERS] AS' 
END
GO


ALTER PROCEDURE [dbo].[BUILD_CUSTOMERS] @RUNID NVARCHAR(100) = NULL
AS
BEGIN

--*****************************CHANGE_LOG*****************************
----------------------------------------------------------------------
--DATE			:	10/22/2019
--MODIFIED_BY	:	Ruchiagarwal3
--CHANGE		:	Updated Indexes, Added Catch Block
----------------------------------------------------------------------
--CREATED_DATE	:
--DESCRIPTION	:
----------------------------------------------------------------------

	SET XACT_ABORT ON 

	DECLARE @LOGID_TBL INT,
		@LOGID_SP INT,
		@SP_TABLE_NAME_1 VARCHAR(50) = OBJECT_NAME(@@PROCID),
		@DBNAME_1 VARCHAR(50) = OBJECT_SCHEMA_NAME(@@PROCID),
		@CURRENTTIME DATETIME,
		@SCHEMANAME_1 VARCHAR(50)= DB_NAME(),
		@RUNID_V NVARCHAR(100) = 1
	SET NOCOUNT ON;

	IF @RUNID IS NOT NULL
		SET @RUNID_V = @RUNID

	--START OF INSERT INTO SP
	SELECT @CURRENTTIME = GETDATE()

    EXECUTE [CD_ADMIN].[dbo].[INSERT_RUN_LOG] 
		@RUNID =@RUNID_V ,@DBNAME = @DBNAME_1  ,@SCHEMANAME = @SCHEMANAME_1 ,@OBJECTTYPE ='SP' ,@OBJECTNAME = @SP_TABLE_NAME_1,
		@STARTTIME =@CURRENTTIME ,@ENDTIME =null  ,@STATUS = 'In Progress' ,@ROWS_AFFECTED = '0', @ID = @LOGID_SP  OUTPUT;

	--IF OBJECT_ID('CD_BASE..CUSTOMERS') is not null
	--	BEGIN
	--		DROP TABLE CUSTOMERS
	--	END; 

	DECLARE @LASTDATE DATETIME  = (SELECT ISNULL(MAX(MODIFYDATE),'') FROM dbo.CUSTOMERS);

	BEGIN TRANSACTION INS1;
	BEGIN TRY

	IF NOT EXISTS  (SELECT *  FROM CD_BASE.sys.indexes  WHERE NAME='IX_NCI_HHID' 
    AND object_id = OBJECT_ID('CD_BASE.[dbo].[CUSTOMERS]'))
	BEGIN
		CREATE NONCLUSTERED INDEX [IX_NCI_HHID] ON CD_BASE.[dbo].[CUSTOMERS]
		(
			[HHID] ASC
		)
		WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
	END

	
	ALTER INDEX [IX_NCI_HHID] ON [dbo].[CUSTOMERS] DISABLE ;
	
	
	WITH customers_raw AS
	(
		SELECT [HHID]
			,[INDID]
			,[ADDID]
			,[COMPID]
			,[ACCTNO]
			,[PRENAME]
			,[FNAME]
			,[MNAME]
			,[LNAME]
			,[SUFNAME]
			,[COMPANY]
			,[TITLE]
			,[ADD1]
			,[ADD2]
			,[CITY]
			,[STATE]
			,[ZIP]
			,[COUNTRY]
			,[PLUS4]
			,[DELPT]
			,[CKDIGIT]
			,[CRRT]
			,[CASSCODE]
			,[CNTRYCODE]
			,[CNTYCODE]
			,[CNTYNAME]
			,[DPV]
			,[DPVFTNOTE]
			,[DPV_VACANT]
			,[LACSINDC]
			,[LOT]
			,[LOTORDER]
			,[DPVNOSTAT]
			,[EMAIL]
			,[PHONE]
			,[GENDER]
			,[BDAY]
			,[FILEDATE]
			,[INSERTDATE]
			,ROW_NUMBER() OVER (PARTITION BY [ACCTNO] ORDER BY CAST([FILEDATE] AS DATE) DESC, CAST([INSERTDATE] AS DATETIME) DESC, CAST([SEQ] AS INT) DESC) AS rownum
		FROM [CD_RAW].[dbo].[CUSTOMERS_LTD] WHERE CAST([INSERTDATE] AS DATETIME) > @LASTDATE
	),
	customers_deduped AS
	(
		SELECT *
		FROM customers_raw
		WHERE rownum = 1
	),
	customers_final AS
	(
		SELECT [HHID]
			,[INDID]
			,[ADDID]
			,[COMPID]
			,[ACCTNO]
			,[PRENAME]
			,[FNAME]
			,[MNAME]
			,[LNAME]
			,[SUFNAME]
			,[COMPANY]
			,[TITLE]
			,[ADD1]
			,[ADD2]
			,[CITY]
			,[STATE]
			,[ZIP]
			,[PLUS4]
			,[DELPT]
			,[CKDIGIT]
			,[CRRT]
			,[CASSCODE]
			,[COUNTRY]
			,[CNTRYCODE]
			,[CNTYCODE]
			,[CNTYNAME]
			,[DPV]
			,[DPVFTNOTE]
			,[DPV_VACANT]
			,[LACSINDC]
			,[LOT]
			,[LOTORDER]
			,[DPVNOSTAT]
			,[EMAIL]
			,[PHONE]
			,[GENDER]
			,[BDAY]
			,'' AS [DNMFLAG]
			,'' AS [DNRFLAG]
			,'' AS [DNCFLAG]
			,'' AS [DNEFLAG]
			,CASE WHEN [CASSCODE] LIKE 'E%'
				THEN 'N' ELSE 'Y' END AS [MAILABLE]
			,CASE WHEN [EMAIL] LIKE '%_@__%.__%' AND PATINDEX('%[^a-z,0-9,@,.,_,\-]%', LOWER([EMAIL])) = 0 
				THEN 'Y' ELSE 'N' END AS [EMAILFLAG]
			,'B' AS [CUSTTYPE]
			,[FILEDATE]
			,CAST([INSERTDATE] AS DATETIME) AS [MODIFYDATE]
		FROM customers_deduped
		WHERE CAST([INSERTDATE] AS DATETIME) >= @LASTDATE
	)
	--SELECT *
	--INTO [CD_BASE].[dbo].[CUSTOMERS]
	--FROM customers_final

	MERGE [CD_BASE].[dbo].[CUSTOMERS] t
    USING customers_final s
    ON s.ACCTNO = t.ACCTNO
    WHEN MATCHED AND s.MODIFYDATE > t.MODIFYDATE
    THEN UPDATE
    SET [HHID] = s.HHID
		,[INDID] = s.INDID
		,[ADDID] = s.ADDID
		,[COMPID] = s.COMPID
		,[ACCTNO] = s.ACCTNO
		,[PRENAME] = s.PRENAME
		,[FNAME] = s.FNAME
		,[MNAME] = s.MNAME
		,[LNAME] = s.LNAME
		,[SUFNAME] = s.SUFNAME
		,[COMPANY] = s.COMPANY
		,[TITLE] = s.TITLE
		,[ADD1] = s.ADD1
		,[ADD2] = s.ADD2
		,[CITY] = s.CITY
		,[STATE] = s.STATE
		,[ZIP] = s.ZIP
		,[PLUS4] = s.PLUS4
		,[DELPT] = s.DELPT
		,[CKDIGIT] = s.CKDIGIT
		,[CRRT] = s.CRRT
		,[CASSCODE] = s.CASSCODE
		,[COUNTRY] = s.COUNTRY
		,[CNTRYCODE] = s.CNTRYCODE
		,[CNTYCODE] = s.CNTYCODE
		,[CNTYNAME] = s.CNTYNAME
		,[DPV] = s.DPV
		,[DPVFTNOTE] = s.DPVFTNOTE
		,[DPV_VACANT] = s.DPV_VACANT
		,[LACSINDC] = s.LACSINDC
		,[LOT] = s.LOT
		,[LOTORDER] = s.LOTORDER
		,[DPVNOSTAT] = s.DPVNOSTAT
		,[EMAIL] = s.EMAIL
		,[PHONE] = s.PHONE
		,[GENDER] = s.GENDER
		,[BDAY] = s.BDAY
		,[DNMFLAG] = s.DNMFLAG
		,[DNRFLAG] = s.DNRFLAG
		,[DNCFLAG] = s.DNCFLAG
		,[DNEFLAG] = s.DNEFLAG
		,[MAILABLE] = s.MAILABLE
		,[EMAILFLAG] = s.EMAILFLAG
		,[CUSTTYPE] = s.CUSTTYPE
		,[FILEDATE] = s.FILEDATE
		,[MODIFYDATE] = s.MODIFYDATE
    WHEN NOT MATCHED
		THEN INSERT
			([HHID]
			,[INDID]
			,[ADDID]
			,[COMPID]
			,[ACCTNO]
			,[PRENAME]
			,[FNAME]
			,[MNAME]
			,[LNAME]
			,[SUFNAME]
			,[COMPANY]
			,[TITLE]
			,[ADD1]
			,[ADD2]
			,[CITY]
			,[STATE]
			,[ZIP]
			,[PLUS4]
			,[DELPT]
			,[CKDIGIT]
			,[CRRT]
			,[CASSCODE]
			,[COUNTRY]
			,[CNTRYCODE]
			,[CNTYCODE]
			,[CNTYNAME]
			,[DPV]
			,[DPVFTNOTE]
			,[DPV_VACANT]
			,[LACSINDC]
			,[LOT]
			,[LOTORDER]
			,[DPVNOSTAT]
			,[EMAIL]
			,[PHONE]
			,[GENDER]
			,[BDAY]
			,[DNMFLAG]
			,[DNRFLAG]
			,[DNCFLAG]
			,[DNEFLAG]
			,[MAILABLE]
			,[EMAILFLAG]
			,[CUSTTYPE]
			,[FILEDATE]
			,[MODIFYDATE])
		VALUES
			(s.HHID
			,s.INDID
			,s.ADDID
			,s.COMPID
			,s.ACCTNO
			,s.PRENAME
			,s.FNAME
			,s.MNAME
			,s.LNAME
			,s.SUFNAME
			,s.COMPANY
			,s.TITLE
			,s.ADD1
			,s.ADD2
			,s.CITY
			,s.STATE
			,s.ZIP
			,s.PLUS4
			,s.DELPT
			,s.CKDIGIT
			,s.CRRT
			,s.CASSCODE
			,s.COUNTRY
			,s.CNTRYCODE
			,s.CNTYCODE
			,s.CNTYNAME
			,s.DPV
			,s.DPVFTNOTE
			,s.DPV_VACANT
			,s.LACSINDC
			,s.LOT
			,s.LOTORDER
			,s.DPVNOSTAT
			,s.EMAIL
			,s.PHONE
			,s.GENDER
			,s.BDAY
			,s.DNMFLAG
			,s.DNRFLAG
			,s.DNCFLAG
			,s.DNEFLAG
			,s.MAILABLE
			,s.EMAILFLAG
			,s.CUSTTYPE
			,s.FILEDATE
			,s.MODIFYDATE);
			
	ALTER INDEX [IX_NCI_HHID] ON [dbo].[CUSTOMERS] REBUILD ;

	COMMIT TRANSACTION INS1;

	SELECT @CURRENTTIME = getdate()  --take start time of table
	
	EXECUTE [CD_ADMIN].[dbo].[INSERT_RUN_LOG] @LOGID = @LOGID_SP, @ENDTIME =@CURRENTTIME  ,@STATUS = 'Completed' ,@ROWS_AFFECTED = null, @ID = @LOGID_SP  OUTPUT
	--END OF INSERT INTO SP

	END TRY

	BEGIN CATCH  
	DECLARE @allerrors AS VARCHAR(500)=(SELECT CONCAT(ERROR_MESSAGE(), CHAR(13),
		'Error Number: ',ERROR_NUMBER(),CHAR(13),
		'Error Severity: ',ERROR_SEVERITY(),CHAR(13),
		'Error State: ',ERROR_STATE(),CHAR(13),
		'Error Proc: ',ERROR_PROCEDURE(),CHAR(13),
		'Error Line: ',ERROR_LINE()));
	DECLARE @ErrorSeverity INT;
	SELECT @ErrorSeverity = ERROR_SEVERITY() 
	DECLARE @ErrorState INT; 
	SELECT @ErrorState = ERROR_STATE()
	RAISERROR(@allerrors, --Message Text,
			@ErrorSeverity, -- Severity,
			@ErrorState, --State,
			N'number', --First argument,
			5); --Second argument.
		ROLLBACK TRANSACTION

	SELECT @CURRENTTIME = GETDATE()  --take start time of table
	
	EXECUTE [CD_ADMIN].[dbo].[INSERT_RUN_LOG] @LOGID = @LOGID_SP, @ENDTIME =@CURRENTTIME  ,@STATUS = 'Failed' ,@ROWS_AFFECTED = null, @ID = @LOGID_SP  OUTPUT
	--END OF INSERT INTO SP

	END CATCH  

END
GO
