﻿USE [CD_BASE]
GO
DROP PROCEDURE IF EXISTS [dbo].[BUILD_NON_BUYER_INTERACTIONS]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BUILD_NON_BUYER_INTERACTIONS]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[BUILD_NON_BUYER_INTERACTIONS] AS' 
END
GO


ALTER PROCEDURE [dbo].[BUILD_NON_BUYER_INTERACTIONS] @RUNID NVARCHAR(100) = NULL
AS
BEGIN
--*****************************CHANGE_LOG*****************************
----------------------------------------------------------------------
--DATE			:	10/22/2019
--MODIFIED_BY	:	Ruchiagarwal3
--CHANGE		:	Added Catch Block
----------------------------------------------------------------------
--CREATED_DATE	:
--DESCRIPTION	:
----------------------------------------------------------------------

	SET XACT_ABORT ON 

	DECLARE @LOGID_TBL INT,
		@LOGID_SP INT,
		@SP_TABLE_NAME_1 VARCHAR(50) = OBJECT_NAME(@@PROCID),
		@DBNAME_1 VARCHAR(50) = OBJECT_SCHEMA_NAME(@@PROCID),
		@CURRENTTIME DATETIME,
		@SCHEMANAME_1 VARCHAR(50)= DB_NAME(),
		@RUNID_V NVARCHAR(100) = 1
	SET NOCOUNT ON;
	
	IF @RUNID IS NOT NULL
		SET @RUNID_V = @RUNID

	--START OF INSERT INTO SP
	SELECT @CURRENTTIME = GETDATE()

    EXECUTE [CD_ADMIN].[dbo].[INSERT_RUN_LOG]
		@RUNID =@RUNID_V ,@DBNAME = @DBNAME_1  ,@SCHEMANAME = @SCHEMANAME_1 ,@OBJECTTYPE ='SP' ,@OBJECTNAME = @SP_TABLE_NAME_1,
		@STARTTIME =@CURRENTTIME ,@ENDTIME =null  ,@STATUS = 'In Progress' ,@ROWS_AFFECTED = '0', @ID = @LOGID_SP  OUTPUT

	
	DECLARE @LASTDATE DATETIME  = (SELECT ISNULL(MAX(MODIFYDATE),'') FROM dbo.NON_BUYER_INTERACTIONS)

	BEGIN TRANSACTION INS1
	BEGIN TRY

		INSERT INTO [dbo].[NON_BUYER_INTERACTIONS]
			([FNAME]
			,[LNAME]
			,[ADD1]
			,[ADD2]
			,[CITY]
			,[STATE]
			,[ZIP]
			,[EMAIL]
			,[PHONE]
			,[INTDATE]
			,[INTTYPE]
			,[ACCTNO]
			,[IPADDRESS]
			,[FILEDATE]
			,[MODIFYDATE])
		SELECT [FNAME]
			,[LNAME]
			,[ADD1]
			,[ADD2]
			,[CITY]
			,[STATE]
			,[ZIP]
/*			,[PLUS4]
			,[COMPANY]
			,[PRINUM]
			,[STREET]
			,[UNITNUM]
			,[FNAMEKEY]
			,[LNAMEKEY]
			,[COMPKEY]
			,[STREETKEY]*/
			,[EMAIL]
			,[PHONE]
/*			,[PIN]
			,[INDID]
			,[HHID]
			,[ADDID]
			,[COMPID]
			,[PINSOURCE]
			,[PINSEQ]*/
			,CONVERT(DATETIME,[INTDATE],120)
			,[INTTYPE]
			,[ACCTNO]
			,[IPADDRESS]
/*			,[FILENAME]
			,[SEQ]*/
			,[FILEDATE]
/*			,[PRENAME]
			,[MNAME]
			,[FULLNAME]
			,[SUFNAME]
			,[TITLE]
			,[GENDER]
			,[ADD3]
			,[DOMAIN]
			,[CVTDATE]
			,[ADSUFFIX]
			,[ADDTYPE]
			,[CRRT]
			,[CASSCODE]
			,[CKDIGIT]
			,[CNTRYCODE]
			,[CNTYCODE]
			,[CNTYNAME]
			,[DELPT]
			,[DPV]
			,[DPVFTNOTE]
			,[DPV_VACANT]
			,[LACSINDC]
			,[LOT]
			,[LOTORDER]
			,[DPVNOSTAT]
			,[POSDIR]
			,[PREDIR]
			,[UNITTYPE]*/
			,CONVERT(DATETIME,INSERTDATE,120)	  
		FROM CD_RAW.[dbo].[REQUESTORS_LTD]
		WHERE CONVERT(DATETIME,INSERTDATE,120) > @LASTDATE

		COMMIT TRANSACTION INS1

		SELECT @CURRENTTIME = getdate()  --take start time of table
	
		EXECUTE [CD_ADMIN].[dbo].[INSERT_RUN_LOG]@LOGID = @LOGID_SP, @ENDTIME =@CURRENTTIME  ,@STATUS = 'Completed' ,@ROWS_AFFECTED = null, @ID = @LOGID_SP  OUTPUT
		--END OF INSERT INTO SP

	END TRY 

  
	BEGIN CATCH  
	DECLARE @allerrors AS VARCHAR(500)=(SELECT CONCAT(ERROR_MESSAGE(), CHAR(13),
		'Error Number: ',ERROR_NUMBER(),CHAR(13),
		'Error Severity: ',ERROR_SEVERITY(),CHAR(13),
		'Error State: ',ERROR_STATE(),CHAR(13),
		'Error Proc: ',ERROR_PROCEDURE(),CHAR(13),
		'Error Line: ',ERROR_LINE()));
	DECLARE @ErrorSeverity INT;
	SELECT @ErrorSeverity = ERROR_SEVERITY() 
	DECLARE @ErrorState INT; 
	SELECT @ErrorState = ERROR_STATE()
	RAISERROR(@allerrors, --Message Text,
			@ErrorSeverity, -- Severity,
			@ErrorState, --State,
			N'number', --First argument,
			5); --Second argument.
		ROLLBACK TRANSACTION


	SELECT @CURRENTTIME = GETDATE()  --take start time of table
	
	EXECUTE [CD_ADMIN].[dbo].[INSERT_RUN_LOG]@LOGID = @LOGID_SP, @ENDTIME =@CURRENTTIME  ,@STATUS = 'Failed' ,@ROWS_AFFECTED = null, @ID = @LOGID_SP  OUTPUT
	--END OF INSERT INTO SP

	END CATCH  

END
GO
