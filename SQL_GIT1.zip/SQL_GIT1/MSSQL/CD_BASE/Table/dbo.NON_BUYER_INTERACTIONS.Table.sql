﻿USE [CD_BASE]
GO
DROP TABLE IF EXISTS [dbo].[NON_BUYER_INTERACTIONS]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[NON_BUYER_INTERACTIONS]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[NON_BUYER_INTERACTIONS](
	[FNAME] [varchar](250) NULL,
	[LNAME] [varchar](250) NULL,
	[ADD1] [varchar](250) NULL,
	[ADD2] [varchar](250) NULL,
	[CITY] [varchar](250) NULL,
	[STATE] [varchar](250) NULL,
	[ZIP] [varchar](25) NULL,
	[EMAIL] [varchar](250) NULL,
	[PHONE] [varchar](25) NULL,
	[INTDATE] [datetime] NULL,
	[INTTYPE] [varchar](250) NULL,
	[ACCTNO] [varchar](50) NULL,
	[IPADDRESS] [varchar](250) NULL,
	[FILEDATE] [varchar](30) NULL,
	[MODIFYDATE] [datetime] NULL
) ON [PRIMARY]
END
GO
