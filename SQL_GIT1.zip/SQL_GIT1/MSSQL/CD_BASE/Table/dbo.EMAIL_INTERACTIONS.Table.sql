﻿USE [CD_BASE]
GO
DROP TABLE IF EXISTS [dbo].[EMAIL_INTERACTIONS]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[EMAIL_INTERACTIONS]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[EMAIL_INTERACTIONS](
	[EMAILTYPE] [varchar](250) NULL,
	[INTSOURCE] [varchar](250) NULL,
	[EMAIL] [varchar](250) NULL,
	[ACCTNO] [varchar](50) NULL,
	[FNAME] [varchar](250) NULL,
	[LNAME] [varchar](250) NULL,
	[INTDATE] [datetime] NULL,
	[DNEFLAG] [varchar](10) NULL,
	[EMAILPREF] [varchar](10) NULL,
	[IPADDRESS] [varchar](25) NULL,
	[ASSETID] [varchar](50) NULL,
	[FILEDATE] [varchar](8) NULL,
	[MODIFYDATE] [datetime] NULL
) ON [PRIMARY]
END
GO
