﻿USE [CD_BASE]
GO
DROP TABLE IF EXISTS [dbo].[WEB_INTERACTIONS]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[WEB_INTERACTIONS]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[WEB_INTERACTIONS](
	[ACCTNO] [varchar](50) NULL,
	[INDID] [varchar](50) NULL,
	[HHID] [varchar](50) NULL,
	[ADDID] [varchar](50) NULL,
	[COMPID] [varchar](50) NULL,
	[ORDNO] [varchar](250) NULL,
	[ORDDATE] [datetime] NULL,
	[ORDFREQ] [int] NULL,
	[EMAIL] [varchar](250) NULL,
	[DEVICEID] [varchar](250) NULL,
	[SESSIONID] [varchar](250) NULL,
	[INTTYPE] [varchar](250) NULL,
	[INTDATE] [datetime] NULL,
	[INTSOURCE] [varchar](250) NULL,
	[INTDEVICE] [varchar](250) NULL,
	[VISITPAGE] [varchar](250) NULL,
	[VISITTIME] [varchar](25) NULL,
	[IPADDRESS] [varchar](25) NULL,
	[ASSETID] [varchar](50) NULL,
	[CAMPSOURCE] [varchar](250) NULL,
	[CAMPNAME] [varchar](250) NULL,
	[CAMPMEDIUM] [varchar](250) NULL,
	[REGION] [varchar](250) NULL,
	[REFERRER] [varchar](2000) NULL,
	[SOURCE_VISITOR_ID] [varchar](200) NULL,
	[FILEDATE] [varchar](25) NULL,
	[MODIFYDATE] [datetime] NULL
) ON [PRIMARY]
END
GO
