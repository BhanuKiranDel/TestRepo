﻿USE [CD_BI]
GO
DROP PROCEDURE IF EXISTS [dbo].[PROMO_BI]
GO
DROP PROCEDURE IF EXISTS [dbo].[EMAIL_PROMO_BI]
GO
DROP PROCEDURE IF EXISTS [dbo].[CUSTOMERS_INDID_BUILD_BI]
GO
DROP PROCEDURE IF EXISTS [dbo].[CUSTOMERS_HHID_BUILD_BI]
GO
DROP PROCEDURE IF EXISTS [dbo].[CreateTimelines]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CreateTimelines]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CreateTimelines] AS' 
END
GO
ALTER PROCEDURE [dbo].[CreateTimelines] @RUNID NVARCHAR(100) = NULL
AS
BEGIN
SET XACT_ABORT ON
DECLARE @LOGID_TBL int,
			@LOGID_SP int,
			@SP_TABLE_NAME_1 varchar(50) = OBJECT_NAME(@@PROCID),
			@DBNAME_1 varchar(50) = OBJECT_SCHEMA_NAME(@@PROCID),
			@CURRENTTIME DATETIME,
			@SCHEMANAME_1 varchar(50)= DB_NAME(),
			@RUNID_V NVARCHAR(100) = 1

	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	IF @RUNID IS NOT NULL
		SET @RUNID_V = @RUNID
	--START OF INSERT INTO SP
	SELECT @CURRENTTIME = getdate()

    EXECUTE [CD_ADMIN].[dbo].[INSERT_RUN_LOG] 
    @RUNID =@RUNID_V ,@DBNAME = @DBNAME_1  ,@SCHEMANAME = @SCHEMANAME_1 ,@OBJECTTYPE ='SP' ,@OBJECTNAME = @SP_TABLE_NAME_1
    ,@STARTTIME =@CURRENTTIME ,@ENDTIME =null  ,@STATUS = 'In Progress' ,@ROWS_AFFECTED = '0', @ID = @LOGID_SP  OUTPUT

	BEGIN TRANSACTION INS1;
	BEGIN TRY

    -- Clear temp tables - these should not persist across connections I don't think?
	DROP TABLE IF EXISTS #temp_table_email_universe;
	DROP TABLE IF EXISTS #temp_table_adobe_ids;
	DROP TABLE IF EXISTS #temp_table_indids;
	DROP TABLE IF EXISTS #temp_table_customers;
	DROP TABLE IF EXISTS #temp_table_orders;
	DROP TABLE IF EXISTS #temp_table_items;
	DROP TABLE IF EXISTS #temp_table_interactions;
	DROP TABLE IF EXISTS #temp_table_promotions;
	DROP TABLE IF EXISTS #temp_table_email_activities;
	DROP TABLE IF EXISTS #temp_table_email_promotions;
	DROP TABLE IF EXISTS #temp_table_adobe;
	DROP TABLE IF EXISTS #temp_table_events_except_customers;

	-- Just in case there's been a problem with a previous run, hopefully redundant.
	DROP TABLE IF EXISTS [CD_BI].[dbo].[TIMELINES_NEW];

	-- distinct email universe
	SELECT DISTINCT(customers.email) INTO #temp_table_email_universe
	FROM [CD_RAW].[dbo].[HIT_DATA_LTD] AS adobe_data 
	INNER JOIN [CD_BASE].[dbo].[CUSTOMERS_INDID] AS customers 
	ON adobe_data.[evar21] = customers.[email];


	-- distinct adobe id universe
	SELECT DISTINCT([mcvisid]) INTO #temp_table_adobe_ids
	FROM [CD_RAW].[dbo].[HIT_DATA_LTD] 
	WHERE [evar21] IN (SELECT [email] FROM #temp_table_email_universe);


	-- distinct indids
	SELECT DISTINCT([indid]) INTO #temp_table_indids
	FROM [CD_BASE].[dbo].[CUSTOMERS_INDID] 
	WHERE [email] IN (SELECT [email] FROM #temp_table_email_universe);


	-- selected customer data
	SELECT * INTO #temp_table_customers
	FROM [CD_BASE].[dbo].[CUSTOMERS_INDID]
	WHERE [indid] IN (SELECT [indid] FROM #temp_table_indids)
	OR [email] IN (SELECT [email] FROM #temp_table_email_universe);


	-- selected order data
	SELECT * INTO #temp_table_orders 
	FROM [CD_BASE].[dbo].[ORDERS]
	WHERE [indid] IN (SELECT [indid] FROM #temp_table_indids);


	-- selected item data
	SELECT * INTO #temp_table_items 
	FROM [CD_BASE].[dbo].[ITEMS]
	WHERE [indid] IN (SELECT [indid] FROM #temp_table_indids);


	-- selected interactions data
	SELECT * INTO #temp_table_interactions 
	FROM [CD_BASE].[dbo].[interactions]
	WHERE [indid] in (SELECT [indid] FROM #temp_table_indids)
	OR [email] IN (SELECT [email] FROM #temp_table_email_universe);

	
	-- selected promotions data
	SELECT * INTO #temp_table_promotions 
	FROM [CD_BASE].[dbo].[promotions]
	WHERE [indid] IN (SELECT [indid] FROM #temp_table_indids)
	OR [email] IN (SELECT  [email] FROM #temp_table_email_universe);


	-- selected email activities data
	SELECT * INTO #temp_table_email_activities 
	FROM [CD_BASE].[dbo].[email_activities]
	WHERE [email] IN (SELECT [email] FROM #temp_table_email_universe);


	-- selected email promotions data
	SELECT * INTO #temp_table_email_promotions 
	FROM [CD_BASE].[dbo].[email_promotions]
	WHERE [email] IN (SELECT [email] FROM #temp_table_email_universe);


	-- selected adobe data
	SELECT * INTO #temp_table_adobe 
	FROM [CD_RAW].[dbo].[HIT_DATA_LTD]
	WHERE [mcvisid] IN (SELECT [mcvisid] FROM #temp_table_adobe_ids);


	CREATE TABLE #temp_table_events_except_customers(
		[EVENT_TIME] [datetime] NULL,
		[EVENT_TYPE] [varchar](5000) NULL,
		[adobe_accept_language] [varchar](5000) NULL,
		[adobe_browser] [varchar](5000) NULL,
		[adobe_browser_height] [varchar](5000) NULL,
		[adobe_browser_width] [varchar](5000) NULL,
		[adobe_c_color] [varchar](5000) NULL,
		[adobe_campaign] [varchar](5000) NULL,
		[adobe_carrier] [varchar](5000) NULL,
		[adobe_channel] [varchar](5000) NULL,
		[adobe_click_action] [varchar](5000) NULL,
		[adobe_click_action_type] [varchar](5000) NULL,
		[adobe_click_context] [varchar](5000) NULL,
		[adobe_click_context_type] [varchar](5000) NULL,
		[adobe_click_sourceid] [varchar](5000) NULL,
		[adobe_click_tag] [varchar](5000) NULL,
		[adobe_code_ver] [varchar](5000) NULL,
		[adobe_color] [varchar](5000) NULL,
		[adobe_connection_type] [varchar](5000) NULL,
		[adobe_cookies] [varchar](5000) NULL,
		[adobe_country] [varchar](5000) NULL,
		[adobe_ct_connect_type] [varchar](5000) NULL,
		[adobe_curr_factor] [varchar](5000) NULL,
		[adobe_curr_rate] [varchar](5000) NULL,
		[adobe_currency] [varchar](5000) NULL,
		[adobe_cust_hit_time_gmt] [varchar](5000) NULL,
		[adobe_cust_visid] [varchar](5000) NULL,
		[adobe_daily_visitor] [varchar](5000) NULL,
		[adobe_date_time] [varchar](5000) NULL,
		[adobe_domain] [varchar](5000) NULL,
		[adobe_duplicate_events] [varchar](5000) NULL,
		[adobe_duplicate_purchase] [varchar](5000) NULL,
		[adobe_duplicated_from] [varchar](5000) NULL,
		[adobe_ef_id] [varchar](5000) NULL,
		[adobe_evar1] [varchar](5000) NULL,
		[adobe_evar2] [varchar](5000) NULL,
		[adobe_evar3] [varchar](5000) NULL,
		[adobe_evar4] [varchar](5000) NULL,
		[adobe_evar5] [varchar](5000) NULL,
		[adobe_evar6] [varchar](5000) NULL,
		[adobe_evar7] [varchar](5000) NULL,
		[adobe_evar8] [varchar](5000) NULL,
		[adobe_evar9] [varchar](5000) NULL,
		[adobe_evar10] [varchar](5000) NULL,
		[adobe_evar11] [varchar](5000) NULL,
		[adobe_evar12] [varchar](5000) NULL,
		[adobe_evar13] [varchar](5000) NULL,
		[adobe_evar14] [varchar](5000) NULL,
		[adobe_evar15] [varchar](5000) NULL,
		[adobe_evar16] [varchar](5000) NULL,
		[adobe_evar17] [varchar](5000) NULL,
		[adobe_evar18] [varchar](5000) NULL,
		[adobe_evar19] [varchar](5000) NULL,
		[adobe_evar20] [varchar](5000) NULL,
		[adobe_evar21] [varchar](5000) NULL,
		[adobe_evar22] [varchar](5000) NULL,
		[adobe_evar23] [varchar](5000) NULL,
		[adobe_evar24] [varchar](5000) NULL,
		[adobe_evar25] [varchar](5000) NULL,
		[adobe_evar26] [varchar](5000) NULL,
		[adobe_evar27] [varchar](5000) NULL,
		[adobe_evar28] [varchar](5000) NULL,
		[adobe_evar29] [varchar](5000) NULL,
		[adobe_evar30] [varchar](5000) NULL,
		[adobe_evar31] [varchar](5000) NULL,
		[adobe_evar32] [varchar](5000) NULL,
		[adobe_evar33] [varchar](5000) NULL,
		[adobe_evar34] [varchar](5000) NULL,
		[adobe_evar35] [varchar](5000) NULL,
		[adobe_evar36] [varchar](5000) NULL,
		[adobe_evar37] [varchar](5000) NULL,
		[adobe_evar38] [varchar](5000) NULL,
		[adobe_evar39] [varchar](5000) NULL,
		[adobe_evar40] [varchar](5000) NULL,
		[adobe_evar41] [varchar](5000) NULL,
		[adobe_evar42] [varchar](5000) NULL,
		[adobe_evar43] [varchar](5000) NULL,
		[adobe_evar44] [varchar](5000) NULL,
		[adobe_evar45] [varchar](5000) NULL,
		[adobe_evar46] [varchar](5000) NULL,
		[adobe_evar47] [varchar](5000) NULL,
		[adobe_evar48] [varchar](5000) NULL,
		[adobe_evar49] [varchar](5000) NULL,
		[adobe_evar50] [varchar](5000) NULL,
		[adobe_evar51] [varchar](5000) NULL,
		[adobe_evar52] [varchar](5000) NULL,
		[adobe_evar53] [varchar](5000) NULL,
		[adobe_evar54] [varchar](5000) NULL,
		[adobe_evar55] [varchar](5000) NULL,
		[adobe_evar56] [varchar](5000) NULL,
		[adobe_evar57] [varchar](5000) NULL,
		[adobe_evar58] [varchar](5000) NULL,
		[adobe_evar59] [varchar](5000) NULL,
		[adobe_evar60] [varchar](5000) NULL,
		[adobe_evar61] [varchar](5000) NULL,
		[adobe_evar62] [varchar](5000) NULL,
		[adobe_evar63] [varchar](5000) NULL,
		[adobe_evar64] [varchar](5000) NULL,
		[adobe_evar65] [varchar](5000) NULL,
		[adobe_evar66] [varchar](5000) NULL,
		[adobe_evar67] [varchar](5000) NULL,
		[adobe_evar68] [varchar](5000) NULL,
		[adobe_evar69] [varchar](5000) NULL,
		[adobe_evar70] [varchar](5000) NULL,
		[adobe_evar71] [varchar](5000) NULL,
		[adobe_evar72] [varchar](5000) NULL,
		[adobe_evar73] [varchar](5000) NULL,
		[adobe_evar74] [varchar](5000) NULL,
		[adobe_evar75] [varchar](5000) NULL,
		[adobe_evar76] [varchar](5000) NULL,
		[adobe_evar77] [varchar](5000) NULL,
		[adobe_evar78] [varchar](5000) NULL,
		[adobe_evar79] [varchar](5000) NULL,
		[adobe_evar80] [varchar](5000) NULL,
		[adobe_evar81] [varchar](5000) NULL,
		[adobe_evar82] [varchar](5000) NULL,
		[adobe_evar83] [varchar](5000) NULL,
		[adobe_evar84] [varchar](5000) NULL,
		[adobe_evar85] [varchar](5000) NULL,
		[adobe_evar86] [varchar](5000) NULL,
		[adobe_evar87] [varchar](5000) NULL,
		[adobe_evar88] [varchar](5000) NULL,
		[adobe_evar89] [varchar](5000) NULL,
		[adobe_evar90] [varchar](5000) NULL,
		[adobe_evar91] [varchar](5000) NULL,
		[adobe_evar92] [varchar](5000) NULL,
		[adobe_evar93] [varchar](5000) NULL,
		[adobe_evar94] [varchar](5000) NULL,
		[adobe_evar95] [varchar](5000) NULL,
		[adobe_evar96] [varchar](5000) NULL,
		[adobe_evar97] [varchar](5000) NULL,
		[adobe_evar98] [varchar](5000) NULL,
		[adobe_evar99] [varchar](5000) NULL,
		[adobe_evar100] [varchar](5000) NULL,
		[adobe_event_list] [varchar](5000) NULL,
		[adobe_exclude_hit] [varchar](5000) NULL,
		[adobe_first_hit_page_url] [varchar](5000) NULL,
		[adobe_first_hit_pagename] [varchar](5000) NULL,
		[adobe_first_hit_referrer] [varchar](5000) NULL,
		[adobe_first_hit_time_gmt] [varchar](5000) NULL,
		[adobe_geo_city] [varchar](5000) NULL,
		[adobe_geo_country] [varchar](5000) NULL,
		[adobe_geo_dma] [varchar](5000) NULL,
		[adobe_geo_region] [varchar](5000) NULL,
		[adobe_geo_zip] [varchar](5000) NULL,
		[adobe_hier1] [varchar](5000) NULL,
		[adobe_hier2] [varchar](5000) NULL,
		[adobe_hier3] [varchar](5000) NULL,
		[adobe_hier4] [varchar](5000) NULL,
		[adobe_hier5] [varchar](5000) NULL,
		[adobe_hit_source] [varchar](5000) NULL,
		[adobe_hit_time_gmt] [varchar](5000) NULL,
		[adobe_hitid_high] [varchar](5000) NULL,
		[adobe_hitid_low] [varchar](5000) NULL,
		[adobe_homepage] [varchar](5000) NULL,
		[adobe_hourly_visitor] [varchar](5000) NULL,
		[adobe_ip] [varchar](5000) NULL,
		[adobe_ip2] [varchar](5000) NULL,
		[adobe_j_jscript] [varchar](5000) NULL,
		[adobe_java_enabled] [varchar](5000) NULL,
		[adobe_javascript] [varchar](5000) NULL,
		[adobe_language] [varchar](5000) NULL,
		[adobe_last_hit_time_gmt] [varchar](5000) NULL,
		[adobe_last_purchase_num] [varchar](5000) NULL,
		[adobe_last_purchase_time_gmt] [varchar](5000) NULL,
		[adobe_mc_audiences] [varchar](5000) NULL,
		[adobe_mcvisid] [varchar](5000) NULL,
		[adobe_mobile_id] [varchar](5000) NULL,
		[adobe_mobileaction] [varchar](5000) NULL,
		[adobe_mobileappid] [varchar](5000) NULL,
		[adobe_mobilecampaigncontent] [varchar](5000) NULL,
		[adobe_mobilecampaignmedium] [varchar](5000) NULL,
		[adobe_mobilecampaignname] [varchar](5000) NULL,
		[adobe_mobilecampaignsource] [varchar](5000) NULL,
		[adobe_mobilecampaignterm] [varchar](5000) NULL,
		[adobe_mobiledayofweek] [varchar](5000) NULL,
		[adobe_mobiledayssincefirstuse] [varchar](5000) NULL,
		[adobe_mobiledayssincelastuse] [varchar](5000) NULL,
		[adobe_mobiledevice] [varchar](5000) NULL,
		[adobe_mobilehourofday] [varchar](5000) NULL,
		[adobe_mobileinstalldate] [varchar](5000) NULL,
		[adobe_mobilelaunchnumber] [varchar](5000) NULL,
		[adobe_mobileltv] [varchar](5000) NULL,
		[adobe_mobilemessageid] [varchar](5000) NULL,
		[adobe_mobilemessageonline] [varchar](5000) NULL,
		[adobe_mobileosversion] [varchar](5000) NULL,
		[adobe_mobilepushoptin] [varchar](5000) NULL,
		[adobe_mobilepushpayloadid] [varchar](5000) NULL,
		[adobe_mobileresolution] [varchar](5000) NULL,
		[adobe_monthly_visitor] [varchar](5000) NULL,
		[adobe_mvvar1] [varchar](5000) NULL,
		[adobe_mvvar2] [varchar](5000) NULL,
		[adobe_mvvar3] [varchar](5000) NULL,
		[adobe_namespace] [varchar](5000) NULL,
		[adobe_new_visit] [varchar](5000) NULL,
		[adobe_os] [varchar](5000) NULL,
		[adobe_p_plugins] [varchar](5000) NULL,
		[adobe_page_event] [varchar](5000) NULL,
		[adobe_page_event_var1] [varchar](5000) NULL,
		[adobe_page_event_var2] [varchar](5000) NULL,
		[adobe_page_event_var3] [varchar](5000) NULL,
		[adobe_page_type] [varchar](5000) NULL,
		[adobe_page_url] [varchar](5000) NULL,
		[adobe_pagename] [varchar](5000) NULL,
		[adobe_paid_search] [varchar](5000) NULL,
		[adobe_partner_plugins] [varchar](5000) NULL,
		[adobe_persistent_cookie] [varchar](5000) NULL,
		[adobe_plugins] [varchar](5000) NULL,
		[adobe_pointofinterest] [varchar](5000) NULL,
		[adobe_pointofinterestdistance] [varchar](5000) NULL,
		[adobe_post_browser_height] [varchar](5000) NULL,
		[adobe_post_browser_width] [varchar](5000) NULL,
		[adobe_post_campaign] [varchar](5000) NULL,
		[adobe_post_channel] [varchar](5000) NULL,
		[adobe_post_cookies] [varchar](5000) NULL,
		[adobe_post_currency] [varchar](5000) NULL,
		[adobe_post_cust_hit_time_gmt] [varchar](5000) NULL,
		[adobe_post_cust_visid] [varchar](5000) NULL,
		[adobe_post_ef_id] [varchar](5000) NULL,
		[adobe_post_evar1] [varchar](5000) NULL,
		[adobe_post_evar2] [varchar](5000) NULL,
		[adobe_post_evar3] [varchar](5000) NULL,
		[adobe_post_evar4] [varchar](5000) NULL,
		[adobe_post_evar5] [varchar](5000) NULL,
		[adobe_post_evar6] [varchar](5000) NULL,
		[adobe_post_evar7] [varchar](5000) NULL,
		[adobe_post_evar8] [varchar](5000) NULL,
		[adobe_post_evar9] [varchar](5000) NULL,
		[adobe_post_evar10] [varchar](5000) NULL,
		[adobe_post_evar11] [varchar](5000) NULL,
		[adobe_post_evar12] [varchar](5000) NULL,
		[adobe_post_evar13] [varchar](5000) NULL,
		[adobe_post_evar14] [varchar](5000) NULL,
		[adobe_post_evar15] [varchar](5000) NULL,
		[adobe_post_evar16] [varchar](5000) NULL,
		[adobe_post_evar17] [varchar](5000) NULL,
		[adobe_post_evar18] [varchar](5000) NULL,
		[adobe_post_evar19] [varchar](5000) NULL,
		[adobe_post_evar20] [varchar](5000) NULL,
		[adobe_post_evar21] [varchar](5000) NULL,
		[adobe_post_evar22] [varchar](5000) NULL,
		[adobe_post_evar23] [varchar](5000) NULL,
		[adobe_post_evar24] [varchar](5000) NULL,
		[adobe_post_evar25] [varchar](5000) NULL,
		[adobe_post_evar26] [varchar](5000) NULL,
		[adobe_post_evar27] [varchar](5000) NULL,
		[adobe_post_evar28] [varchar](5000) NULL,
		[adobe_post_evar29] [varchar](5000) NULL,
		[adobe_post_evar30] [varchar](5000) NULL,
		[adobe_post_evar31] [varchar](5000) NULL,
		[adobe_post_evar32] [varchar](5000) NULL,
		[adobe_post_evar33] [varchar](5000) NULL,
		[adobe_post_evar34] [varchar](5000) NULL,
		[adobe_post_evar35] [varchar](5000) NULL,
		[adobe_post_evar36] [varchar](5000) NULL,
		[adobe_post_evar37] [varchar](5000) NULL,
		[adobe_post_evar38] [varchar](5000) NULL,
		[adobe_post_evar39] [varchar](5000) NULL,
		[adobe_post_evar40] [varchar](5000) NULL,
		[adobe_post_evar41] [varchar](5000) NULL,
		[adobe_post_evar42] [varchar](5000) NULL,
		[adobe_post_evar43] [varchar](5000) NULL,
		[adobe_post_evar44] [varchar](5000) NULL,
		[adobe_post_evar45] [varchar](5000) NULL,
		[adobe_post_evar46] [varchar](5000) NULL,
		[adobe_post_evar47] [varchar](5000) NULL,
		[adobe_post_evar48] [varchar](5000) NULL,
		[adobe_post_evar49] [varchar](5000) NULL,
		[adobe_post_evar50] [varchar](5000) NULL,
		[adobe_post_evar51] [varchar](5000) NULL,
		[adobe_post_evar52] [varchar](5000) NULL,
		[adobe_post_evar53] [varchar](5000) NULL,
		[adobe_post_evar54] [varchar](5000) NULL,
		[adobe_post_evar55] [varchar](5000) NULL,
		[adobe_post_evar56] [varchar](5000) NULL,
		[adobe_post_evar57] [varchar](5000) NULL,
		[adobe_post_evar58] [varchar](5000) NULL,
		[adobe_post_evar59] [varchar](5000) NULL,
		[adobe_post_evar60] [varchar](5000) NULL,
		[adobe_post_evar61] [varchar](5000) NULL,
		[adobe_post_evar62] [varchar](5000) NULL,
		[adobe_post_evar63] [varchar](5000) NULL,
		[adobe_post_evar64] [varchar](5000) NULL,
		[adobe_post_evar65] [varchar](5000) NULL,
		[adobe_post_evar66] [varchar](5000) NULL,
		[adobe_post_evar67] [varchar](5000) NULL,
		[adobe_post_evar68] [varchar](5000) NULL,
		[adobe_post_evar69] [varchar](5000) NULL,
		[adobe_post_evar70] [varchar](5000) NULL,
		[adobe_post_evar71] [varchar](5000) NULL,
		[adobe_post_evar72] [varchar](5000) NULL,
		[adobe_post_evar73] [varchar](5000) NULL,
		[adobe_post_evar74] [varchar](5000) NULL,
		[adobe_post_evar75] [varchar](5000) NULL,
		[adobe_post_evar76] [varchar](5000) NULL,
		[adobe_post_evar77] [varchar](5000) NULL,
		[adobe_post_evar78] [varchar](5000) NULL,
		[adobe_post_evar79] [varchar](5000) NULL,
		[adobe_post_evar80] [varchar](5000) NULL,
		[adobe_post_evar81] [varchar](5000) NULL,
		[adobe_post_evar82] [varchar](5000) NULL,
		[adobe_post_evar83] [varchar](5000) NULL,
		[adobe_post_evar84] [varchar](5000) NULL,
		[adobe_post_evar85] [varchar](5000) NULL,
		[adobe_post_evar86] [varchar](5000) NULL,
		[adobe_post_evar87] [varchar](5000) NULL,
		[adobe_post_evar88] [varchar](5000) NULL,
		[adobe_post_evar89] [varchar](5000) NULL,
		[adobe_post_evar90] [varchar](5000) NULL,
		[adobe_post_evar91] [varchar](5000) NULL,
		[adobe_post_evar92] [varchar](5000) NULL,
		[adobe_post_evar93] [varchar](5000) NULL,
		[adobe_post_evar94] [varchar](5000) NULL,
		[adobe_post_evar95] [varchar](5000) NULL,
		[adobe_post_evar96] [varchar](5000) NULL,
		[adobe_post_evar97] [varchar](5000) NULL,
		[adobe_post_evar98] [varchar](5000) NULL,
		[adobe_post_evar99] [varchar](5000) NULL,
		[adobe_post_evar100] [varchar](5000) NULL,
		[adobe_post_event_list] [varchar](5000) NULL,
		[adobe_post_hier1] [varchar](5000) NULL,
		[adobe_post_hier2] [varchar](5000) NULL,
		[adobe_post_hier3] [varchar](5000) NULL,
		[adobe_post_hier4] [varchar](5000) NULL,
		[adobe_post_hier5] [varchar](5000) NULL,
		[adobe_post_java_enabled] [varchar](5000) NULL,
		[adobe_post_keywords] [varchar](5000) NULL,
		[adobe_post_mc_audiences] [varchar](5000) NULL,
		[adobe_post_mobileaction] [varchar](5000) NULL,
		[adobe_post_mobileappid] [varchar](5000) NULL,
		[adobe_post_mobilecampaigncontent] [varchar](5000) NULL,
		[adobe_post_mobilecampaignmedium] [varchar](5000) NULL,
		[adobe_post_mobilecampaignname] [varchar](5000) NULL,
		[adobe_post_mobilecampaignsource] [varchar](5000) NULL,
		[adobe_post_mobilecampaignterm] [varchar](5000) NULL,
		[adobe_post_mobiledayofweek] [varchar](5000) NULL,
		[adobe_post_mobiledayssincefirstuse] [varchar](5000) NULL,
		[adobe_post_mobiledayssincelastuse] [varchar](5000) NULL,
		[adobe_post_mobiledevice] [varchar](5000) NULL,
		[adobe_post_mobilehourofday] [varchar](5000) NULL,
		[adobe_post_mobileinstalldate] [varchar](5000) NULL,
		[adobe_post_mobilelaunchnumber] [varchar](5000) NULL,
		[adobe_post_mobileltv] [varchar](5000) NULL,
		[adobe_post_mobilemessageid] [varchar](5000) NULL,
		[adobe_post_mobilemessageonline] [varchar](5000) NULL,
		[adobe_post_mobileosversion] [varchar](5000) NULL,
		[adobe_post_mobilepushoptin] [varchar](5000) NULL,
		[adobe_post_mobilepushpayloadid] [varchar](5000) NULL,
		[adobe_post_mobileresolution] [varchar](5000) NULL,
		[adobe_post_mvvar1] [varchar](5000) NULL,
		[adobe_post_mvvar2] [varchar](5000) NULL,
		[adobe_post_mvvar3] [varchar](5000) NULL,
		[adobe_post_page_event] [varchar](5000) NULL,
		[adobe_post_page_event_var1] [varchar](5000) NULL,
		[adobe_post_page_event_var2] [varchar](5000) NULL,
		[adobe_post_page_event_var3] [varchar](5000) NULL,
		[adobe_post_page_type] [varchar](5000) NULL,
		[adobe_post_page_url] [varchar](5000) NULL,
		[adobe_post_pagename] [varchar](5000) NULL,
		[adobe_post_pagename_no_url] [varchar](5000) NULL,
		[adobe_post_partner_plugins] [varchar](5000) NULL,
		[adobe_post_persistent_cookie] [varchar](5000) NULL,
		[adobe_post_pointofinterest] [varchar](5000) NULL,
		[adobe_post_pointofinterestdistance] [varchar](5000) NULL,
		[adobe_post_product_list] [varchar](5000) NULL,
		[adobe_post_prop1] [varchar](5000) NULL,
		[adobe_post_prop2] [varchar](5000) NULL,
		[adobe_post_prop3] [varchar](5000) NULL,
		[adobe_post_prop4] [varchar](5000) NULL,
		[adobe_post_prop5] [varchar](5000) NULL,
		[adobe_post_prop6] [varchar](5000) NULL,
		[adobe_post_prop7] [varchar](5000) NULL,
		[adobe_post_prop8] [varchar](5000) NULL,
		[adobe_post_prop9] [varchar](5000) NULL,
		[adobe_post_prop10] [varchar](5000) NULL,
		[adobe_post_prop11] [varchar](5000) NULL,
		[adobe_post_prop12] [varchar](5000) NULL,
		[adobe_post_prop13] [varchar](5000) NULL,
		[adobe_post_prop14] [varchar](5000) NULL,
		[adobe_post_prop15] [varchar](5000) NULL,
		[adobe_post_prop16] [varchar](5000) NULL,
		[adobe_post_prop17] [varchar](5000) NULL,
		[adobe_post_prop18] [varchar](5000) NULL,
		[adobe_post_prop19] [varchar](5000) NULL,
		[adobe_post_prop20] [varchar](5000) NULL,
		[adobe_post_prop21] [varchar](5000) NULL,
		[adobe_post_prop22] [varchar](5000) NULL,
		[adobe_post_prop23] [varchar](5000) NULL,
		[adobe_post_prop24] [varchar](5000) NULL,
		[adobe_post_prop25] [varchar](5000) NULL,
		[adobe_post_prop26] [varchar](5000) NULL,
		[adobe_post_prop27] [varchar](5000) NULL,
		[adobe_post_prop28] [varchar](5000) NULL,
		[adobe_post_prop29] [varchar](5000) NULL,
		[adobe_post_prop30] [varchar](5000) NULL,
		[adobe_post_prop31] [varchar](5000) NULL,
		[adobe_post_prop32] [varchar](5000) NULL,
		[adobe_post_prop33] [varchar](5000) NULL,
		[adobe_post_prop34] [varchar](5000) NULL,
		[adobe_post_prop35] [varchar](5000) NULL,
		[adobe_post_prop36] [varchar](5000) NULL,
		[adobe_post_prop37] [varchar](5000) NULL,
		[adobe_post_prop38] [varchar](5000) NULL,
		[adobe_post_prop39] [varchar](5000) NULL,
		[adobe_post_prop40] [varchar](5000) NULL,
		[adobe_post_prop41] [varchar](5000) NULL,
		[adobe_post_prop42] [varchar](5000) NULL,
		[adobe_post_prop43] [varchar](5000) NULL,
		[adobe_post_prop44] [varchar](5000) NULL,
		[adobe_post_prop45] [varchar](5000) NULL,
		[adobe_post_prop46] [varchar](5000) NULL,
		[adobe_post_prop47] [varchar](5000) NULL,
		[adobe_post_prop48] [varchar](5000) NULL,
		[adobe_post_prop49] [varchar](5000) NULL,
		[adobe_post_prop50] [varchar](5000) NULL,
		[adobe_post_prop51] [varchar](5000) NULL,
		[adobe_post_prop52] [varchar](5000) NULL,
		[adobe_post_prop53] [varchar](5000) NULL,
		[adobe_post_prop54] [varchar](5000) NULL,
		[adobe_post_prop55] [varchar](5000) NULL,
		[adobe_post_prop56] [varchar](5000) NULL,
		[adobe_post_prop57] [varchar](5000) NULL,
		[adobe_post_prop58] [varchar](5000) NULL,
		[adobe_post_prop59] [varchar](5000) NULL,
		[adobe_post_prop60] [varchar](5000) NULL,
		[adobe_post_prop61] [varchar](5000) NULL,
		[adobe_post_prop62] [varchar](5000) NULL,
		[adobe_post_prop63] [varchar](5000) NULL,
		[adobe_post_prop64] [varchar](5000) NULL,
		[adobe_post_prop65] [varchar](5000) NULL,
		[adobe_post_prop66] [varchar](5000) NULL,
		[adobe_post_prop67] [varchar](5000) NULL,
		[adobe_post_prop68] [varchar](5000) NULL,
		[adobe_post_prop69] [varchar](5000) NULL,
		[adobe_post_prop70] [varchar](5000) NULL,
		[adobe_post_prop71] [varchar](5000) NULL,
		[adobe_post_prop72] [varchar](5000) NULL,
		[adobe_post_prop73] [varchar](5000) NULL,
		[adobe_post_prop74] [varchar](5000) NULL,
		[adobe_post_prop75] [varchar](5000) NULL,
		[adobe_post_purchaseid] [varchar](5000) NULL,
		[adobe_post_referrer] [varchar](5000) NULL,
		[adobe_post_s_kwcid] [varchar](5000) NULL,
		[adobe_post_search_engine] [varchar](5000) NULL,
		[adobe_post_socialaccountandappids] [varchar](5000) NULL,
		[adobe_post_socialassettrackingcode] [varchar](5000) NULL,
		[adobe_post_socialauthor] [varchar](5000) NULL,
		[adobe_post_socialcontentprovider] [varchar](5000) NULL,
		[adobe_post_socialfbstories] [varchar](5000) NULL,
		[adobe_post_socialfbstorytellers] [varchar](5000) NULL,
		[adobe_post_socialinteractioncount] [varchar](5000) NULL,
		[adobe_post_socialinteractiontype] [varchar](5000) NULL,
		[adobe_post_sociallanguage] [varchar](5000) NULL,
		[adobe_post_sociallatlong] [varchar](5000) NULL,
		[adobe_post_sociallikeadds] [varchar](5000) NULL,
		[adobe_post_socialmentions] [varchar](5000) NULL,
		[adobe_post_socialowneddefinitioninsighttype] [varchar](5000) NULL,
		[adobe_post_socialowneddefinitioninsightvalue] [varchar](5000) NULL,
		[adobe_post_socialowneddefinitionmetric] [varchar](5000) NULL,
		[adobe_post_socialowneddefinitionpropertyvspost] [varchar](5000) NULL,
		[adobe_post_socialownedpostids] [varchar](5000) NULL,
		[adobe_post_socialownedpropertyid] [varchar](5000) NULL,
		[adobe_post_socialownedpropertyname] [varchar](5000) NULL,
		[adobe_post_socialownedpropertypropertyvsapp] [varchar](5000) NULL,
		[adobe_post_socialpageviews] [varchar](5000) NULL,
		[adobe_post_socialpostviews] [varchar](5000) NULL,
		[adobe_post_socialpubcomments] [varchar](5000) NULL,
		[adobe_post_socialpubposts] [varchar](5000) NULL,
		[adobe_post_socialpubrecommends] [varchar](5000) NULL,
		[adobe_post_socialpubsubscribers] [varchar](5000) NULL,
		[adobe_post_socialterm] [varchar](5000) NULL,
		[adobe_post_socialtotalsentiment] [varchar](5000) NULL,
		[adobe_post_state] [varchar](5000) NULL,
		[adobe_post_survey] [varchar](5000) NULL,
		[adobe_post_t_time_info] [varchar](5000) NULL,
		[adobe_post_tnt] [varchar](5000) NULL,
		[adobe_post_tnt_action] [varchar](5000) NULL,
		[adobe_post_transactionid] [varchar](5000) NULL,
		[adobe_post_video] [varchar](5000) NULL,
		[adobe_post_videoad] [varchar](5000) NULL,
		[adobe_post_videoadinpod] [varchar](5000) NULL,
		[adobe_post_videoadplayername] [varchar](5000) NULL,
		[adobe_post_videoadpod] [varchar](5000) NULL,
		[adobe_post_videochannel] [varchar](5000) NULL,
		[adobe_post_videochapter] [varchar](5000) NULL,
		[adobe_post_videocontenttype] [varchar](5000) NULL,
		[adobe_post_videoplayername] [varchar](5000) NULL,
		[adobe_post_videoqoebitrateaverageevar] [varchar](5000) NULL,
		[adobe_post_videoqoebitratechangecountevar] [varchar](5000) NULL,
		[adobe_post_videoqoebuffercountevar] [varchar](5000) NULL,
		[adobe_post_videoqoebuffertimeevar] [varchar](5000) NULL,
		[adobe_post_videoqoedroppedframecountevar] [varchar](5000) NULL,
		[adobe_post_videoqoeerrorcountevar] [varchar](5000) NULL,
		[adobe_post_videoqoetimetostartevar] [varchar](5000) NULL,
		[adobe_post_videosegment] [varchar](5000) NULL,
		[adobe_post_visid_high] [varchar](5000) NULL,
		[adobe_post_visid_low] [varchar](5000) NULL,
		[adobe_post_visid_type] [varchar](5000) NULL,
		[adobe_post_zip] [varchar](5000) NULL,
		[adobe_prev_page] [varchar](5000) NULL,
		[adobe_product_list] [varchar](5000) NULL,
		[adobe_product_merchandising] [varchar](5000) NULL,
		[adobe_prop1] [varchar](5000) NULL,
		[adobe_prop2] [varchar](5000) NULL,
		[adobe_prop3] [varchar](5000) NULL,
		[adobe_prop4] [varchar](5000) NULL,
		[adobe_prop5] [varchar](5000) NULL,
		[adobe_prop6] [varchar](5000) NULL,
		[adobe_prop7] [varchar](5000) NULL,
		[adobe_prop8] [varchar](5000) NULL,
		[adobe_prop9] [varchar](5000) NULL,
		[adobe_prop10] [varchar](5000) NULL,
		[adobe_prop11] [varchar](5000) NULL,
		[adobe_prop12] [varchar](5000) NULL,
		[adobe_prop13] [varchar](5000) NULL,
		[adobe_prop14] [varchar](5000) NULL,
		[adobe_prop15] [varchar](5000) NULL,
		[adobe_prop16] [varchar](5000) NULL,
		[adobe_prop17] [varchar](5000) NULL,
		[adobe_prop18] [varchar](5000) NULL,
		[adobe_prop19] [varchar](5000) NULL,
		[adobe_prop20] [varchar](5000) NULL,
		[adobe_prop21] [varchar](5000) NULL,
		[adobe_prop22] [varchar](5000) NULL,
		[adobe_prop23] [varchar](5000) NULL,
		[adobe_prop24] [varchar](5000) NULL,
		[adobe_prop25] [varchar](5000) NULL,
		[adobe_prop26] [varchar](5000) NULL,
		[adobe_prop27] [varchar](5000) NULL,
		[adobe_prop28] [varchar](5000) NULL,
		[adobe_prop29] [varchar](5000) NULL,
		[adobe_prop30] [varchar](5000) NULL,
		[adobe_prop31] [varchar](5000) NULL,
		[adobe_prop32] [varchar](5000) NULL,
		[adobe_prop33] [varchar](5000) NULL,
		[adobe_prop34] [varchar](5000) NULL,
		[adobe_prop35] [varchar](5000) NULL,
		[adobe_prop36] [varchar](5000) NULL,
		[adobe_prop37] [varchar](5000) NULL,
		[adobe_prop38] [varchar](5000) NULL,
		[adobe_prop39] [varchar](5000) NULL,
		[adobe_prop40] [varchar](5000) NULL,
		[adobe_prop41] [varchar](5000) NULL,
		[adobe_prop42] [varchar](5000) NULL,
		[adobe_prop43] [varchar](5000) NULL,
		[adobe_prop44] [varchar](5000) NULL,
		[adobe_prop45] [varchar](5000) NULL,
		[adobe_prop46] [varchar](5000) NULL,
		[adobe_prop47] [varchar](5000) NULL,
		[adobe_prop48] [varchar](5000) NULL,
		[adobe_prop49] [varchar](5000) NULL,
		[adobe_prop50] [varchar](5000) NULL,
		[adobe_prop51] [varchar](5000) NULL,
		[adobe_prop52] [varchar](5000) NULL,
		[adobe_prop53] [varchar](5000) NULL,
		[adobe_prop54] [varchar](5000) NULL,
		[adobe_prop55] [varchar](5000) NULL,
		[adobe_prop56] [varchar](5000) NULL,
		[adobe_prop57] [varchar](5000) NULL,
		[adobe_prop58] [varchar](5000) NULL,
		[adobe_prop59] [varchar](5000) NULL,
		[adobe_prop60] [varchar](5000) NULL,
		[adobe_prop61] [varchar](5000) NULL,
		[adobe_prop62] [varchar](5000) NULL,
		[adobe_prop63] [varchar](5000) NULL,
		[adobe_prop64] [varchar](5000) NULL,
		[adobe_prop65] [varchar](5000) NULL,
		[adobe_prop66] [varchar](5000) NULL,
		[adobe_prop67] [varchar](5000) NULL,
		[adobe_prop68] [varchar](5000) NULL,
		[adobe_prop69] [varchar](5000) NULL,
		[adobe_prop70] [varchar](5000) NULL,
		[adobe_prop71] [varchar](5000) NULL,
		[adobe_prop72] [varchar](5000) NULL,
		[adobe_prop73] [varchar](5000) NULL,
		[adobe_prop74] [varchar](5000) NULL,
		[adobe_prop75] [varchar](5000) NULL,
		[adobe_purchaseid] [varchar](5000) NULL,
		[adobe_quarterly_visitor] [varchar](5000) NULL,
		[adobe_ref_domain] [varchar](5000) NULL,
		[adobe_ref_type] [varchar](5000) NULL,
		[adobe_referrer] [varchar](5000) NULL,
		[adobe_resolution] [varchar](5000) NULL,
		[adobe_s_kwcid] [varchar](5000) NULL,
		[adobe_s_resolution] [varchar](5000) NULL,
		[adobe_sampled_hit] [varchar](5000) NULL,
		[adobe_search_engine] [varchar](5000) NULL,
		[adobe_search_page_num] [varchar](5000) NULL,
		[adobe_secondary_hit] [varchar](5000) NULL,
		[adobe_service] [varchar](5000) NULL,
		[adobe_socialaccountandappids] [varchar](5000) NULL,
		[adobe_socialassettrackingcode] [varchar](5000) NULL,
		[adobe_socialauthor] [varchar](5000) NULL,
		[adobe_socialcontentprovider] [varchar](5000) NULL,
		[adobe_socialfbstories] [varchar](5000) NULL,
		[adobe_socialfbstorytellers] [varchar](5000) NULL,
		[adobe_socialinteractioncount] [varchar](5000) NULL,
		[adobe_socialinteractiontype] [varchar](5000) NULL,
		[adobe_sociallanguage] [varchar](5000) NULL,
		[adobe_sociallatlong] [varchar](5000) NULL,
		[adobe_sociallikeadds] [varchar](5000) NULL,
		[adobe_socialmentions] [varchar](5000) NULL,
		[adobe_socialowneddefinitioninsighttype] [varchar](5000) NULL,
		[adobe_socialowneddefinitioninsightvalue] [varchar](5000) NULL,
		[adobe_socialowneddefinitionmetric] [varchar](5000) NULL,
		[adobe_socialowneddefinitionpropertyvspost] [varchar](5000) NULL,
		[adobe_socialownedpostids] [varchar](5000) NULL,
		[adobe_socialownedpropertyid] [varchar](5000) NULL,
		[adobe_socialownedpropertyname] [varchar](5000) NULL,
		[adobe_socialownedpropertypropertyvsapp] [varchar](5000) NULL,
		[adobe_socialpageviews] [varchar](5000) NULL,
		[adobe_socialpostviews] [varchar](5000) NULL,
		[adobe_socialpubcomments] [varchar](5000) NULL,
		[adobe_socialpubposts] [varchar](5000) NULL,
		[adobe_socialpubrecommends] [varchar](5000) NULL,
		[adobe_socialpubsubscribers] [varchar](5000) NULL,
		[adobe_socialterm] [varchar](5000) NULL,
		[adobe_socialtotalsentiment] [varchar](5000) NULL,
		[adobe_sourceid] [varchar](5000) NULL,
		[adobe_state] [varchar](5000) NULL,
		[adobe_stats_server] [varchar](5000) NULL,
		[adobe_t_time_info] [varchar](5000) NULL,
		[adobe_tnt] [varchar](5000) NULL,
		[adobe_tnt_action] [varchar](5000) NULL,
		[adobe_tnt_post_vista] [varchar](5000) NULL,
		[adobe_transactionid] [varchar](5000) NULL,
		[adobe_truncated_hit] [varchar](5000) NULL,
		[adobe_ua_color] [varchar](5000) NULL,
		[adobe_ua_os] [varchar](5000) NULL,
		[adobe_ua_pixels] [varchar](5000) NULL,
		[adobe_user_agent] [varchar](5000) NULL,
		[adobe_user_hash] [varchar](5000) NULL,
		[adobe_user_server] [varchar](5000) NULL,
		[adobe_userid] [varchar](5000) NULL,
		[adobe_username] [varchar](5000) NULL,
		[adobe_va_closer_detail] [varchar](5000) NULL,
		[adobe_va_closer_id] [varchar](5000) NULL,
		[adobe_va_finder_detail] [varchar](5000) NULL,
		[adobe_va_finder_id] [varchar](5000) NULL,
		[adobe_va_instance_event] [varchar](5000) NULL,
		[adobe_va_new_engagement] [varchar](5000) NULL,
		[adobe_video] [varchar](5000) NULL,
		[adobe_videoad] [varchar](5000) NULL,
		[adobe_videoadinpod] [varchar](5000) NULL,
		[adobe_videoadplayername] [varchar](5000) NULL,
		[adobe_videoadpod] [varchar](5000) NULL,
		[adobe_videochannel] [varchar](5000) NULL,
		[adobe_videochapter] [varchar](5000) NULL,
		[adobe_videocontenttype] [varchar](5000) NULL,
		[adobe_videoplayername] [varchar](5000) NULL,
		[adobe_videoqoebitrateaverageevar] [varchar](5000) NULL,
		[adobe_videoqoebitratechangecountevar] [varchar](5000) NULL,
		[adobe_videoqoebuffercountevar] [varchar](5000) NULL,
		[adobe_videoqoebuffertimeevar] [varchar](5000) NULL,
		[adobe_videoqoedroppedframecountevar] [varchar](5000) NULL,
		[adobe_videoqoeerrorcountevar] [varchar](5000) NULL,
		[adobe_videoqoetimetostartevar] [varchar](5000) NULL,
		[adobe_videosegment] [varchar](5000) NULL,
		[adobe_visid_high] [varchar](5000) NULL,
		[adobe_visid_low] [varchar](5000) NULL,
		[adobe_visid_new] [varchar](5000) NULL,
		[adobe_visid_timestamp] [varchar](5000) NULL,
		[adobe_visid_type] [varchar](5000) NULL,
		[adobe_visit_keywords] [varchar](5000) NULL,
		[adobe_visit_num] [varchar](5000) NULL,
		[adobe_visit_page_num] [varchar](5000) NULL,
		[adobe_visit_referrer] [varchar](5000) NULL,
		[adobe_visit_search_engine] [varchar](5000) NULL,
		[adobe_visit_start_page_url] [varchar](5000) NULL,
		[adobe_visit_start_pagename] [varchar](5000) NULL,
		[adobe_visit_start_time_gmt] [varchar](5000) NULL,
		[adobe_weekly_visitor] [varchar](5000) NULL,
		[adobe_yearly_visitor] [varchar](5000) NULL,
		[adobe_zip] [varchar](5000) NULL,
		[orders_ORDDATE] [datetime] NULL,
		[orders_ACCTNO] [varchar](150) NULL,
		[orders_INDID] [varchar](250) NULL,
		[orders_HHID] [varchar](250) NULL,
		[orders_ADDID] [varchar](250) NULL,
		[orders_COMPID] [varchar](250) NULL,
		[orders_STORENO] [varchar](150) NULL,
		[orders_ORDALTLOC] [varchar](150) NULL,
		[orders_ORDERTYPE] [varchar](150) NULL,
		[orders_ORDNO] [varchar](150) NULL,
		[orders_ORDSOURCE] [varchar](150) NULL,
		[orders_SOURCETYPE] [varchar](150) NULL,
		[orders_ORDCHANNEL] [varchar](150) NULL,
		[orders_ORDSUBCHAN] [varchar](150) NULL,
		[orders_ORDQTY] [int] NULL,
		[orders_ORDGROSDOL] [money] NULL,
		[orders_ORDRTNDOL] [money] NULL,
		[orders_FILENAME] [varchar](150) NULL,
		[orders_SEQ] [varchar](150) NULL,
		[orders_FILEDATE] [varchar](150) NULL,
		[orders_INSERTDATE] [datetime] NULL,
		[items_ACCTNO] [varchar](150) NULL,
		[items_INDID] [varchar](250) NULL,
		[items_HHID] [varchar](250) NULL,
		[items_ADDID] [varchar](250) NULL,
		[items_COMPID] [varchar](250) NULL,
		[items_COUNTRYFLG] [varchar](150) NULL,
		[items_CATALOG] [varchar](150) NULL,
		[items_ITMCHANNEL] [varchar](150) NULL,
		[items_DEPT] [varchar](150) NULL,
		[items_DEPT_DESC] [varchar](150) NULL,
		[items_DEPTRFS] [varchar](150) NULL,
		[items_DSCNTCODE] [varchar](150) NULL,
		[items_DSCNTTYPE] [varchar](150) NULL,
		[items_INITIALDTE] [datetime] NULL,
		[items_ITEMNO] [varchar](150) NULL,
		[items_ITMDATE] [datetime] NULL,
		[items_LINENUM] [varchar](150) NULL,
		[items_ORDERTYPE] [varchar](150) NULL,
		[items_ITEMORDNO] [varchar](150) NULL,
		[items_ORIGLINENO] [varchar](150) NULL,
		[items_ORIGORDNO] [varchar](150) NULL,
		[items_ORIGSHIPTO] [varchar](150) NULL,
		[items_PAGENUM] [varchar](150) NULL,
		[items_DEMANDFLAG] [varchar](150) NULL,
		[items_RETURNFLAG] [int] NULL,
		[items_RECORDTYPE] [varchar](150) NULL,
		[items_RETAILAMT] [money] NULL,
		[items_ITMGROSDOL] [money] NULL,
		[items_ITMGROSRTN] [money] NULL,
		[items_RETREASON] [varchar](150) NULL,
		[items_SEQNO] [varchar](150) NULL,
		[items_SIZE] [varchar](150) NULL,
		[items_SIZE_DESC] [varchar](150) NULL,
		[items_COLOR] [varchar](150) NULL,
		[items_COLOR_DESC] [varchar](150) NULL,
		[items_STYLE] [varchar](150) NULL,
		[items_STYLE_DESC] [varchar](150) NULL,
		[items_SKU] [varchar](150) NULL,
		[items_ITMSTORENO] [varchar](150) NULL,
		[items_ITMSUBCHAN] [varchar](150) NULL,
		[items_TRANSNO] [varchar](150) NULL,
		[items_TRANSTYPE] [varchar](150) NULL,
		[items_ITMALTLOC] [varchar](150) NULL,
		[items_MERCHCNCPT] [varchar](150) NULL,
		[items_RETURNNO] [varchar](150) NULL,
		[items_SOURCECODE] [varchar](150) NULL,
		[items_ORGPRICE] [money] NULL,
		[items_DISCNTAMT] [varchar](150) NULL,
		[items_FILENAME] [varchar](150) NULL,
		[items_SEQ] [varchar](150) NULL,
		[items_FILEDATE] [varchar](150) NULL,
		[items_INSERTDATE] [datetime] NULL,
		[interactions_INTTYPE] [varchar](20) NULL,
		[interactions_INTSOURCE] [varchar](20) NULL,
		[interactions_EMAIL] [varchar](500) NULL,
		[interactions_ACCTNO] [varchar](9) NULL,
		[interactions_INDID] [varchar](20) NULL,
		[interactions_HHID] [nvarchar](20) NULL,
		[interactions_ADDRID] [nvarchar](20) NULL,
		[interactions_FNAME] [varchar](50) NULL,
		[interactions_LNAME] [varchar](50) NULL,
		[interactions_INTDATE] [varchar](50) NULL,
		[interactions_DNEFLAG] [varchar](2) NULL,
		[interactions_EMAILSTORE] [varchar](50) NULL,
		[interactions_EMAILPREF] [varchar](1) NULL,
		[interactions_FILENAME] [varchar](80) NULL,
		[interactions_SEQ] [varchar](10) NULL,
		[interactions_FILEDATE] [varchar](50) NULL,
		[interactions_MODDATE] [varchar](50) NULL,
		[promotions_ACCTNO] [varchar](80) NULL,
		[promotions_INDID] [varchar](80) NULL,
		[promotions_HHID] [varchar](80) NULL,
		[promotions_ADDID] [varchar](80) NULL,
		[promotions_COMPID] [varchar](80) NULL,
		[promotions_INHOME] [varchar](80) NULL,
		[promotions_CIRCNAME] [varchar](80) NULL,
		[promotions_FNAME] [varchar](80) NULL,
		[promotions_LNAME] [varchar](80) NULL,
		[promotions_COMPANY] [varchar](80) NULL,
		[promotions_TITLE] [varchar](80) NULL,
		[promotions_ADD1] [varchar](80) NULL,
		[promotions_ADD2] [varchar](80) NULL,
		[promotions_CITY] [varchar](80) NULL,
		[promotions_STATE] [varchar](80) NULL,
		[promotions_ZIP] [varchar](80) NULL,
		[promotions_EMAIL] [varchar](80) NULL,
		[promotions_PHONE] [varchar](80) NULL,
		[promotions_PLUS4] [varchar](80) NULL,
		[promotions_PRINUM] [varchar](80) NULL,
		[promotions_STREET] [varchar](80) NULL,
		[promotions_UNITNUM] [varchar](80) NULL,
		[promotions_FNAMEKEY] [varchar](80) NULL,
		[promotions_LNAMEKEY] [varchar](80) NULL,
		[promotions_COMPKEY] [varchar](80) NULL,
		[promotions_STREETKEY] [varchar](80) NULL,
		[promotions_ADSUFFIX] [varchar](80) NULL,
		[promotions_ADDTYPE] [varchar](80) NULL,
		[promotions_CRRT] [varchar](80) NULL,
		[promotions_CASSCODE] [varchar](80) NULL,
		[promotions_CKDIGIT] [varchar](80) NULL,
		[promotions_CNTRYCODE] [varchar](80) NULL,
		[promotions_CNTYCODE] [varchar](80) NULL,
		[promotions_CNTYNAME] [varchar](80) NULL,
		[promotions_DELPT] [varchar](80) NULL,
		[promotions_DPV] [varchar](80) NULL,
		[promotions_DPVFTNOTE] [varchar](80) NULL,
		[promotions_DPV_VACANT] [varchar](80) NULL,
		[promotions_LACSINDC] [varchar](80) NULL,
		[promotions_LOT] [varchar](80) NULL,
		[promotions_LOTORDER] [varchar](80) NULL,
		[promotions_DPVNOSTAT] [varchar](80) NULL,
		[promotions_POSDIR] [varchar](80) NULL,
		[promotions_PREDIR] [varchar](80) NULL,
		[promotions_UNITTYPE] [varchar](80) NULL,
		[promotions_GENDER] [varchar](80) NULL,
		[promotions_PROMTYPE] [varchar](80) NULL,
		[promotions_MAILKEY] [varchar](80) NULL,
		[promotions_LISTDESC] [varchar](80) NULL,
		[promotions_STRING] [varchar](80) NULL,
		[promotions_DEMO] [varchar](80) NULL,
		[promotions_HOLDOUT] [varchar](80) NULL,
		[promotions_CIRCID] [varchar](80) NULL,
		[promotions_ORG_INDID] [varchar](80) NULL,
		[promotions_ORG_HHID] [varchar](80) NULL,
		[promotions_ORG_ADDID] [varchar](80) NULL,
		[promotions_ORG_COMPID] [varchar](80) NULL,
		[email_activities_EMAILTYPE] [varchar](20) NULL,
		[email_activities_INTSOURCE] [varchar](20) NULL,
		[email_activities_EMAIL] [varchar](500) NULL,
		[email_activities_ACCTNO] [varchar](9) NULL,
		[email_activities_FNAME] [varchar](50) NULL,
		[email_activities_LNAME] [varchar](50) NULL,
		[email_activities_EMAILDATE] [varchar](50) NULL,
		[email_activities_DNEFLAG] [varchar](2) NULL,
		[email_activities_EMAILSTORE] [varchar](50) NULL,
		[email_activities_EMAILPREF] [varchar](1) NULL,
		[email_activities_FILENAME] [varchar](80) NULL,
		[email_activities_SEQ] [varchar](10) NULL,
		[email_activities_FILEDATE] [varchar](50) NULL,
		[email_activities_MODDATE] [varchar](50) NULL,
		[email_activities_IPADDRESS] [varchar](50) NULL,
		[email_promotions_ACCTNO] [varchar](10) NULL,
		[email_promotions_INDID] [varchar](30) NULL,
		[email_promotions_HHID] [varchar](30) NULL,
		[email_promotions_ADDRID] [varchar](30) NULL,
		[email_promotions_FNAME] [varchar](50) NULL,
		[email_promotions_LNAME] [varchar](50) NULL,
		[email_promotions_ADD1] [varchar](100) NULL,
		[email_promotions_ADD2] [varchar](100) NULL,
		[email_promotions_CITY] [varchar](100) NULL,
		[email_promotions_STATE] [varchar](100) NULL,
		[email_promotions_ZIP] [varchar](20) NULL,
		[email_promotions_ZIP4] [varchar](4) NULL,
		[email_promotions_COUNTRY] [varchar](100) NULL,
		[email_promotions_EMAIL] [varchar](100) NULL,
		[email_promotions_MAILABLE] [varchar](1) NULL,
		[email_promotions_DNRFLAG] [varchar](1) NULL,
		[email_promotions_DNEFLAG] [varchar](1) NULL,
		[email_promotions_EMAILFLAG] [varchar](1) NULL,
		[email_promotions_BDAY] [varchar](10) NULL,
		[email_promotions_INHOME] [date] NULL,
		[email_promotions_CIRCNAME] [varchar](150) NULL,
		[email_promotions_CIRCDESC] [varchar](100) NULL,
		[email_promotions_PROMTYPE] [varchar](100) NULL,
		[email_promotions_MAILKEY] [varchar](80) NULL,
		[email_promotions_LISTDESC] [varchar](100) NULL,
		[email_promotions_LDATE] [date] NULL,
		[email_promotions_OFFERDESCRIPTION] [varchar](100) NULL,
		[email_promotions_CAMPAIGNID] [varchar](40) NULL,
		[email_promotions_CAMPAIGNTYPE] [varchar](40) NULL,
		[email_promotions_FILEDATE] [varchar](40) NULL
	) ON [PRIMARY]

	-- go through and insert all of our events, pulling out timestamps and naming source tables
	INSERT INTO #temp_table_events_except_customers ([EVENT_TIME], [EVENT_TYPE], [adobe_accept_language], [adobe_browser], [adobe_browser_height], [adobe_browser_width], [adobe_c_color], [adobe_campaign], [adobe_carrier], [adobe_channel], [adobe_click_action], [adobe_click_action_type], [adobe_click_context], [adobe_click_context_type], [adobe_click_sourceid], [adobe_click_tag], [adobe_code_ver], [adobe_color], [adobe_connection_type], [adobe_cookies], [adobe_country], [adobe_ct_connect_type], [adobe_curr_factor], [adobe_curr_rate], [adobe_currency], [adobe_cust_hit_time_gmt], [adobe_cust_visid], [adobe_daily_visitor], [adobe_date_time], [adobe_domain], [adobe_duplicate_events], [adobe_duplicate_purchase], [adobe_duplicated_from], [adobe_ef_id], [adobe_evar1], [adobe_evar2], [adobe_evar3], [adobe_evar4], [adobe_evar5], [adobe_evar6], [adobe_evar7], [adobe_evar8], [adobe_evar9], [adobe_evar10], [adobe_evar11], [adobe_evar12], [adobe_evar13], [adobe_evar14], [adobe_evar15], [adobe_evar16], [adobe_evar17], [adobe_evar18], [adobe_evar19], [adobe_evar20], [adobe_evar21], [adobe_evar22], [adobe_evar23], [adobe_evar24], [adobe_evar25], [adobe_evar26], [adobe_evar27], [adobe_evar28], [adobe_evar29], [adobe_evar30], [adobe_evar31], [adobe_evar32], [adobe_evar33], [adobe_evar34], [adobe_evar35], [adobe_evar36], [adobe_evar37], [adobe_evar38], [adobe_evar39], [adobe_evar40], [adobe_evar41], [adobe_evar42], [adobe_evar43], [adobe_evar44], [adobe_evar45], [adobe_evar46], [adobe_evar47], [adobe_evar48], [adobe_evar49], [adobe_evar50], [adobe_evar51], [adobe_evar52], [adobe_evar53], [adobe_evar54], [adobe_evar55], [adobe_evar56], [adobe_evar57], [adobe_evar58], [adobe_evar59], [adobe_evar60], [adobe_evar61], [adobe_evar62], [adobe_evar63], [adobe_evar64], [adobe_evar65], [adobe_evar66], [adobe_evar67], [adobe_evar68], [adobe_evar69], [adobe_evar70], [adobe_evar71], [adobe_evar72], [adobe_evar73], [adobe_evar74], [adobe_evar75], [adobe_evar76], [adobe_evar77], [adobe_evar78], [adobe_evar79], [adobe_evar80], [adobe_evar81], [adobe_evar82], [adobe_evar83], [adobe_evar84], [adobe_evar85], [adobe_evar86], [adobe_evar87], [adobe_evar88], [adobe_evar89], [adobe_evar90], [adobe_evar91], [adobe_evar92], [adobe_evar93], [adobe_evar94], [adobe_evar95], [adobe_evar96], [adobe_evar97], [adobe_evar98], [adobe_evar99], [adobe_evar100], [adobe_event_list], [adobe_exclude_hit], [adobe_first_hit_page_url], [adobe_first_hit_pagename], [adobe_first_hit_referrer], [adobe_first_hit_time_gmt], [adobe_geo_city], [adobe_geo_country], [adobe_geo_dma], [adobe_geo_region], [adobe_geo_zip], [adobe_hier1], [adobe_hier2], [adobe_hier3], [adobe_hier4], [adobe_hier5], [adobe_hit_source], [adobe_hit_time_gmt], [adobe_hitid_high], [adobe_hitid_low], [adobe_homepage], [adobe_hourly_visitor], [adobe_ip], [adobe_ip2], [adobe_j_jscript], [adobe_java_enabled], [adobe_javascript], [adobe_language], [adobe_last_hit_time_gmt], [adobe_last_purchase_num], [adobe_last_purchase_time_gmt], [adobe_mc_audiences], [adobe_mcvisid], [adobe_mobile_id], [adobe_mobileaction], [adobe_mobileappid], [adobe_mobilecampaigncontent], [adobe_mobilecampaignmedium], [adobe_mobilecampaignname], [adobe_mobilecampaignsource], [adobe_mobilecampaignterm], [adobe_mobiledayofweek], [adobe_mobiledayssincefirstuse], [adobe_mobiledayssincelastuse], [adobe_mobiledevice], [adobe_mobilehourofday], [adobe_mobileinstalldate], [adobe_mobilelaunchnumber], [adobe_mobileltv], [adobe_mobilemessageid], [adobe_mobilemessageonline], [adobe_mobileosversion], [adobe_mobilepushoptin], [adobe_mobilepushpayloadid], [adobe_mobileresolution], [adobe_monthly_visitor], [adobe_mvvar1], [adobe_mvvar2], [adobe_mvvar3], [adobe_namespace], [adobe_new_visit], [adobe_os], [adobe_p_plugins], [adobe_page_event], [adobe_page_event_var1], [adobe_page_event_var2], [adobe_page_event_var3], [adobe_page_type], [adobe_page_url], [adobe_pagename], [adobe_paid_search], [adobe_partner_plugins], [adobe_persistent_cookie], [adobe_plugins], [adobe_pointofinterest], [adobe_pointofinterestdistance], [adobe_post_browser_height], [adobe_post_browser_width], [adobe_post_campaign], [adobe_post_channel], [adobe_post_cookies], [adobe_post_currency], [adobe_post_cust_hit_time_gmt], [adobe_post_cust_visid], [adobe_post_ef_id], [adobe_post_evar1], [adobe_post_evar2], [adobe_post_evar3], [adobe_post_evar4], [adobe_post_evar5], [adobe_post_evar6], [adobe_post_evar7], [adobe_post_evar8], [adobe_post_evar9], [adobe_post_evar10], [adobe_post_evar11], [adobe_post_evar12], [adobe_post_evar13], [adobe_post_evar14], [adobe_post_evar15], [adobe_post_evar16], [adobe_post_evar17], [adobe_post_evar18], [adobe_post_evar19], [adobe_post_evar20], [adobe_post_evar21], [adobe_post_evar22], [adobe_post_evar23], [adobe_post_evar24], [adobe_post_evar25], [adobe_post_evar26], [adobe_post_evar27], [adobe_post_evar28], [adobe_post_evar29], [adobe_post_evar30], [adobe_post_evar31], [adobe_post_evar32], [adobe_post_evar33], [adobe_post_evar34], [adobe_post_evar35], [adobe_post_evar36], [adobe_post_evar37], [adobe_post_evar38], [adobe_post_evar39], [adobe_post_evar40], [adobe_post_evar41], [adobe_post_evar42], [adobe_post_evar43], [adobe_post_evar44], [adobe_post_evar45], [adobe_post_evar46], [adobe_post_evar47], [adobe_post_evar48], [adobe_post_evar49], [adobe_post_evar50], [adobe_post_evar51], [adobe_post_evar52], [adobe_post_evar53], [adobe_post_evar54], [adobe_post_evar55], [adobe_post_evar56], [adobe_post_evar57], [adobe_post_evar58], [adobe_post_evar59], [adobe_post_evar60], [adobe_post_evar61], [adobe_post_evar62], [adobe_post_evar63], [adobe_post_evar64], [adobe_post_evar65], [adobe_post_evar66], [adobe_post_evar67], [adobe_post_evar68], [adobe_post_evar69], [adobe_post_evar70], [adobe_post_evar71], [adobe_post_evar72], [adobe_post_evar73], [adobe_post_evar74], [adobe_post_evar75], [adobe_post_evar76], [adobe_post_evar77], [adobe_post_evar78], [adobe_post_evar79], [adobe_post_evar80], [adobe_post_evar81], [adobe_post_evar82], [adobe_post_evar83], [adobe_post_evar84], [adobe_post_evar85], [adobe_post_evar86], [adobe_post_evar87], [adobe_post_evar88], [adobe_post_evar89], [adobe_post_evar90], [adobe_post_evar91], [adobe_post_evar92], [adobe_post_evar93], [adobe_post_evar94], [adobe_post_evar95], [adobe_post_evar96], [adobe_post_evar97], [adobe_post_evar98], [adobe_post_evar99], [adobe_post_evar100], [adobe_post_event_list], [adobe_post_hier1], [adobe_post_hier2], [adobe_post_hier3], [adobe_post_hier4], [adobe_post_hier5], [adobe_post_java_enabled], [adobe_post_keywords], [adobe_post_mc_audiences], [adobe_post_mobileaction], [adobe_post_mobileappid], [adobe_post_mobilecampaigncontent], [adobe_post_mobilecampaignmedium], [adobe_post_mobilecampaignname], [adobe_post_mobilecampaignsource], [adobe_post_mobilecampaignterm], [adobe_post_mobiledayofweek], [adobe_post_mobiledayssincefirstuse], [adobe_post_mobiledayssincelastuse], [adobe_post_mobiledevice], [adobe_post_mobilehourofday], [adobe_post_mobileinstalldate], [adobe_post_mobilelaunchnumber], [adobe_post_mobileltv], [adobe_post_mobilemessageid], [adobe_post_mobilemessageonline], [adobe_post_mobileosversion], [adobe_post_mobilepushoptin], [adobe_post_mobilepushpayloadid], [adobe_post_mobileresolution], [adobe_post_mvvar1], [adobe_post_mvvar2], [adobe_post_mvvar3], [adobe_post_page_event], [adobe_post_page_event_var1], [adobe_post_page_event_var2], [adobe_post_page_event_var3], [adobe_post_page_type], [adobe_post_page_url], [adobe_post_pagename], [adobe_post_pagename_no_url], [adobe_post_partner_plugins], [adobe_post_persistent_cookie], [adobe_post_pointofinterest], [adobe_post_pointofinterestdistance], [adobe_post_product_list], [adobe_post_prop1], [adobe_post_prop2], [adobe_post_prop3], [adobe_post_prop4], [adobe_post_prop5], [adobe_post_prop6], [adobe_post_prop7], [adobe_post_prop8], [adobe_post_prop9], [adobe_post_prop10], [adobe_post_prop11], [adobe_post_prop12], [adobe_post_prop13], [adobe_post_prop14], [adobe_post_prop15], [adobe_post_prop16], [adobe_post_prop17], [adobe_post_prop18], [adobe_post_prop19], [adobe_post_prop20], [adobe_post_prop21], [adobe_post_prop22], [adobe_post_prop23], [adobe_post_prop24], [adobe_post_prop25], [adobe_post_prop26], [adobe_post_prop27], [adobe_post_prop28], [adobe_post_prop29], [adobe_post_prop30], [adobe_post_prop31], [adobe_post_prop32], [adobe_post_prop33], [adobe_post_prop34], [adobe_post_prop35], [adobe_post_prop36], [adobe_post_prop37], [adobe_post_prop38], [adobe_post_prop39], [adobe_post_prop40], [adobe_post_prop41], [adobe_post_prop42], [adobe_post_prop43], [adobe_post_prop44], [adobe_post_prop45], [adobe_post_prop46], [adobe_post_prop47], [adobe_post_prop48], [adobe_post_prop49], [adobe_post_prop50], [adobe_post_prop51], [adobe_post_prop52], [adobe_post_prop53], [adobe_post_prop54], [adobe_post_prop55], [adobe_post_prop56], [adobe_post_prop57], [adobe_post_prop58], [adobe_post_prop59], [adobe_post_prop60], [adobe_post_prop61], [adobe_post_prop62], [adobe_post_prop63], [adobe_post_prop64], [adobe_post_prop65], [adobe_post_prop66], [adobe_post_prop67], [adobe_post_prop68], [adobe_post_prop69], [adobe_post_prop70], [adobe_post_prop71], [adobe_post_prop72], [adobe_post_prop73], [adobe_post_prop74], [adobe_post_prop75], [adobe_post_purchaseid], [adobe_post_referrer], [adobe_post_s_kwcid], [adobe_post_search_engine], [adobe_post_socialaccountandappids], [adobe_post_socialassettrackingcode], [adobe_post_socialauthor], [adobe_post_socialcontentprovider], [adobe_post_socialfbstories], [adobe_post_socialfbstorytellers], [adobe_post_socialinteractioncount], [adobe_post_socialinteractiontype], [adobe_post_sociallanguage], [adobe_post_sociallatlong], [adobe_post_sociallikeadds], [adobe_post_socialmentions], [adobe_post_socialowneddefinitioninsighttype], [adobe_post_socialowneddefinitioninsightvalue], [adobe_post_socialowneddefinitionmetric], [adobe_post_socialowneddefinitionpropertyvspost], [adobe_post_socialownedpostids], [adobe_post_socialownedpropertyid], [adobe_post_socialownedpropertyname], [adobe_post_socialownedpropertypropertyvsapp], [adobe_post_socialpageviews], [adobe_post_socialpostviews], [adobe_post_socialpubcomments], [adobe_post_socialpubposts], [adobe_post_socialpubrecommends], [adobe_post_socialpubsubscribers], [adobe_post_socialterm], [adobe_post_socialtotalsentiment], [adobe_post_state], [adobe_post_survey], [adobe_post_t_time_info], [adobe_post_tnt], [adobe_post_tnt_action], [adobe_post_transactionid], [adobe_post_video], [adobe_post_videoad], [adobe_post_videoadinpod], [adobe_post_videoadplayername], [adobe_post_videoadpod], [adobe_post_videochannel], [adobe_post_videochapter], [adobe_post_videocontenttype], [adobe_post_videoplayername], [adobe_post_videoqoebitrateaverageevar], [adobe_post_videoqoebitratechangecountevar], [adobe_post_videoqoebuffercountevar], [adobe_post_videoqoebuffertimeevar], [adobe_post_videoqoedroppedframecountevar], [adobe_post_videoqoeerrorcountevar], [adobe_post_videoqoetimetostartevar], [adobe_post_videosegment], [adobe_post_visid_high], [adobe_post_visid_low], [adobe_post_visid_type], [adobe_post_zip], [adobe_prev_page], [adobe_product_list], [adobe_product_merchandising], [adobe_prop1], [adobe_prop2], [adobe_prop3], [adobe_prop4], [adobe_prop5], [adobe_prop6], [adobe_prop7], [adobe_prop8], [adobe_prop9], [adobe_prop10], [adobe_prop11], [adobe_prop12], [adobe_prop13], [adobe_prop14], [adobe_prop15], [adobe_prop16], [adobe_prop17], [adobe_prop18], [adobe_prop19], [adobe_prop20], [adobe_prop21], [adobe_prop22], [adobe_prop23], [adobe_prop24], [adobe_prop25], [adobe_prop26], [adobe_prop27], [adobe_prop28], [adobe_prop29], [adobe_prop30], [adobe_prop31], [adobe_prop32], [adobe_prop33], [adobe_prop34], [adobe_prop35], [adobe_prop36], [adobe_prop37], [adobe_prop38], [adobe_prop39], [adobe_prop40], [adobe_prop41], [adobe_prop42], [adobe_prop43], [adobe_prop44], [adobe_prop45], [adobe_prop46], [adobe_prop47], [adobe_prop48], [adobe_prop49], [adobe_prop50], [adobe_prop51], [adobe_prop52], [adobe_prop53], [adobe_prop54], [adobe_prop55], [adobe_prop56], [adobe_prop57], [adobe_prop58], [adobe_prop59], [adobe_prop60], [adobe_prop61], [adobe_prop62], [adobe_prop63], [adobe_prop64], [adobe_prop65], [adobe_prop66], [adobe_prop67], [adobe_prop68], [adobe_prop69], [adobe_prop70], [adobe_prop71], [adobe_prop72], [adobe_prop73], [adobe_prop74], [adobe_prop75], [adobe_purchaseid], [adobe_quarterly_visitor], [adobe_ref_domain], [adobe_ref_type], [adobe_referrer], [adobe_resolution], [adobe_s_kwcid], [adobe_s_resolution], [adobe_sampled_hit], [adobe_search_engine], [adobe_search_page_num], [adobe_secondary_hit], [adobe_service], [adobe_socialaccountandappids], [adobe_socialassettrackingcode], [adobe_socialauthor], [adobe_socialcontentprovider], [adobe_socialfbstories], [adobe_socialfbstorytellers], [adobe_socialinteractioncount], [adobe_socialinteractiontype], [adobe_sociallanguage], [adobe_sociallatlong], [adobe_sociallikeadds], [adobe_socialmentions], [adobe_socialowneddefinitioninsighttype], [adobe_socialowneddefinitioninsightvalue], [adobe_socialowneddefinitionmetric], [adobe_socialowneddefinitionpropertyvspost], [adobe_socialownedpostids], [adobe_socialownedpropertyid], [adobe_socialownedpropertyname], [adobe_socialownedpropertypropertyvsapp], [adobe_socialpageviews], [adobe_socialpostviews], [adobe_socialpubcomments], [adobe_socialpubposts], [adobe_socialpubrecommends], [adobe_socialpubsubscribers], [adobe_socialterm], [adobe_socialtotalsentiment], [adobe_sourceid], [adobe_state], [adobe_stats_server], [adobe_t_time_info], [adobe_tnt], [adobe_tnt_action], [adobe_tnt_post_vista], [adobe_transactionid], [adobe_truncated_hit], [adobe_ua_color], [adobe_ua_os], [adobe_ua_pixels], [adobe_user_agent], [adobe_user_hash], [adobe_user_server], [adobe_userid], [adobe_username], [adobe_va_closer_detail], [adobe_va_closer_id], [adobe_va_finder_detail], [adobe_va_finder_id], [adobe_va_instance_event], [adobe_va_new_engagement], [adobe_video], [adobe_videoad], [adobe_videoadinpod], [adobe_videoadplayername], [adobe_videoadpod], [adobe_videochannel], [adobe_videochapter], [adobe_videocontenttype], [adobe_videoplayername], [adobe_videoqoebitrateaverageevar], [adobe_videoqoebitratechangecountevar], [adobe_videoqoebuffercountevar], [adobe_videoqoebuffertimeevar], [adobe_videoqoedroppedframecountevar], [adobe_videoqoeerrorcountevar], [adobe_videoqoetimetostartevar], [adobe_videosegment], [adobe_visid_high], [adobe_visid_low], [adobe_visid_new], [adobe_visid_timestamp], [adobe_visid_type], [adobe_visit_keywords], [adobe_visit_num], [adobe_visit_page_num], [adobe_visit_referrer], [adobe_visit_search_engine], [adobe_visit_start_page_url], [adobe_visit_start_pagename], [adobe_visit_start_time_gmt], [adobe_weekly_visitor], [adobe_yearly_visitor], [adobe_zip])
	SELECT [date_time] AS [EVENT_TIME],
		'adobe',
		[accept_language] AS [adobe_accept_language],
		[browser] AS [adobe_browser],
		[browser_height] AS [adobe_browser_height],
		[browser_width] AS [adobe_browser_width],
		[c_color] AS [adobe_c_color],
		[campaign] AS [adobe_campaign],
		[carrier] AS [adobe_carrier],
		[channel] AS [adobe_channel],
		[click_action] AS [adobe_click_action],
		[click_action_type] AS [adobe_click_action_type],
		[click_context] AS [adobe_click_context],
		[click_context_type] AS [adobe_click_context_type],
		[click_sourceid] AS [adobe_click_sourceid],
		[click_tag] AS [adobe_click_tag],
		[code_ver] AS [adobe_code_ver],
		[color] AS [adobe_color],
		[connection_type] AS [adobe_connection_type],
		[cookies] AS [adobe_cookies],
		[country] AS [adobe_country],
		[ct_connect_type] AS [adobe_ct_connect_type],
		[curr_factor] AS [adobe_curr_factor],
		[curr_rate] AS [adobe_curr_rate],
		[currency] AS [adobe_currency],
		[cust_hit_time_gmt] AS [adobe_cust_hit_time_gmt],
		[cust_visid] AS [adobe_cust_visid],
		[daily_visitor] AS [adobe_daily_visitor],
		[date_time] AS [adobe_date_time],
		[domain] AS [adobe_domain],
		[duplicate_events] AS [adobe_duplicate_events],
		[duplicate_purchase] AS [adobe_duplicate_purchase],
		[duplicated_from] AS [adobe_duplicated_from],
		[ef_id] AS [adobe_ef_id],
		[evar1] AS [adobe_evar1],
		[evar2] AS [adobe_evar2],
		[evar3] AS [adobe_evar3],
		[evar4] AS [adobe_evar4],
		[evar5] AS [adobe_evar5],
		[evar6] AS [adobe_evar6],
		[evar7] AS [adobe_evar7],
		[evar8] AS [adobe_evar8],
		[evar9] AS [adobe_evar9],
		[evar10] AS [adobe_evar10],
		[evar11] AS [adobe_evar11],
		[evar12] AS [adobe_evar12],
		[evar13] AS [adobe_evar13],
		[evar14] AS [adobe_evar14],
		[evar15] AS [adobe_evar15],
		[evar16] AS [adobe_evar16],
		[evar17] AS [adobe_evar17],
		[evar18] AS [adobe_evar18],
		[evar19] AS [adobe_evar19],
		[evar20] AS [adobe_evar20],
		[evar21] AS [adobe_evar21],
		[evar22] AS [adobe_evar22],
		[evar23] AS [adobe_evar23],
		[evar24] AS [adobe_evar24],
		[evar25] AS [adobe_evar25],
		[evar26] AS [adobe_evar26],
		[evar27] AS [adobe_evar27],
		[evar28] AS [adobe_evar28],
		[evar29] AS [adobe_evar29],
		[evar30] AS [adobe_evar30],
		[evar31] AS [adobe_evar31],
		[evar32] AS [adobe_evar32],
		[evar33] AS [adobe_evar33],
		[evar34] AS [adobe_evar34],
		[evar35] AS [adobe_evar35],
		[evar36] AS [adobe_evar36],
		[evar37] AS [adobe_evar37],
		[evar38] AS [adobe_evar38],
		[evar39] AS [adobe_evar39],
		[evar40] AS [adobe_evar40],
		[evar41] AS [adobe_evar41],
		[evar42] AS [adobe_evar42],
		[evar43] AS [adobe_evar43],
		[evar44] AS [adobe_evar44],
		[evar45] AS [adobe_evar45],
		[evar46] AS [adobe_evar46],
		[evar47] AS [adobe_evar47],
		[evar48] AS [adobe_evar48],
		[evar49] AS [adobe_evar49],
		[evar50] AS [adobe_evar50],
		[evar51] AS [adobe_evar51],
		[evar52] AS [adobe_evar52],
		[evar53] AS [adobe_evar53],
		[evar54] AS [adobe_evar54],
		[evar55] AS [adobe_evar55],
		[evar56] AS [adobe_evar56],
		[evar57] AS [adobe_evar57],
		[evar58] AS [adobe_evar58],
		[evar59] AS [adobe_evar59],
		[evar60] AS [adobe_evar60],
		[evar61] AS [adobe_evar61],
		[evar62] AS [adobe_evar62],
		[evar63] AS [adobe_evar63],
		[evar64] AS [adobe_evar64],
		[evar65] AS [adobe_evar65],
		[evar66] AS [adobe_evar66],
		[evar67] AS [adobe_evar67],
		[evar68] AS [adobe_evar68],
		[evar69] AS [adobe_evar69],
		[evar70] AS [adobe_evar70],
		[evar71] AS [adobe_evar71],
		[evar72] AS [adobe_evar72],
		[evar73] AS [adobe_evar73],
		[evar74] AS [adobe_evar74],
		[evar75] AS [adobe_evar75],
		[evar76] AS [adobe_evar76],
		[evar77] AS [adobe_evar77],
		[evar78] AS [adobe_evar78],
		[evar79] AS [adobe_evar79],
		[evar80] AS [adobe_evar80],
		[evar81] AS [adobe_evar81],
		[evar82] AS [adobe_evar82],
		[evar83] AS [adobe_evar83],
		[evar84] AS [adobe_evar84],
		[evar85] AS [adobe_evar85],
		[evar86] AS [adobe_evar86],
		[evar87] AS [adobe_evar87],
		[evar88] AS [adobe_evar88],
		[evar89] AS [adobe_evar89],
		[evar90] AS [adobe_evar90],
		[evar91] AS [adobe_evar91],
		[evar92] AS [adobe_evar92],
		[evar93] AS [adobe_evar93],
		[evar94] AS [adobe_evar94],
		[evar95] AS [adobe_evar95],
		[evar96] AS [adobe_evar96],
		[evar97] AS [adobe_evar97],
		[evar98] AS [adobe_evar98],
		[evar99] AS [adobe_evar99],
		[evar100] AS [adobe_evar100],
		[event_list] AS [adobe_event_list],
		[exclude_hit] AS [adobe_exclude_hit],
		[first_hit_page_url] AS [adobe_first_hit_page_url],
		[first_hit_pagename] AS [adobe_first_hit_pagename],
		[first_hit_referrer] AS [adobe_first_hit_referrer],
		[first_hit_time_gmt] AS [adobe_first_hit_time_gmt],
		[geo_city] AS [adobe_geo_city],
		[geo_country] AS [adobe_geo_country],
		[geo_dma] AS [adobe_geo_dma],
		[geo_region] AS [adobe_geo_region],
		[geo_zip] AS [adobe_geo_zip],
		[hier1] AS [adobe_hier1],
		[hier2] AS [adobe_hier2],
		[hier3] AS [adobe_hier3],
		[hier4] AS [adobe_hier4],
		[hier5] AS [adobe_hier5],
		[hit_source] AS [adobe_hit_source],
		[hit_time_gmt] AS [adobe_hit_time_gmt],
		[hitid_high] AS [adobe_hitid_high],
		[hitid_low] AS [adobe_hitid_low],
		[homepage] AS [adobe_homepage],
		[hourly_visitor] AS [adobe_hourly_visitor],
		[ip] AS [adobe_ip],
		[ip2] AS [adobe_ip2],
		[j_jscript] AS [adobe_j_jscript],
		[java_enabled] AS [adobe_java_enabled],
		[javascript] AS [adobe_javascript],
		[language] AS [adobe_language],
		[last_hit_time_gmt] AS [adobe_last_hit_time_gmt],
		[last_purchase_num] AS [adobe_last_purchase_num],
		[last_purchase_time_gmt] AS [adobe_last_purchase_time_gmt],
		[mc_audiences] AS [adobe_mc_audiences],
		[mcvisid] AS [adobe_mcvisid],
		[mobile_id] AS [adobe_mobile_id],
		[mobileaction] AS [adobe_mobileaction],
		[mobileappid] AS [adobe_mobileappid],
		[mobilecampaigncontent] AS [adobe_mobilecampaigncontent],
		[mobilecampaignmedium] AS [adobe_mobilecampaignmedium],
		[mobilecampaignname] AS [adobe_mobilecampaignname],
		[mobilecampaignsource] AS [adobe_mobilecampaignsource],
		[mobilecampaignterm] AS [adobe_mobilecampaignterm],
		[mobiledayofweek] AS [adobe_mobiledayofweek],
		[mobiledayssincefirstuse] AS [adobe_mobiledayssincefirstuse],
		[mobiledayssincelastuse] AS [adobe_mobiledayssincelastuse],
		[mobiledevice] AS [adobe_mobiledevice],
		[mobilehourofday] AS [adobe_mobilehourofday],
		[mobileinstalldate] AS [adobe_mobileinstalldate],
		[mobilelaunchnumber] AS [adobe_mobilelaunchnumber],
		[mobileltv] AS [adobe_mobileltv],
		[mobilemessageid] AS [adobe_mobilemessageid],
		[mobilemessageonline] AS [adobe_mobilemessageonline],
		[mobileosversion] AS [adobe_mobileosversion],
		[mobilepushoptin] AS [adobe_mobilepushoptin],
		[mobilepushpayloadid] AS [adobe_mobilepushpayloadid],
		[mobileresolution] AS [adobe_mobileresolution],
		[monthly_visitor] AS [adobe_monthly_visitor],
		[mvvar1] AS [adobe_mvvar1],
		[mvvar2] AS [adobe_mvvar2],
		[mvvar3] AS [adobe_mvvar3],
		[namespace] AS [adobe_namespace],
		[new_visit] AS [adobe_new_visit],
		[os] AS [adobe_os],
		[p_plugins] AS [adobe_p_plugins],
		[page_event] AS [adobe_page_event],
		[page_event_var1] AS [adobe_page_event_var1],
		[page_event_var2] AS [adobe_page_event_var2],
		[page_event_var3] AS [adobe_page_event_var3],
		[page_type] AS [adobe_page_type],
		[page_url] AS [adobe_page_url],
		[pagename] AS [adobe_pagename],
		[paid_search] AS [adobe_paid_search],
		[partner_plugins] AS [adobe_partner_plugins],
		[persistent_cookie] AS [adobe_persistent_cookie],
		[plugins] AS [adobe_plugins],
		[pointofinterest] AS [adobe_pointofinterest],
		[pointofinterestdistance] AS [adobe_pointofinterestdistance],
		[post_browser_height] AS [adobe_post_browser_height],
		[post_browser_width] AS [adobe_post_browser_width],
		[post_campaign] AS [adobe_post_campaign],
		[post_channel] AS [adobe_post_channel],
		[post_cookies] AS [adobe_post_cookies],
		[post_currency] AS [adobe_post_currency],
		[post_cust_hit_time_gmt] AS [adobe_post_cust_hit_time_gmt],
		[post_cust_visid] AS [adobe_post_cust_visid],
		[post_ef_id] AS [adobe_post_ef_id],
		[post_evar1] AS [adobe_post_evar1],
		[post_evar2] AS [adobe_post_evar2],
		[post_evar3] AS [adobe_post_evar3],
		[post_evar4] AS [adobe_post_evar4],
		[post_evar5] AS [adobe_post_evar5],
		[post_evar6] AS [adobe_post_evar6],
		[post_evar7] AS [adobe_post_evar7],
		[post_evar8] AS [adobe_post_evar8],
		[post_evar9] AS [adobe_post_evar9],
		[post_evar10] AS [adobe_post_evar10],
		[post_evar11] AS [adobe_post_evar11],
		[post_evar12] AS [adobe_post_evar12],
		[post_evar13] AS [adobe_post_evar13],
		[post_evar14] AS [adobe_post_evar14],
		[post_evar15] AS [adobe_post_evar15],
		[post_evar16] AS [adobe_post_evar16],
		[post_evar17] AS [adobe_post_evar17],
		[post_evar18] AS [adobe_post_evar18],
		[post_evar19] AS [adobe_post_evar19],
		[post_evar20] AS [adobe_post_evar20],
		[post_evar21] AS [adobe_post_evar21],
		[post_evar22] AS [adobe_post_evar22],
		[post_evar23] AS [adobe_post_evar23],
		[post_evar24] AS [adobe_post_evar24],
		[post_evar25] AS [adobe_post_evar25],
		[post_evar26] AS [adobe_post_evar26],
		[post_evar27] AS [adobe_post_evar27],
		[post_evar28] AS [adobe_post_evar28],
		[post_evar29] AS [adobe_post_evar29],
		[post_evar30] AS [adobe_post_evar30],
		[post_evar31] AS [adobe_post_evar31],
		[post_evar32] AS [adobe_post_evar32],
		[post_evar33] AS [adobe_post_evar33],
		[post_evar34] AS [adobe_post_evar34],
		[post_evar35] AS [adobe_post_evar35],
		[post_evar36] AS [adobe_post_evar36],
		[post_evar37] AS [adobe_post_evar37],
		[post_evar38] AS [adobe_post_evar38],
		[post_evar39] AS [adobe_post_evar39],
		[post_evar40] AS [adobe_post_evar40],
		[post_evar41] AS [adobe_post_evar41],
		[post_evar42] AS [adobe_post_evar42],
		[post_evar43] AS [adobe_post_evar43],
		[post_evar44] AS [adobe_post_evar44],
		[post_evar45] AS [adobe_post_evar45],
		[post_evar46] AS [adobe_post_evar46],
		[post_evar47] AS [adobe_post_evar47],
		[post_evar48] AS [adobe_post_evar48],
		[post_evar49] AS [adobe_post_evar49],
		[post_evar50] AS [adobe_post_evar50],
		[post_evar51] AS [adobe_post_evar51],
		[post_evar52] AS [adobe_post_evar52],
		[post_evar53] AS [adobe_post_evar53],
		[post_evar54] AS [adobe_post_evar54],
		[post_evar55] AS [adobe_post_evar55],
		[post_evar56] AS [adobe_post_evar56],
		[post_evar57] AS [adobe_post_evar57],
		[post_evar58] AS [adobe_post_evar58],
		[post_evar59] AS [adobe_post_evar59],
		[post_evar60] AS [adobe_post_evar60],
		[post_evar61] AS [adobe_post_evar61],
		[post_evar62] AS [adobe_post_evar62],
		[post_evar63] AS [adobe_post_evar63],
		[post_evar64] AS [adobe_post_evar64],
		[post_evar65] AS [adobe_post_evar65],
		[post_evar66] AS [adobe_post_evar66],
		[post_evar67] AS [adobe_post_evar67],
		[post_evar68] AS [adobe_post_evar68],
		[post_evar69] AS [adobe_post_evar69],
		[post_evar70] AS [adobe_post_evar70],
		[post_evar71] AS [adobe_post_evar71],
		[post_evar72] AS [adobe_post_evar72],
		[post_evar73] AS [adobe_post_evar73],
		[post_evar74] AS [adobe_post_evar74],
		[post_evar75] AS [adobe_post_evar75],
		[post_evar76] AS [adobe_post_evar76],
		[post_evar77] AS [adobe_post_evar77],
		[post_evar78] AS [adobe_post_evar78],
		[post_evar79] AS [adobe_post_evar79],
		[post_evar80] AS [adobe_post_evar80],
		[post_evar81] AS [adobe_post_evar81],
		[post_evar82] AS [adobe_post_evar82],
		[post_evar83] AS [adobe_post_evar83],
		[post_evar84] AS [adobe_post_evar84],
		[post_evar85] AS [adobe_post_evar85],
		[post_evar86] AS [adobe_post_evar86],
		[post_evar87] AS [adobe_post_evar87],
		[post_evar88] AS [adobe_post_evar88],
		[post_evar89] AS [adobe_post_evar89],
		[post_evar90] AS [adobe_post_evar90],
		[post_evar91] AS [adobe_post_evar91],
		[post_evar92] AS [adobe_post_evar92],
		[post_evar93] AS [adobe_post_evar93],
		[post_evar94] AS [adobe_post_evar94],
		[post_evar95] AS [adobe_post_evar95],
		[post_evar96] AS [adobe_post_evar96],
		[post_evar97] AS [adobe_post_evar97],
		[post_evar98] AS [adobe_post_evar98],
		[post_evar99] AS [adobe_post_evar99],
		[post_evar100] AS [adobe_post_evar100],
		[post_event_list] AS [adobe_post_event_list],
		[post_hier1] AS [adobe_post_hier1],
		[post_hier2] AS [adobe_post_hier2],
		[post_hier3] AS [adobe_post_hier3],
		[post_hier4] AS [adobe_post_hier4],
		[post_hier5] AS [adobe_post_hier5],
		[post_java_enabled] AS [adobe_post_java_enabled],
		[post_keywords] AS [adobe_post_keywords],
		[post_mc_audiences] AS [adobe_post_mc_audiences],
		[post_mobileaction] AS [adobe_post_mobileaction],
		[post_mobileappid] AS [adobe_post_mobileappid],
		[post_mobilecampaigncontent] AS [adobe_post_mobilecampaigncontent],
		[post_mobilecampaignmedium] AS [adobe_post_mobilecampaignmedium],
		[post_mobilecampaignname] AS [adobe_post_mobilecampaignname],
		[post_mobilecampaignsource] AS [adobe_post_mobilecampaignsource],
		[post_mobilecampaignterm] AS [adobe_post_mobilecampaignterm],
		[post_mobiledayofweek] AS [adobe_post_mobiledayofweek],
		[post_mobiledayssincefirstuse] AS [adobe_post_mobiledayssincefirstuse],
		[post_mobiledayssincelastuse] AS [adobe_post_mobiledayssincelastuse],
		[post_mobiledevice] AS [adobe_post_mobiledevice],
		[post_mobilehourofday] AS [adobe_post_mobilehourofday],
		[post_mobileinstalldate] AS [adobe_post_mobileinstalldate],
		[post_mobilelaunchnumber] AS [adobe_post_mobilelaunchnumber],
		[post_mobileltv] AS [adobe_post_mobileltv],
		[post_mobilemessageid] AS [adobe_post_mobilemessageid],
		[post_mobilemessageonline] AS [adobe_post_mobilemessageonline],
		[post_mobileosversion] AS [adobe_post_mobileosversion],
		[post_mobilepushoptin] AS [adobe_post_mobilepushoptin],
		[post_mobilepushpayloadid] AS [adobe_post_mobilepushpayloadid],
		[post_mobileresolution] AS [adobe_post_mobileresolution],
		[post_mvvar1] AS [adobe_post_mvvar1],
		[post_mvvar2] AS [adobe_post_mvvar2],
		[post_mvvar3] AS [adobe_post_mvvar3],
		[post_page_event] AS [adobe_post_page_event],
		[post_page_event_var1] AS [adobe_post_page_event_var1],
		[post_page_event_var2] AS [adobe_post_page_event_var2],
		[post_page_event_var3] AS [adobe_post_page_event_var3],
		[post_page_type] AS [adobe_post_page_type],
		[post_page_url] AS [adobe_post_page_url],
		[post_pagename] AS [adobe_post_pagename],
		[post_pagename_no_url] AS [adobe_post_pagename_no_url],
		[post_partner_plugins] AS [adobe_post_partner_plugins],
		[post_persistent_cookie] AS [adobe_post_persistent_cookie],
		[post_pointofinterest] AS [adobe_post_pointofinterest],
		[post_pointofinterestdistance] AS [adobe_post_pointofinterestdistance],
		[post_product_list] AS [adobe_post_product_list],
		[post_prop1] AS [adobe_post_prop1],
		[post_prop2] AS [adobe_post_prop2],
		[post_prop3] AS [adobe_post_prop3],
		[post_prop4] AS [adobe_post_prop4],
		[post_prop5] AS [adobe_post_prop5],
		[post_prop6] AS [adobe_post_prop6],
		[post_prop7] AS [adobe_post_prop7],
		[post_prop8] AS [adobe_post_prop8],
		[post_prop9] AS [adobe_post_prop9],
		[post_prop10] AS [adobe_post_prop10],
		[post_prop11] AS [adobe_post_prop11],
		[post_prop12] AS [adobe_post_prop12],
		[post_prop13] AS [adobe_post_prop13],
		[post_prop14] AS [adobe_post_prop14],
		[post_prop15] AS [adobe_post_prop15],
		[post_prop16] AS [adobe_post_prop16],
		[post_prop17] AS [adobe_post_prop17],
		[post_prop18] AS [adobe_post_prop18],
		[post_prop19] AS [adobe_post_prop19],
		[post_prop20] AS [adobe_post_prop20],
		[post_prop21] AS [adobe_post_prop21],
		[post_prop22] AS [adobe_post_prop22],
		[post_prop23] AS [adobe_post_prop23],
		[post_prop24] AS [adobe_post_prop24],
		[post_prop25] AS [adobe_post_prop25],
		[post_prop26] AS [adobe_post_prop26],
		[post_prop27] AS [adobe_post_prop27],
		[post_prop28] AS [adobe_post_prop28],
		[post_prop29] AS [adobe_post_prop29],
		[post_prop30] AS [adobe_post_prop30],
		[post_prop31] AS [adobe_post_prop31],
		[post_prop32] AS [adobe_post_prop32],
		[post_prop33] AS [adobe_post_prop33],
		[post_prop34] AS [adobe_post_prop34],
		[post_prop35] AS [adobe_post_prop35],
		[post_prop36] AS [adobe_post_prop36],
		[post_prop37] AS [adobe_post_prop37],
		[post_prop38] AS [adobe_post_prop38],
		[post_prop39] AS [adobe_post_prop39],
		[post_prop40] AS [adobe_post_prop40],
		[post_prop41] AS [adobe_post_prop41],
		[post_prop42] AS [adobe_post_prop42],
		[post_prop43] AS [adobe_post_prop43],
		[post_prop44] AS [adobe_post_prop44],
		[post_prop45] AS [adobe_post_prop45],
		[post_prop46] AS [adobe_post_prop46],
		[post_prop47] AS [adobe_post_prop47],
		[post_prop48] AS [adobe_post_prop48],
		[post_prop49] AS [adobe_post_prop49],
		[post_prop50] AS [adobe_post_prop50],
		[post_prop51] AS [adobe_post_prop51],
		[post_prop52] AS [adobe_post_prop52],
		[post_prop53] AS [adobe_post_prop53],
		[post_prop54] AS [adobe_post_prop54],
		[post_prop55] AS [adobe_post_prop55],
		[post_prop56] AS [adobe_post_prop56],
		[post_prop57] AS [adobe_post_prop57],
		[post_prop58] AS [adobe_post_prop58],
		[post_prop59] AS [adobe_post_prop59],
		[post_prop60] AS [adobe_post_prop60],
		[post_prop61] AS [adobe_post_prop61],
		[post_prop62] AS [adobe_post_prop62],
		[post_prop63] AS [adobe_post_prop63],
		[post_prop64] AS [adobe_post_prop64],
		[post_prop65] AS [adobe_post_prop65],
		[post_prop66] AS [adobe_post_prop66],
		[post_prop67] AS [adobe_post_prop67],
		[post_prop68] AS [adobe_post_prop68],
		[post_prop69] AS [adobe_post_prop69],
		[post_prop70] AS [adobe_post_prop70],
		[post_prop71] AS [adobe_post_prop71],
		[post_prop72] AS [adobe_post_prop72],
		[post_prop73] AS [adobe_post_prop73],
		[post_prop74] AS [adobe_post_prop74],
		[post_prop75] AS [adobe_post_prop75],
		[post_purchaseid] AS [adobe_post_purchaseid],
		[post_referrer] AS [adobe_post_referrer],
		[post_s_kwcid] AS [adobe_post_s_kwcid],
		[post_search_engine] AS [adobe_post_search_engine],
		[post_socialaccountandappids] AS [adobe_post_socialaccountandappids],
		[post_socialassettrackingcode] AS [adobe_post_socialassettrackingcode],
		[post_socialauthor] AS [adobe_post_socialauthor],
		[post_socialcontentprovider] AS [adobe_post_socialcontentprovider],
		[post_socialfbstories] AS [adobe_post_socialfbstories],
		[post_socialfbstorytellers] AS [adobe_post_socialfbstorytellers],
		[post_socialinteractioncount] AS [adobe_post_socialinteractioncount],
		[post_socialinteractiontype] AS [adobe_post_socialinteractiontype],
		[post_sociallanguage] AS [adobe_post_sociallanguage],
		[post_sociallatlong] AS [adobe_post_sociallatlong],
		[post_sociallikeadds] AS [adobe_post_sociallikeadds],
		[post_socialmentions] AS [adobe_post_socialmentions],
		[post_socialowneddefinitioninsighttype] AS [adobe_post_socialowneddefinitioninsighttype],
		[post_socialowneddefinitioninsightvalue] AS [adobe_post_socialowneddefinitioninsightvalue],
		[post_socialowneddefinitionmetric] AS [adobe_post_socialowneddefinitionmetric],
		[post_socialowneddefinitionpropertyvspost] AS [adobe_post_socialowneddefinitionpropertyvspost],
		[post_socialownedpostids] AS [adobe_post_socialownedpostids],
		[post_socialownedpropertyid] AS [adobe_post_socialownedpropertyid],
		[post_socialownedpropertyname] AS [adobe_post_socialownedpropertyname],
		[post_socialownedpropertypropertyvsapp] AS [adobe_post_socialownedpropertypropertyvsapp],
		[post_socialpageviews] AS [adobe_post_socialpageviews],
		[post_socialpostviews] AS [adobe_post_socialpostviews],
		[post_socialpubcomments] AS [adobe_post_socialpubcomments],
		[post_socialpubposts] AS [adobe_post_socialpubposts],
		[post_socialpubrecommends] AS [adobe_post_socialpubrecommends],
		[post_socialpubsubscribers] AS [adobe_post_socialpubsubscribers],
		[post_socialterm] AS [adobe_post_socialterm],
		[post_socialtotalsentiment] AS [adobe_post_socialtotalsentiment],
		[post_state] AS [adobe_post_state],
		[post_survey] AS [adobe_post_survey],
		[post_t_time_info] AS [adobe_post_t_time_info],
		[post_tnt] AS [adobe_post_tnt],
		[post_tnt_action] AS [adobe_post_tnt_action],
		[post_transactionid] AS [adobe_post_transactionid],
		[post_video] AS [adobe_post_video],
		[post_videoad] AS [adobe_post_videoad],
		[post_videoadinpod] AS [adobe_post_videoadinpod],
		[post_videoadplayername] AS [adobe_post_videoadplayername],
		[post_videoadpod] AS [adobe_post_videoadpod],
		[post_videochannel] AS [adobe_post_videochannel],
		[post_videochapter] AS [adobe_post_videochapter],
		[post_videocontenttype] AS [adobe_post_videocontenttype],
		[post_videoplayername] AS [adobe_post_videoplayername],
		[post_videoqoebitrateaverageevar] AS [adobe_post_videoqoebitrateaverageevar],
		[post_videoqoebitratechangecountevar] AS [adobe_post_videoqoebitratechangecountevar],
		[post_videoqoebuffercountevar] AS [adobe_post_videoqoebuffercountevar],
		[post_videoqoebuffertimeevar] AS [adobe_post_videoqoebuffertimeevar],
		[post_videoqoedroppedframecountevar] AS [adobe_post_videoqoedroppedframecountevar],
		[post_videoqoeerrorcountevar] AS [adobe_post_videoqoeerrorcountevar],
		[post_videoqoetimetostartevar] AS [adobe_post_videoqoetimetostartevar],
		[post_videosegment] AS [adobe_post_videosegment],
		[post_visid_high] AS [adobe_post_visid_high],
		[post_visid_low] AS [adobe_post_visid_low],
		[post_visid_type] AS [adobe_post_visid_type],
		[post_zip] AS [adobe_post_zip],
		[prev_page] AS [adobe_prev_page],
		[product_list] AS [adobe_product_list],
		[product_merchandising] AS [adobe_product_merchandising],
		[prop1] AS [adobe_prop1],
		[prop2] AS [adobe_prop2],
		[prop3] AS [adobe_prop3],
		[prop4] AS [adobe_prop4],
		[prop5] AS [adobe_prop5],
		[prop6] AS [adobe_prop6],
		[prop7] AS [adobe_prop7],
		[prop8] AS [adobe_prop8],
		[prop9] AS [adobe_prop9],
		[prop10] AS [adobe_prop10],
		[prop11] AS [adobe_prop11],
		[prop12] AS [adobe_prop12],
		[prop13] AS [adobe_prop13],
		[prop14] AS [adobe_prop14],
		[prop15] AS [adobe_prop15],
		[prop16] AS [adobe_prop16],
		[prop17] AS [adobe_prop17],
		[prop18] AS [adobe_prop18],
		[prop19] AS [adobe_prop19],
		[prop20] AS [adobe_prop20],
		[prop21] AS [adobe_prop21],
		[prop22] AS [adobe_prop22],
		[prop23] AS [adobe_prop23],
		[prop24] AS [adobe_prop24],
		[prop25] AS [adobe_prop25],
		[prop26] AS [adobe_prop26],
		[prop27] AS [adobe_prop27],
		[prop28] AS [adobe_prop28],
		[prop29] AS [adobe_prop29],
		[prop30] AS [adobe_prop30],
		[prop31] AS [adobe_prop31],
		[prop32] AS [adobe_prop32],
		[prop33] AS [adobe_prop33],
		[prop34] AS [adobe_prop34],
		[prop35] AS [adobe_prop35],
		[prop36] AS [adobe_prop36],
		[prop37] AS [adobe_prop37],
		[prop38] AS [adobe_prop38],
		[prop39] AS [adobe_prop39],
		[prop40] AS [adobe_prop40],
		[prop41] AS [adobe_prop41],
		[prop42] AS [adobe_prop42],
		[prop43] AS [adobe_prop43],
		[prop44] AS [adobe_prop44],
		[prop45] AS [adobe_prop45],
		[prop46] AS [adobe_prop46],
		[prop47] AS [adobe_prop47],
		[prop48] AS [adobe_prop48],
		[prop49] AS [adobe_prop49],
		[prop50] AS [adobe_prop50],
		[prop51] AS [adobe_prop51],
		[prop52] AS [adobe_prop52],
		[prop53] AS [adobe_prop53],
		[prop54] AS [adobe_prop54],
		[prop55] AS [adobe_prop55],
		[prop56] AS [adobe_prop56],
		[prop57] AS [adobe_prop57],
		[prop58] AS [adobe_prop58],
		[prop59] AS [adobe_prop59],
		[prop60] AS [adobe_prop60],
		[prop61] AS [adobe_prop61],
		[prop62] AS [adobe_prop62],
		[prop63] AS [adobe_prop63],
		[prop64] AS [adobe_prop64],
		[prop65] AS [adobe_prop65],
		[prop66] AS [adobe_prop66],
		[prop67] AS [adobe_prop67],
		[prop68] AS [adobe_prop68],
		[prop69] AS [adobe_prop69],
		[prop70] AS [adobe_prop70],
		[prop71] AS [adobe_prop71],
		[prop72] AS [adobe_prop72],
		[prop73] AS [adobe_prop73],
		[prop74] AS [adobe_prop74],
		[prop75] AS [adobe_prop75],
		[purchaseid] AS [adobe_purchaseid],
		[quarterly_visitor] AS [adobe_quarterly_visitor],
		[ref_domain] AS [adobe_ref_domain],
		[ref_type] AS [adobe_ref_type],
		[referrer] AS [adobe_referrer],
		[resolution] AS [adobe_resolution],
		[s_kwcid] AS [adobe_s_kwcid],
		[s_resolution] AS [adobe_s_resolution],
		[sampled_hit] AS [adobe_sampled_hit],
		[search_engine] AS [adobe_search_engine],
		[search_page_num] AS [adobe_search_page_num],
		[secondary_hit] AS [adobe_secondary_hit],
		[service] AS [adobe_service],
		[socialaccountandappids] AS [adobe_socialaccountandappids],
		[socialassettrackingcode] AS [adobe_socialassettrackingcode],
		[socialauthor] AS [adobe_socialauthor],
		[socialcontentprovider] AS [adobe_socialcontentprovider],
		[socialfbstories] AS [adobe_socialfbstories],
		[socialfbstorytellers] AS [adobe_socialfbstorytellers],
		[socialinteractioncount] AS [adobe_socialinteractioncount],
		[socialinteractiontype] AS [adobe_socialinteractiontype],
		[sociallanguage] AS [adobe_sociallanguage],
		[sociallatlong] AS [adobe_sociallatlong],
		[sociallikeadds] AS [adobe_sociallikeadds],
		[socialmentions] AS [adobe_socialmentions],
		[socialowneddefinitioninsighttype] AS [adobe_socialowneddefinitioninsighttype],
		[socialowneddefinitioninsightvalue] AS [adobe_socialowneddefinitioninsightvalue],
		[socialowneddefinitionmetric] AS [adobe_socialowneddefinitionmetric],
		[socialowneddefinitionpropertyvspost] AS [adobe_socialowneddefinitionpropertyvspost],
		[socialownedpostids] AS [adobe_socialownedpostids],
		[socialownedpropertyid] AS [adobe_socialownedpropertyid],
		[socialownedpropertyname] AS [adobe_socialownedpropertyname],
		[socialownedpropertypropertyvsapp] AS [adobe_socialownedpropertypropertyvsapp],
		[socialpageviews] AS [adobe_socialpageviews],
		[socialpostviews] AS [adobe_socialpostviews],
		[socialpubcomments] AS [adobe_socialpubcomments],
		[socialpubposts] AS [adobe_socialpubposts],
		[socialpubrecommends] AS [adobe_socialpubrecommends],
		[socialpubsubscribers] AS [adobe_socialpubsubscribers],
		[socialterm] AS [adobe_socialterm],
		[socialtotalsentiment] AS [adobe_socialtotalsentiment],
		[sourceid] AS [adobe_sourceid],
		[state] AS [adobe_state],
		[stats_server] AS [adobe_stats_server],
		[t_time_info] AS [adobe_t_time_info],
		[tnt] AS [adobe_tnt],
		[tnt_action] AS [adobe_tnt_action],
		[tnt_post_vista] AS [adobe_tnt_post_vista],
		[transactionid] AS [adobe_transactionid],
		[truncated_hit] AS [adobe_truncated_hit],
		[ua_color] AS [adobe_ua_color],
		[ua_os] AS [adobe_ua_os],
		[ua_pixels] AS [adobe_ua_pixels],
		[user_agent] AS [adobe_user_agent],
		[user_hash] AS [adobe_user_hash],
		[user_server] AS [adobe_user_server],
		[userid] AS [adobe_userid],
		[username] AS [adobe_username],
		[va_closer_detail] AS [adobe_va_closer_detail],
		[va_closer_id] AS [adobe_va_closer_id],
		[va_finder_detail] AS [adobe_va_finder_detail],
		[va_finder_id] AS [adobe_va_finder_id],
		[va_instance_event] AS [adobe_va_instance_event],
		[va_new_engagement] AS [adobe_va_new_engagement],
		[video] AS [adobe_video],
		[videoad] AS [adobe_videoad],
		[videoadinpod] AS [adobe_videoadinpod],
		[videoadplayername] AS [adobe_videoadplayername],
		[videoadpod] AS [adobe_videoadpod],
		[videochannel] AS [adobe_videochannel],
		[videochapter] AS [adobe_videochapter],
		[videocontenttype] AS [adobe_videocontenttype],
		[videoplayername] AS [adobe_videoplayername],
		[videoqoebitrateaverageevar] AS [adobe_videoqoebitrateaverageevar],
		[videoqoebitratechangecountevar] AS [adobe_videoqoebitratechangecountevar],
		[videoqoebuffercountevar] AS [adobe_videoqoebuffercountevar],
		[videoqoebuffertimeevar] AS [adobe_videoqoebuffertimeevar],
		[videoqoedroppedframecountevar] AS [adobe_videoqoedroppedframecountevar],
		[videoqoeerrorcountevar] AS [adobe_videoqoeerrorcountevar],
		[videoqoetimetostartevar] AS [adobe_videoqoetimetostartevar],
		[videosegment] AS [adobe_videosegment],
		[visid_high] AS [adobe_visid_high],
		[visid_low] AS [adobe_visid_low],
		[visid_new] AS [adobe_visid_new],
		[visid_timestamp] AS [adobe_visid_timestamp],
		[visid_type] AS [adobe_visid_type],
		[visit_keywords] AS [adobe_visit_keywords],
		[visit_num] AS [adobe_visit_num],
		[visit_page_num] AS [adobe_visit_page_num],
		[visit_referrer] AS [adobe_visit_referrer],
		[visit_search_engine] AS [adobe_visit_search_engine],
		[visit_start_page_url] AS [adobe_visit_start_page_url],
		[visit_start_pagename] AS [adobe_visit_start_pagename],
		[visit_start_time_gmt] AS [adobe_visit_start_time_gmt],
		[weekly_visitor] AS [adobe_weekly_visitor],
		[yearly_visitor] AS [adobe_yearly_visitor],
		[zip] AS [adobe_zip]
	FROM #temp_table_adobe;
	
	
	INSERT INTO #temp_table_events_except_customers ([EVENT_TIME], [EVENT_TYPE], [orders_ORDDATE], [orders_ACCTNO], [orders_INDID], [orders_HHID], [orders_ADDID], [orders_COMPID], [orders_STORENO], [orders_ORDALTLOC], [orders_ORDERTYPE], [orders_ORDNO], [orders_ORDSOURCE], [orders_SOURCETYPE], [orders_ORDCHANNEL], [orders_ORDSUBCHAN], [orders_ORDQTY], [orders_ORDGROSDOL], [orders_ORDRTNDOL], [orders_FILENAME], [orders_SEQ], [orders_FILEDATE], [orders_INSERTDATE])
	SELECT [ORDDATE] AS [EVENT_TIME],
		'orders',
		[ORDDATE] AS [orders_ORDDATE],
		[ACCTNO] AS [orders_ACCTNO],
		[INDID] AS [orders_INDID],
		[HHID] AS [orders_HHID],
		[ADDID] AS [orders_ADDID],
		[COMPID] AS [orders_COMPID],
		[STORENO] AS [orders_STORENO],
		[ORDALTLOC] AS [orders_ORDALTLOC],
		[ORDERTYPE] AS [orders_ORDERTYPE],
		[ORDNO] AS [orders_ORDNO],
		[ORDSOURCE] AS [orders_ORDSOURCE],
		[SOURCETYPE] AS [orders_SOURCETYPE],
		[ORDCHANNEL] AS [orders_ORDCHANNEL],
		[ORDSUBCHAN] AS [orders_ORDSUBCHAN],
		[ORDQTY] AS [orders_ORDQTY],
		[ORDGROSDOL] AS [orders_ORDGROSDOL],
		[ORDRTNDOL] AS [orders_ORDRTNDOL],
		[FILENAME] AS [orders_FILENAME],
		[SEQ] AS [orders_SEQ],
		[FILEDATE] AS [orders_FILEDATE],
		[INSERTDATE] AS [orders_INSERTDATE]
	FROM #temp_table_orders;
	
	
	INSERT INTO #temp_table_events_except_customers ([EVENT_TIME], [EVENT_TYPE], [items_ACCTNO], [items_INDID], [items_HHID], [items_ADDID], [items_COMPID], [items_COUNTRYFLG], [items_CATALOG], [items_ITMCHANNEL], [items_DEPT], [items_DEPT_DESC], [items_DEPTRFS], [items_DSCNTCODE], [items_DSCNTTYPE], [items_INITIALDTE], [items_ITEMNO], [items_ITMDATE], [items_LINENUM], [items_ORDERTYPE], [items_ITEMORDNO], [items_ORIGLINENO], [items_ORIGORDNO], [items_ORIGSHIPTO], [items_PAGENUM], [items_DEMANDFLAG], [items_RETURNFLAG], [items_RECORDTYPE], [items_RETAILAMT], [items_ITMGROSDOL], [items_ITMGROSRTN], [items_RETREASON], [items_SEQNO], [items_SIZE], [items_SIZE_DESC], [items_COLOR], [items_COLOR_DESC], [items_STYLE], [items_STYLE_DESC], [items_SKU], [items_ITMSTORENO], [items_ITMSUBCHAN], [items_TRANSNO], [items_TRANSTYPE], [items_ITMALTLOC], [items_MERCHCNCPT], [items_RETURNNO], [items_SOURCECODE], [items_ORGPRICE], [items_DISCNTAMT], [items_FILENAME], [items_SEQ], [items_FILEDATE], [items_INSERTDATE])
	SELECT [INSERTDATE] AS [EVENT_TIME],
	'items',
	[ACCTNO] AS [items_ACCTNO],
	[INDID] AS [items_INDID],
	[HHID] AS [items_HHID],
	[ADDID] AS [items_ADDID],
	[COMPID] AS [items_COMPID],
	[COUNTRYFLG] AS [items_COUNTRYFLG],
	[CATALOG] AS [items_CATALOG],
	[ITMCHANNEL] AS [items_ITMCHANNEL],
	[DEPT] AS [items_DEPT],
	[DEPT_DESC] AS [items_DEPT_DESC],
	[DEPTRFS] AS [items_DEPTRFS],
	[DSCNTCODE] AS [items_DSCNTCODE],
	[DSCNTTYPE] AS [items_DSCNTTYPE],
	[INITIALDTE] AS [items_INITIALDTE],
	[ITEMNO] AS [items_ITEMNO],
	[ITMDATE] AS [items_ITMDATE],
	[LINENUM] AS [items_LINENUM],
	[ORDERTYPE] AS [items_ORDERTYPE],
	[ITEMORDNO] AS [items_ITEMORDNO],
	[ORIGLINENO] AS [items_ORIGLINENO],
	[ORIGORDNO] AS [items_ORIGORDNO],
	[ORIGSHIPTO] AS [items_ORIGSHIPTO],
	[PAGENUM] AS [items_PAGENUM],
	[DEMANDFLAG] AS [items_DEMANDFLAG],
	[RETURNFLAG] AS [items_RETURNFLAG],
	[RECORDTYPE] AS [items_RECORDTYPE],
	[RETAILAMT] AS [items_RETAILAMT],
	[ITMGROSDOL] AS [items_ITMGROSDOL],
	[ITMGROSRTN] AS [items_ITMGROSRTN],
	[RETREASON] AS [items_RETREASON],
	[SEQNO] AS [items_SEQNO],
	[SIZE] AS [items_SIZE],
	[SIZE_DESC] AS [items_SIZE_DESC],
	[COLOR] AS [items_COLOR],
	[COLOR_DESC] AS [items_COLOR_DESC],
	[STYLE] AS [items_STYLE],
	[STYLE_DESC] AS [items_STYLE_DESC],
	[SKU] AS [items_SKU],
	[ITMSTORENO] AS [items_ITMSTORENO],
	[ITMSUBCHAN] AS [items_ITMSUBCHAN],
	[TRANSNO] AS [items_TRANSNO],
	[TRANSTYPE] AS [items_TRANSTYPE],
	[ITMALTLOC] AS [items_ITMALTLOC],
	[MERCHCNCPT] AS [items_MERCHCNCPT],
	[RETURNNO] AS [items_RETURNNO],
	[SOURCECODE] AS [items_SOURCECODE],
	[ORGPRICE] AS [items_ORGPRICE],
	[DISCNTAMT] AS [items_DISCNTAMT],
	[FILENAME] AS [items_FILENAME],
	[SEQ] AS [items_SEQ],
	[FILEDATE] AS [items_FILEDATE],
	[INSERTDATE] AS [items_INSERTDATE]
	FROM #temp_table_items;
	
	
	INSERT INTO #temp_table_events_except_customers ([EVENT_TIME], [EVENT_TYPE], [interactions_INTTYPE], [interactions_INTSOURCE], [interactions_EMAIL], [interactions_ACCTNO], [interactions_INDID], [interactions_HHID], [interactions_ADDRID], [interactions_FNAME], [interactions_LNAME], [interactions_INTDATE], [interactions_DNEFLAG], [interactions_EMAILSTORE], [interactions_EMAILPREF], [interactions_FILENAME], [interactions_SEQ], [interactions_FILEDATE], [interactions_MODDATE])
	SELECT [INTDATE] AS [EVENT_TIME],
		'interactions',
		[INTTYPE] AS [interactions_INTTYPE],
		[INTSOURCE] AS [interactions_INTSOURCE],
		[EMAIL] AS [interactions_EMAIL],
		[ACCTNO] AS [interactions_ACCTNO],
		[INDID] AS [interactions_INDID],
		[HHID] AS [interactions_HHID],
		[ADDRID] AS [interactions_ADDRID],
		[FNAME] AS [interactions_FNAME],
		[LNAME] AS [interactions_LNAME],
		[INTDATE] AS [interactions_INTDATE],
		[DNEFLAG] AS [interactions_DNEFLAG],
		[EMAILSTORE] AS [interactions_EMAILSTORE],
		[EMAILPREF] AS [interactions_EMAILPREF],
		[FILENAME] AS [interactions_FILENAME],
		[SEQ] AS [interactions_SEQ],
		[FILEDATE] AS [interactions_FILEDATE],
		[MODDATE] AS [interactions_MODDATE]
	FROM #temp_table_interactions;
	
	
	INSERT INTO #temp_table_events_except_customers ([EVENT_TIME], [EVENT_TYPE], [promotions_ACCTNO], [promotions_INDID], [promotions_HHID], [promotions_ADDID], [promotions_COMPID], [promotions_INHOME], [promotions_CIRCNAME], [promotions_FNAME], [promotions_LNAME], [promotions_COMPANY], [promotions_TITLE], [promotions_ADD1], [promotions_ADD2], [promotions_CITY], [promotions_STATE], [promotions_ZIP], [promotions_EMAIL], [promotions_PHONE], [promotions_PLUS4], [promotions_PRINUM], [promotions_STREET], [promotions_UNITNUM], [promotions_FNAMEKEY], [promotions_LNAMEKEY], [promotions_COMPKEY], [promotions_STREETKEY], [promotions_ADSUFFIX], [promotions_ADDTYPE], [promotions_CRRT], [promotions_CASSCODE], [promotions_CKDIGIT], [promotions_CNTRYCODE], [promotions_CNTYCODE], [promotions_CNTYNAME], [promotions_DELPT], [promotions_DPV], [promotions_DPVFTNOTE], [promotions_DPV_VACANT], [promotions_LACSINDC], [promotions_LOT], [promotions_LOTORDER], [promotions_DPVNOSTAT], [promotions_POSDIR], [promotions_PREDIR], [promotions_UNITTYPE], [promotions_GENDER], [promotions_PROMTYPE], [promotions_MAILKEY], [promotions_LISTDESC], [promotions_STRING], [promotions_DEMO], [promotions_HOLDOUT], [promotions_CIRCID], [promotions_ORG_INDID], [promotions_ORG_HHID], [promotions_ORG_ADDID], [promotions_ORG_COMPID])
	SELECT [INHOME] AS [EVENT_TIME],
		'promotions',
		[ACCTNO] AS [promotions_ACCTNO],
		[INDID] AS [promotions_INDID],
		[HHID] AS [promotions_HHID],
		[ADDID] AS [promotions_ADDID],
		[COMPID] AS [promotions_COMPID],
		[INHOME] AS [promotions_INHOME],
		[CIRCNAME] AS [promotions_CIRCNAME],
		[FNAME] AS [promotions_FNAME],
		[LNAME] AS [promotions_LNAME],
		[COMPANY] AS [promotions_COMPANY],
		[TITLE] AS [promotions_TITLE],
		[ADD1] AS [promotions_ADD1],
		[ADD2] AS [promotions_ADD2],
		[CITY] AS [promotions_CITY],
		[STATE] AS [promotions_STATE],
		[ZIP] AS [promotions_ZIP],
		[EMAIL] AS [promotions_EMAIL],
		[PHONE] AS [promotions_PHONE],
		[PLUS4] AS [promotions_PLUS4],
		[PRINUM] AS [promotions_PRINUM],
		[STREET] AS [promotions_STREET],
		[UNITNUM] AS [promotions_UNITNUM],
		[FNAMEKEY] AS [promotions_FNAMEKEY],
		[LNAMEKEY] AS [promotions_LNAMEKEY],
		[COMPKEY] AS [promotions_COMPKEY],
		[STREETKEY] AS [promotions_STREETKEY],
		[ADSUFFIX] AS [promotions_ADSUFFIX],
		[ADDTYPE] AS [promotions_ADDTYPE],
		[CRRT] AS [promotions_CRRT],
		[CASSCODE] AS [promotions_CASSCODE],
		[CKDIGIT] AS [promotions_CKDIGIT],
		[CNTRYCODE] AS [promotions_CNTRYCODE],
		[CNTYCODE] AS [promotions_CNTYCODE],
		[CNTYNAME] AS [promotions_CNTYNAME],
		[DELPT] AS [promotions_DELPT],
		[DPV] AS [promotions_DPV],
		[DPVFTNOTE] AS [promotions_DPVFTNOTE],
		[DPV_VACANT] AS [promotions_DPV_VACANT],
		[LACSINDC] AS [promotions_LACSINDC],
		[LOT] AS [promotions_LOT],
		[LOTORDER] AS [promotions_LOTORDER],
		[DPVNOSTAT] AS [promotions_DPVNOSTAT],
		[POSDIR] AS [promotions_POSDIR],
		[PREDIR] AS [promotions_PREDIR],
		[UNITTYPE] AS [promotions_UNITTYPE],
		[GENDER] AS [promotions_GENDER],
		[PROMTYPE] AS [promotions_PROMTYPE],
		[MAILKEY] AS [promotions_MAILKEY],
		[LISTDESC] AS [promotions_LISTDESC],
		[STRING] AS [promotions_STRING],
		[DEMO] AS [promotions_DEMO],
		[HOLDOUT] AS [promotions_HOLDOUT],
		[CIRCID] AS [promotions_CIRCID],
		[ORG_INDID] AS [promotions_ORG_INDID],
		[ORG_HHID] AS [promotions_ORG_HHID],
		[ORG_ADDID] AS [promotions_ORG_ADDID],
		[ORG_COMPID] AS [promotions_ORG_COMPID]
	FROM #temp_table_promotions;
	
	
	INSERT INTO #temp_table_events_except_customers ([EVENT_TIME], [EVENT_TYPE], [email_activities_EMAILTYPE], [email_activities_INTSOURCE], [email_activities_EMAIL], [email_activities_ACCTNO], [email_activities_FNAME], [email_activities_LNAME], [email_activities_EMAILDATE], [email_activities_DNEFLAG], [email_activities_EMAILSTORE], [email_activities_EMAILPREF], [email_activities_FILENAME], [email_activities_SEQ], [email_activities_FILEDATE], [email_activities_MODDATE], [email_activities_IPADDRESS])
	SELECT [EMAILDATE] AS [EVENT_TIME],
		'email_activities',
		[EMAILTYPE] AS [email_activities_EMAILTYPE],
		[INTSOURCE] AS [email_activities_INTSOURCE],
		[EMAIL] AS [email_activities_EMAIL],
		[ACCTNO] AS [email_activities_ACCTNO],
		[FNAME] AS [email_activities_FNAME],
		[LNAME] AS [email_activities_LNAME],
		[EMAILDATE] AS [email_activities_EMAILDATE],
		[DNEFLAG] AS [email_activities_DNEFLAG],
		[EMAILSTORE] AS [email_activities_EMAILSTORE],
		[EMAILPREF] AS [email_activities_EMAILPREF],
		[FILENAME] AS [email_activities_FILENAME],
		[SEQ] AS [email_activities_SEQ],
		[FILEDATE] AS [email_activities_FILEDATE],
		[MODDATE] AS [email_activities_MODDATE],
		[IPADDRESS] AS [email_activities_IPADDRESS]
	FROM #temp_table_email_activities;
	
	
	INSERT INTO #temp_table_events_except_customers ([EVENT_TIME], [EVENT_TYPE], [email_promotions_ACCTNO], [email_promotions_INDID], [email_promotions_HHID], [email_promotions_ADDRID], [email_promotions_FNAME], [email_promotions_LNAME], [email_promotions_ADD1], [email_promotions_ADD2], [email_promotions_CITY], [email_promotions_STATE], [email_promotions_ZIP], [email_promotions_ZIP4], [email_promotions_COUNTRY], [email_promotions_EMAIL], [email_promotions_MAILABLE], [email_promotions_DNRFLAG], [email_promotions_DNEFLAG], [email_promotions_EMAILFLAG], [email_promotions_BDAY], [email_promotions_INHOME], [email_promotions_CIRCNAME], [email_promotions_CIRCDESC], [email_promotions_PROMTYPE], [email_promotions_MAILKEY], [email_promotions_LISTDESC], [email_promotions_LDATE], [email_promotions_OFFERDESCRIPTION], [email_promotions_CAMPAIGNID], [email_promotions_CAMPAIGNTYPE], [email_promotions_FILEDATE])
	SELECT [INHOME] AS [EVENT_TIME],
		'email_promotions',
		[ACCTNO] AS [email_promotions_ACCTNO],
		[INDID] AS [email_promotions_INDID],
		[HHID] AS [email_promotions_HHID],
		[ADDRID] AS [email_promotions_ADDRID],
		[FNAME] AS [email_promotions_FNAME],
		[LNAME] AS [email_promotions_LNAME],
		[ADD1] AS [email_promotions_ADD1],
		[ADD2] AS [email_promotions_ADD2],
		[CITY] AS [email_promotions_CITY],
		[STATE] AS [email_promotions_STATE],
		[ZIP] AS [email_promotions_ZIP],
		[ZIP4] AS [email_promotions_ZIP4],
		[COUNTRY] AS [email_promotions_COUNTRY],
		[EMAIL] AS [email_promotions_EMAIL],
		[MAILABLE] AS [email_promotions_MAILABLE],
		[DNRFLAG] AS [email_promotions_DNRFLAG],
		[DNEFLAG] AS [email_promotions_DNEFLAG],
		[EMAILFLAG] AS [email_promotions_EMAILFLAG],
		[BDAY] AS [email_promotions_BDAY],
		[INHOME] AS [email_promotions_INHOME],
		[CIRCNAME] AS [email_promotions_CIRCNAME],
		[CIRCDESC] AS [email_promotions_CIRCDESC],
		[PROMTYPE] AS [email_promotions_PROMTYPE],
		[MAILKEY] AS [email_promotions_MAILKEY],
		[LISTDESC] AS [email_promotions_LISTDESC],
		[LDATE] AS [email_promotions_LDATE],
		[OFFERDESCRIPTION] AS [email_promotions_OFFERDESCRIPTION],
		[CAMPAIGNID] AS [email_promotions_CAMPAIGNID],
		[CAMPAIGNTYPE] AS [email_promotions_CAMPAIGNTYPE],
		[FILEDATE] AS [email_promotions_FILEDATE]
	FROM #temp_table_email_promotions;


	-- If we've gotten this far, time to drop the old table, and rename the existing table to TIMELINES_OLD
	IF OBJECT_ID('CD_BI..TIMELINES') IS NOT NULL
	BEGIN
		IF OBJECT_ID('CD_BI..TIMELINES_OLD') IS NOT NULL
		BEGIN
			DROP TABLE IF EXISTS [CD_BI].[dbo].[TIMELINES_OLD];
		END; 
		EXEC sp_rename 'TIMELINES', 'TIMELINES_OLD';
	END; 
	
	-- enrich the events with customer data
	SELECT * INTO [CD_BI].[dbo].[TIMELINES_NEW]
	FROM #temp_table_customers c, #temp_table_events_except_customers e
	WHERE c.INDID = e.[orders_INDID]
		or c.indid = e.[items_INDID]
		or c.indid = e.[interactions_INDID]
		or c.email = e.[interactions_EMAIL]
		or c.indid = e.[promotions_INDID]
		or c.email = e.[promotions_EMAIL]
		or c.EMAIL = e.[email_activities_EMAIL]
		or c.EMAIL = e.[email_promotions_EMAIL]
		or e.[adobe_evar21] = c.[EMAIL];

	

	IF OBJECT_ID('CD_BI..TIMELINES_NEW') IS NOT NULL
	BEGIN
		EXEC sp_rename 'TIMELINES_NEW', 'TIMELINES';
	END; 

	-- Ticket doesn't specify to remove TIMELINES_OLD so keeping it around...
	COMMIT TRANSACTION INS1;

	SELECT @CURRENTTIME = getdate()  --take start time of table
	
	EXECUTE [CD_ADMIN].[dbo].[INSERT_RUN_LOG] @LOGID = @LOGID_SP, @ENDTIME =@CURRENTTIME  ,@STATUS = 'Completed' ,@ROWS_AFFECTED = null, @ID = @LOGID_SP  OUTPUT
	--END OF INSERT INTO SP

	END TRY

	BEGIN CATCH
	DECLARE @allerrors AS VARCHAR(500)=(SELECT CONCAT(ERROR_MESSAGE(), CHAR(13),
		'Error Number: ',ERROR_NUMBER(),CHAR(13),
		'Error Severity: ',ERROR_SEVERITY(),CHAR(13),
		'Error State: ',ERROR_STATE(),CHAR(13),
		'Error Proc: ',ERROR_PROCEDURE(),CHAR(13),
		'Error Line: ',ERROR_LINE()));
	DECLARE @ErrorSeverity INT;
	SELECT @ErrorSeverity = ERROR_SEVERITY() 
	DECLARE @ErrorState INT; 
	SELECT @ErrorState = ERROR_STATE()
	RAISERROR(@allerrors, --Message Text,
			@ErrorSeverity, -- Severity,
			@ErrorState, --State,
			N'number', --First argument,
			5); --Second argument.
		ROLLBACK TRANSACTION

	SELECT @CURRENTTIME = getdate() --take start time of table

	EXECUTE [CD_ADMIN].[dbo].[INSERT_RUN_LOG] @LOGID = @LOGID_SP, @ENDTIME = @CURRENTTIME, @STATUS = 'Failed', @ROWS_AFFECTED = null, @ID = @LOGID_SP OUTPUT --END of INSERT INTO SP

	END CATCH

END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CUSTOMERS_HHID_BUILD_BI]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CUSTOMERS_HHID_BUILD_BI] AS' 
END
GO

ALTER PROCEDURE [dbo].[CUSTOMERS_HHID_BUILD_BI] @RUNID NVARCHAR(100) = NULL
AS
BEGIN
--*****************************CHANGE_LOG*****************************
----------------------------------------------------------------------
--DATE			:	10/22/2019
--MODIFIED_BY	:	Ruchiagarwal3
--CHANGE		:	Added Catch Block
----------------------------------------------------------------------
--CREATED_DATE	:
--DESCRIPTION	:
----------------------------------------------------------------------
SET XACT_ABORT ON
DECLARE @LOGID_TBL int,
			@LOGID_SP int,
			@SP_TABLE_NAME_1 varchar(50) = OBJECT_NAME(@@PROCID),
			@DBNAME_1 varchar(50) = OBJECT_SCHEMA_NAME(@@PROCID),
			@CURRENTTIME DATETIME,
			@SCHEMANAME_1 varchar(50)= DB_NAME(),
			@RUNID_V NVARCHAR(100) = 1

	IF @RUNID IS NOT NULL
		SET @RUNID_V = @RUNID

	--START OF INSERT INTO SP
	SELECT @CURRENTTIME = getdate()

    EXECUTE [CD_ADMIN].[dbo].[INSERT_RUN_LOG]
    @RUNID =@RUNID_V ,@DBNAME = @DBNAME_1  ,@SCHEMANAME = @SCHEMANAME_1 ,@OBJECTTYPE ='SP' ,@OBJECTNAME = @SP_TABLE_NAME_1
    ,@STARTTIME =@CURRENTTIME ,@ENDTIME =null  ,@STATUS = 'In Progress' ,@ROWS_AFFECTED = '0', @ID = @LOGID_SP  OUTPUT


--CHECK IF TABLE EXISTS			
IF OBJECT_ID('CD_BI.dbo.CUSTOMERS_HHID') is not NULL --table exists			
	BEGIN			
	 DROP TABLE CD_BI.dbo.CUSTOMERS_HHID;			
	END		

--CREATE TABLE
CREATE TABLE [dbo].[CUSTOMERS_HHID](
	[ID] INT IDENTITY(1,1) PRIMARY KEY,
	[HHID] [VARCHAR](250) NULL,
	[INDID] [VARCHAR](250) NULL,
	[ADDID] [VARCHAR](250) NULL,
	[COMPID] [VARCHAR](250) NULL,
	[ACCTNO] [VARCHAR](50) NULL,
	[STATE] [VARCHAR](250) NULL,
	[ZIP] [VARCHAR](25) NULL,
	[CNTRYCODE] [VARCHAR](250) NULL,
	[EMAIL] [VARCHAR](250) NULL,
	[PHONE] [VARCHAR](25) NULL,
	[DNMFLAG] [VARCHAR](1) NOT NULL,
	[DNRFLAG] [VARCHAR](1) NOT NULL,
	[DNCFLAG] [VARCHAR](1) NOT NULL,
	[DNEFLAG] [VARCHAR](1) NOT NULL,
	[MAILABLE] [VARCHAR](1) NOT NULL,
	[EMAILFLAG] [VARCHAR](1) NOT NULL,
	[GENDER] [VARCHAR](250) NULL,
	[BDAY] [VARCHAR](25) NULL,
	[ODATE] [DATETIME] NULL,
	[LDATE] [DATETIME] NULL,
	[FREQ] [INT] NULL,
	[TDOL] [MONEY] NULL,
	[ADOL] [MONEY] NULL,
	[LPCHANNEL] [VARCHAR](25) NULL,
	[CPCHANNEL] [VARCHAR](MAX) NULL,
	[RLDATE] [DATETIME] NULL,
	[RFREQ] [INT] NULL,
	[RTDOL] [MONEY] NULL,
	[RADOL] [MONEY] NULL,
	[WLDATE] [DATETIME] NULL,
	[WFREQ] [INT] NULL,
	[WTDOL] [MONEY] NULL,
	[WADOL] [MONEY] NULL,
	[PLDATE] [DATETIME] NULL,
	[PFREQ] [INT] NULL,
	[PTDOL] [MONEY] NULL,
	[PADOL] [MONEY] NULL,
	[MONACT] [INT] NULL,
	[FSTMCHNL] [VARCHAR](25) NULL
);
--SELECT * FROM CD_BI.dbo.CUSTOMERS_HHID

BEGIN TRANSACTION INS1;
BEGIN TRY;

WITH FIRST_ORD AS
	(SELECT * FROM 
		(
		SELECT  ORDDATE,ORDCHANNEL,HHID
		,ROW_NUMBER() OVER (PARTITION BY HHID ORDER BY ORDDATE ASC) RA
		,COUNT(*) OVER (PARTITION BY HHID) TOTORD
		,SUM(ORDTDOL) OVER (PARTITION BY HHID) TOTDOL
		FROM  CD_BASE.dbo.ORDERS  
		) T
	WHERE RA = 1 )
,LAST_ORD AS  
	(SELECT * FROM 
		(
		SELECT  ORDDATE,ORDCHANNEL,HHID
		,ROW_NUMBER() OVER (PARTITION BY HHID ORDER BY ORDDATE DESC) RD
		FROM  CD_BASE.dbo.ORDERS  
		) T 
	WHERE RD = 1)
,ORDCHN AS
	(
	SELECT 
	HHID
	,MIN(ORDDATE) FDATE
	,MAX(ORDDATE) LDATE
	,COUNT(ORDNO) FREQ
	,SUM(ORDTDOL) TDOL
	,ORDCHANNEL
	FROM  CD_BASE.dbo.ORDERS
	WHERE ORDCHANNEL IN ('RETAIL','PHONE','WEB')
	GROUP BY HHID,ORDCHANNEL
	)
INSERT INTO CD_BI.dbo.CUSTOMERS_HHID
SELECT 
	C.HHID  	HHID  
	,C.INDID 	INDID 
	,C.ADDID   	ADDID
	,C.COMPID   	COMPID
	,C.ACCTNO	ACCTNO 
	,C.STATE	STATE 
	,C.ZIP	ZIP   
	,C.COUNTRY   	CNTRYCODE
	,C.EMAIL   	EMAIL
	,C.PHONE   	PHONE 
	,C.DNMFLAG   	DNMFLAG   
	,C.DNRFLAG   	DNRFLAG   
	,C.DNCFLAG 	DNCFLAG   
	,C.DNEFLAG	DNEFLAG   
	,C.MAILABLE 	MAILABLE  
	,C.EMAILFLAG 	EMAILFLAG 
	,C.GENDER	GENDER
	,C.BDAY 	BDAY  
	,FIRST_ORD.ORDDATE ODATE
	,FIRST_ORD.ORDDATE LDATE 
	,FIRST_ORD.TOTORD FREQ  
	,FIRST_ORD.TOTDOL TDOL  
	,FIRST_ORD.TOTDOL/FIRST_ORD.TOTORD ADOL  
	,FIRST_ORD.ORDCHANNEL LPCHANNEL 
	,(SELECT STUFF((SELECT DISTINCT '/ ' + ORDCHANNEL 
			  FROM CD_BASE.dbo.ORDERS O
			  WHERE HHID = C.HHID
			  FOR XML PATH('')), 1, 1, '')) CPCHANNEL 
	,RE.LDATE RLDATE  
	,RE.FREQ RFREQ   
	,RE.TDOL RTDOL   
	,RE.TDOL/RE.FREQ RADOL   
	,WE.LDATE WLDATE  
	,WE.FREQ WFREQ   
	,WE.TDOL WTDOL   
	,WE.TDOL/WE.FREQ WADOL  
	,PH.LDATE PLDATE  
	,PH.FREQ PFREQ   
	,PH.TDOL PTDOL   
	,PH.TDOL/PH.FREQ PADOL  
	,DATEDIFF(MONTH,FIRST_ORD.ORDDATE,GETDATE()) MONACT
	,FIRST_ORD.ORDCHANNEL FSTMCHNL 

FROM (SELECT  *
        ,ROW_NUMBER() OVER (PARTITION BY HHID ORDER BY FILEDATE DESC) INDID_R
        FROM  CD_BASE.dbo.CUSTOMERS
        ) C
LEFT JOIN FIRST_ORD ON C.HHID = FIRST_ORD.HHID
LEFT JOIN LAST_ORD ON C.HHID = LAST_ORD.HHID
LEFT JOIN ORDCHN RE ON C.HHID = RE.HHID AND RE.ORDCHANNEL = 'RETAIL'
LEFT JOIN ORDCHN PH ON C.HHID = PH.HHID AND PH.ORDCHANNEL = 'PHONE'
LEFT JOIN ORDCHN WE ON C.HHID = WE.HHID AND WE.ORDCHANNEL = 'WEB'
WHERE C.INDID_R = 1

COMMIT TRANSACTION INS1;

SELECT @CURRENTTIME = getdate()  --take start time of table
	
EXECUTE [CD_ADMIN].[dbo].[INSERT_RUN_LOG]@LOGID = @LOGID_SP, @ENDTIME =@CURRENTTIME  ,@STATUS = 'Completed' ,@ROWS_AFFECTED = null, @ID = @LOGID_SP  OUTPUT
 --END OF INSERT INTO SP

END TRY 

  
BEGIN CATCH  
DECLARE @allerrors AS VARCHAR(500)=(SELECT CONCAT(ERROR_MESSAGE(), CHAR(13),
	'Error Number: ',ERROR_NUMBER(),CHAR(13),
	'Error Severity: ',ERROR_SEVERITY(),CHAR(13),
	'Error State: ',ERROR_STATE(),CHAR(13),
	'Error Proc: ',ERROR_PROCEDURE(),CHAR(13),
	'Error Line: ',ERROR_LINE()));
DECLARE @ErrorSeverity INT;
SELECT @ErrorSeverity = ERROR_SEVERITY() 
DECLARE @ErrorState INT; 
SELECT @ErrorState = ERROR_STATE()
RAISERROR(@allerrors, --Message Text,
		@ErrorSeverity, -- Severity,
		@ErrorState, --State,
		N'number', --First argument,
		5); --Second argument.
	ROLLBACK TRANSACTION

SELECT @CURRENTTIME = getdate()  --take start time of table
	
EXECUTE [CD_ADMIN].[dbo].[INSERT_RUN_LOG]@LOGID = @LOGID_SP, @ENDTIME =@CURRENTTIME  ,@STATUS = 'Failed' ,@ROWS_AFFECTED = null, @ID = @LOGID_SP  OUTPUT
 --END OF INSERT INTO SP
END CATCH  


END

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CUSTOMERS_INDID_BUILD_BI]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[CUSTOMERS_INDID_BUILD_BI] AS' 
END
GO

ALTER PROCEDURE [dbo].[CUSTOMERS_INDID_BUILD_BI] @RUNID NVARCHAR(100) = NULL
AS
BEGIN
--*****************************CHANGE_LOG*****************************
----------------------------------------------------------------------
--DATE			:	10/22/2019
--MODIFIED_BY	:	Ruchiagarwal3
--CHANGE		:	Added Catch Block
----------------------------------------------------------------------
--CREATED_DATE	:
--DESCRIPTION	:
----------------------------------------------------------------------
SET XACT_ABORT ON
DECLARE @LOGID_TBL int,
			@LOGID_SP int,
			@SP_TABLE_NAME_1 varchar(50) = OBJECT_NAME(@@PROCID),
			@DBNAME_1 varchar(50) = OBJECT_SCHEMA_NAME(@@PROCID),
			@CURRENTTIME DATETIME,
			@SCHEMANAME_1 varchar(50)= DB_NAME(),
			@RUNID_V NVARCHAR(100) = 1

	IF @RUNID IS NOT NULL
		SET @RUNID_V = @RUNID

	--START OF INSERT INTO SP
	SELECT @CURRENTTIME = getdate()

    EXECUTE [CD_ADMIN].[dbo].[INSERT_RUN_LOG]
    @RUNID =@RUNID_V ,@DBNAME = @DBNAME_1  ,@SCHEMANAME = @SCHEMANAME_1 ,@OBJECTTYPE ='SP' ,@OBJECTNAME = @SP_TABLE_NAME_1
    ,@STARTTIME =@CURRENTTIME ,@ENDTIME =null  ,@STATUS = 'In Progress' ,@ROWS_AFFECTED = '0', @ID = @LOGID_SP  OUTPUT


--CHECK IF TABLE EXISTS			
IF OBJECT_ID('CD_BI.dbo.CUSTOMERS_INDID') is not NULL --table exists			
	BEGIN			
	 DROP TABLE CD_BI.dbo.CUSTOMERS_INDID;			
	END		

--CREATE TABLE
CREATE TABLE [dbo].[CUSTOMERS_INDID](
	[ID] INT IDENTITY(1,1) PRIMARY KEY,
	[HHID] [VARCHAR](250) NULL,
	[INDID] [VARCHAR](250) NULL,
	[ADDID] [VARCHAR](250) NULL,
	[COMPID] [VARCHAR](250) NULL,
	[ACCTNO] [VARCHAR](50) NULL,
	[STATE] [VARCHAR](250) NULL,
	[ZIP] [VARCHAR](25) NULL,
	[CNTRYCODE] [VARCHAR](250) NULL,
	[EMAIL] [VARCHAR](250) NULL,
	[PHONE] [VARCHAR](25) NULL,
	[DNMFLAG] [VARCHAR](1) NOT NULL,
	[DNRFLAG] [VARCHAR](1) NOT NULL,
	[DNCFLAG] [VARCHAR](1) NOT NULL,
	[DNEFLAG] [VARCHAR](1) NOT NULL,
	[MAILABLE] [VARCHAR](1) NOT NULL,
	[EMAILFLAG] [VARCHAR](1) NOT NULL,
	[GENDER] [VARCHAR](250) NULL,
	[BDAY] [VARCHAR](25) NULL,
	[ODATE] [DATETIME] NULL,
	[LDATE] [DATETIME] NULL,
	[FREQ] [INT] NULL,
	[TDOL] [MONEY] NULL,
	[ADOL] [MONEY] NULL,
	[LPCHANNEL] [VARCHAR](25) NULL,
	[CPCHANNEL] [VARCHAR](MAX) NULL,
	[RLDATE] [DATETIME] NULL,
	[RFREQ] [INT] NULL,
	[RTDOL] [MONEY] NULL,
	[RADOL] [MONEY] NULL,
	[WLDATE] [DATETIME] NULL,
	[WFREQ] [INT] NULL,
	[WTDOL] [MONEY] NULL,
	[WADOL] [MONEY] NULL,
	[PLDATE] [DATETIME] NULL,
	[PFREQ] [INT] NULL,
	[PTDOL] [MONEY] NULL,
	[PADOL] [MONEY] NULL,
	[MONACT] [INT] NULL,
	[FSTMCHNL] [VARCHAR](25) NULL,
);


BEGIN TRANSACTION INS1;
BEGIN TRY;

WITH 
FIRST_ORD AS
    (SELECT * FROM 
        (
        SELECT  ORDDATE,ORDCHANNEL,INDID
        ,ROW_NUMBER() OVER (PARTITION BY INDID ORDER BY ORDDATE ASC) RA
        ,COUNT(*) OVER (PARTITION BY INDID) TOTORD
        ,SUM(ORDTDOL) OVER (PARTITION BY INDID) TOTDOL
        FROM [CD_BASE].[dbo].[ORDERS]
        ) T
    WHERE RA = 1 )
,LAST_ORD AS  
    (SELECT * FROM 
        (
        SELECT  ORDDATE,ORDCHANNEL,INDID
        ,ROW_NUMBER() OVER (PARTITION BY INDID ORDER BY ORDDATE DESC) RD
        FROM [CD_BASE].[dbo].[ORDERS]
        ) T 
    WHERE RD = 1)
,ORDCHN AS
    (
    SELECT 
    INDID
    ,MIN(ORDDATE) FDATE
    ,MAX(ORDDATE) LDATE
    ,COUNT(ORDNO) FREQ
    ,SUM(ORDTDOL) TDOL
    ,ORDCHANNEL
    FROM [CD_BASE].[dbo].[ORDERS]
    WHERE ORDCHANNEL IN ('RETAIL','PHONE','WEB')
    GROUP BY INDID,ORDCHANNEL
    )
INSERT INTO [dbo].[CUSTOMERS_INDID]
SELECT --TOP 50000
    C.HHID      HHID  
    ,C.INDID     INDID 
    ,C.ADDID       ADDID
    ,C.COMPID       COMPID
    ,C.ACCTNO    ACCTNO
    ,C.STATE    STATE 
    ,C.ZIP    ZIP   
    ,C.COUNTRY       CNTRYCODE
    ,C.EMAIL       EMAIL
    ,C.PHONE       PHONE 
    ,C.DNMFLAG       DNMFLAG   
    ,C.DNRFLAG       DNRFLAG   
    ,C.DNCFLAG     DNCFLAG   
    ,C.DNEFLAG    DNEFLAG   
    ,C.MAILABLE     MAILABLE  
    ,C.EMAILFLAG     EMAILFLAG 
    ,C.GENDER    GENDER
    ,C.BDAY     BDAY  
    ,FIRST_ORD.ORDDATE ODATE
    ,LAST_ORD.ORDDATE LDATE 
    ,FIRST_ORD.TOTORD FREQ  
    ,FIRST_ORD.TOTDOL TDOL  
    ,FIRST_ORD.TOTDOL/FIRST_ORD.TOTORD ADOL  
    ,LAST_ORD.ORDCHANNEL LPCHANNEL 
    ,(SELECT STUFF((SELECT DISTINCT '/ ' + ORDCHANNEL 
              FROM [CD_BASE].[dbo].[ORDERS] O
              WHERE INDID = C.INDID
              FOR XML PATH('')), 1, 1, '')) CPCHANNEL 
    ,RE.LDATE RLDATE  
    ,RE.FREQ RFREQ   
    ,RE.TDOL RTDOL   
    ,RE.TDOL/RE.FREQ RADOL   
    ,WE.LDATE WLDATE  
    ,WE.FREQ WFREQ   
    ,WE.TDOL WTDOL   
    ,WE.TDOL/WE.FREQ WADOL  
    ,PH.LDATE PLDATE  
    ,PH.FREQ PFREQ   
    ,PH.TDOL PTDOL   
    ,PH.TDOL/PH.FREQ PADOL  
    ,DATEDIFF(MONTH,FIRST_ORD.ORDDATE,GETDATE()) MONACT
    ,FIRST_ORD.ORDCHANNEL FSTMCHNL 
FROM (SELECT  *
        ,ROW_NUMBER() OVER (PARTITION BY INDID ORDER BY FILEDATE DESC) INDID_R
        FROM  CD_BASE.dbo.CUSTOMERS
        ) C
LEFT JOIN FIRST_ORD ON C.INDID = FIRST_ORD.INDID
LEFT JOIN LAST_ORD ON C.INDID = LAST_ORD.INDID
LEFT JOIN ORDCHN RE ON C.INDID = RE.INDID AND RE.ORDCHANNEL = 'RETAIL'
LEFT JOIN ORDCHN PH ON C.INDID = PH.INDID AND PH.ORDCHANNEL = 'PHONE'
LEFT JOIN ORDCHN WE ON C.INDID = WE.INDID AND WE.ORDCHANNEL = 'WEB'
WHERE C.INDID_R = 1;

COMMIT TRANSACTION INS1;

SELECT @CURRENTTIME = getdate()  --take start time of table
	
EXECUTE [CD_ADMIN].[dbo].[INSERT_RUN_LOG]@LOGID = @LOGID_SP, @ENDTIME =@CURRENTTIME  ,@STATUS = 'Completed' ,@ROWS_AFFECTED = null, @ID = @LOGID_SP  OUTPUT
 --END OF INSERT INTO SP

END TRY 

  
BEGIN CATCH  
DECLARE @allerrors AS VARCHAR(500)=(SELECT CONCAT(ERROR_MESSAGE(), CHAR(13),
	'Error Number: ',ERROR_NUMBER(),CHAR(13),
	'Error Severity: ',ERROR_SEVERITY(),CHAR(13),
	'Error State: ',ERROR_STATE(),CHAR(13),
	'Error Proc: ',ERROR_PROCEDURE(),CHAR(13),
	'Error Line: ',ERROR_LINE()));
DECLARE @ErrorSeverity INT;
SELECT @ErrorSeverity = ERROR_SEVERITY() 
DECLARE @ErrorState INT; 
SELECT @ErrorState = ERROR_STATE()
RAISERROR(@allerrors, --Message Text,
		@ErrorSeverity, -- Severity,
		@ErrorState, --State,
		N'number', --First argument,
		5); --Second argument.
	ROLLBACK TRANSACTION

SELECT @CURRENTTIME = getdate()  --take start time of table
	
EXECUTE [CD_ADMIN].[dbo].[INSERT_RUN_LOG]@LOGID = @LOGID_SP, @ENDTIME =@CURRENTTIME  ,@STATUS = 'Failed' ,@ROWS_AFFECTED = null, @ID = @LOGID_SP  OUTPUT
 --END OF INSERT INTO SP
END CATCH  

END

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[EMAIL_PROMO_BI]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[EMAIL_PROMO_BI] AS' 
END
GO

ALTER PROCEDURE [dbo].[EMAIL_PROMO_BI] @RUNID NVARCHAR(100) = NULL
AS
BEGIN
		

SET XACT_ABORT ON
DECLARE @LOGID_TBL int,
			@LOGID_SP int,
			@SP_TABLE_NAME_1 varchar(50) = OBJECT_NAME(@@PROCID),
			@DBNAME_1 varchar(50) = OBJECT_SCHEMA_NAME(@@PROCID),
			@CURRENTTIME DATETIME,
			@SCHEMANAME_1 varchar(50)= DB_NAME(),
			@RUNID_V NVARCHAR(100) = 1

	IF @RUNID IS NOT NULL
		SET @RUNID_V = @RUNID
	--START OF INSERT INTO SP
	SELECT @CURRENTTIME = getdate()

    EXECUTE [CD_ADMIN].[dbo].[INSERT_RUN_LOG] 
    @RUNID =@RUNID_V ,@DBNAME = @DBNAME_1  ,@SCHEMANAME = @SCHEMANAME_1 ,@OBJECTTYPE ='SP' ,@OBJECTNAME = @SP_TABLE_NAME_1
    ,@STARTTIME =@CURRENTTIME ,@ENDTIME =null  ,@STATUS = 'In Progress' ,@ROWS_AFFECTED = '0', @ID = @LOGID_SP  OUTPUT

BEGIN TRANSACTION
BEGIN TRY 


IF OBJECT_ID('CD_BI.dbo.EMAIL_PROMOS') is null

BEGIN
   
CREATE TABLE [dbo].[EMAIL_PROMOS](
	[ACCTNO] [varchar](50) NULL,
	[INDID] [varchar](50) NULL,
	[HHID] [varchar](50) NULL,
	[ADDID] [varchar](50) NULL,
	[COMPID] [varchar](50) NULL,
	[FNAME] [varchar](50) NULL,
	[LNAME] [varchar](50) NULL,
	[COUNTRY] [varchar](50) NULL,
	[EMAIL] [varchar](250) NULL,
	[MAILABLE] [varchar](250) NULL,
	[DNRFLAG] [varchar](1) NULL,
	[DNEFLAG] [varchar](1) NULL,
	[EMAILFLAG] [varchar](1) NULL,
	[BDAY] [varchar](25) NULL,
	[INHOME] [datetime] NULL,
	[CIRCNAME] [varchar](250) NULL,
	[CIRCDESC] [varchar](250) NULL,
	[MAILKEY] [varchar](250) NULL,
	[LISTDESC] [varchar](250) NULL,
	[OFFERDESC] [varchar](250) NULL,
	[CAMPAIGNID] [varchar](50) NULL,
	[MESSAGEID] [varchar](50) NULL,
	[FILEDATE] DATETIME NULL,
	[INSERTDATE] DATETIME NULL
) ON [PRIMARY]


CREATE NONCLUSTERED INDEX [IX_NCI_EMAIL] ON [dbo].[EMAIL_PROMOS]
(
	[EMAIL] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)





CREATE NONCLUSTERED INDEX [IX_NCI_FILEDATE] ON [dbo].[EMAIL_PROMOS]
(
	[FILEDATE] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)


END;

DECLARE @HIGHESTDATE AS DATE =(SELECT MAX(CAST(INSERTDATE AS DATETIME)) FROM CD_BI.DBO.EMAIL_PROMOS WHERE ISNULL(INSERTDATE,'')<>'');
	
-- ADD IF FOR NULL DATE

IF @HIGHESTDATE IS NULL
     BEGIN
          SET @HIGHESTDATE ='1900-01-01'
     END

print cast(@HIGHESTDATE as VARCHAR(20)) + ' Highest Date on promos';


INSERT INTO CD_BI.DBO.EMAIL_PROMOS
(      
       ACCTNO
      ,INDID
      ,HHID
      ,ADDID
      ,COMPID
      ,FNAME
      ,LNAME
      ,COUNTRY
      ,EMAIL
      ,MAILABLE
      ,DNRFLAG
      ,DNEFLAG
      ,EMAILFLAG
      ,BDAY
      ,INHOME
      ,CIRCNAME
      ,CIRCDESC
      ,MAILKEY
      ,LISTDESC
      ,OFFERDESC
      ,CAMPAIGNID
	  ,MESSAGEID
      ,FILEDATE
      ,INSERTDATE
)
SELECT 
       SENDS.ACCTNO 
      ,CE.INDID AS INDID 
      ,CE.HHID AS HHID 
      ,CE.ADDID AS ADDID 
      ,CE.COMPID AS COMPID 
      ,CE.FNAME AS FNAME  
      ,CE.LNAME AS LNAME 
      ,NULL AS COUNTRY 
      ,SENDS.EMAIL 
      ,CE.MAILABLE AS MAILABLE 
      ,CE.DNRFLAG AS DNRFLAG
      ,SENDS.DNEFLAG 
      ,CE.EMAILFLAG AS EMAILFLAG 
      ,CE.BDAY AS BDAY 
      ,INTDATE AS INHOME
      ,CAMPNAME AS CIRCNAME
      ,NULL AS CIRCDESC
      ,NULL AS MAILKEY
      ,NULL AS LISTDESC
      ,NULL AS OFFERDESC
      ,CAMPAIGNID 
	  ,MESSAGEID 
      ,FILEDATE 
      ,INSERTDATE
  FROM CD_RAW.dbo.EMAIL_SENDS_LTD SENDS
  LEFT JOIN
  CD_CAMPAIGN.dbo.CUSTOMERS_EMAIL CE ON SENDS.EMAIL=CE.EMAIL
  WHERE SENDS.INSERTDATE>@HIGHESTDATE;
  
COMMIT TRANSACTION
SELECT @CURRENTTIME = getdate()  --take start time of table
	
	EXECUTE [CD_ADMIN].[dbo].[INSERT_RUN_LOG] @LOGID = @LOGID_SP, @ENDTIME =@CURRENTTIME  ,@STATUS = 'Completed' ,@ROWS_AFFECTED = null, @ID = @LOGID_SP  OUTPUT
END TRY 


BEGIN CATCH  
DECLARE @allerrors AS VARCHAR(500)=(SELECT CONCAT(ERROR_MESSAGE(), CHAR(13),
	'Error Number: ',ERROR_NUMBER(),CHAR(13),
	'Error Severity: ',ERROR_SEVERITY(),CHAR(13),
	'Error State: ',ERROR_STATE(),CHAR(13),
	'Error Proc: ',ERROR_PROCEDURE(),CHAR(13),
	'Error Line: ',ERROR_LINE()));
DECLARE @ErrorSeverity INT;
SELECT @ErrorSeverity = ERROR_SEVERITY() 
DECLARE @ErrorState INT; 
SELECT @ErrorState = ERROR_STATE()
RAISERROR(@allerrors, --Message Text,
		@ErrorSeverity, -- Severity,
		@ErrorState, --State,
		N'number', --First argument,
		5); --Second argument.
	ROLLBACK TRANSACTION
SELECT @CURRENTTIME = getdate()  --take start time of table
	
EXECUTE [CD_ADMIN].[dbo].[INSERT_RUN_LOG] @LOGID = @LOGID_SP, @ENDTIME =@CURRENTTIME  ,@STATUS = 'Failed' ,@ROWS_AFFECTED = null, @ID = @LOGID_SP  OUTPUT
END CATCH  

END


GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PROMO_BI]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[PROMO_BI] AS' 
END
GO


ALTER PROCEDURE [dbo].[PROMO_BI] @RUNID NVARCHAR(100) = NULL
AS
BEGIN

SET XACT_ABORT ON
DECLARE @LOGID_TBL INT,
			@LOGID_SP INT,
			@SP_TABLE_NAME_1 VARCHAR(50) = OBJECT_NAME(@@PROCID),
			@DBNAME_1 VARCHAR(50) = OBJECT_SCHEMA_NAME(@@PROCID),
			@CURRENTTIME DATETIME,
			@SCHEMANAME_1 VARCHAR(50)= DB_NAME(),
			@RUNID_V NVARCHAR(100) = 1

	IF @RUNID IS NOT NULL
		SET @RUNID_V = @RUNID
	
	--START OF INSERT INTO SP
	SELECT @CURRENTTIME = getdate()

    EXECUTE [CD_ADMIN].[dbo].[INSERT_RUN_LOG] 
    @RUNID =@RUNID_V ,@DBNAME = @DBNAME_1  ,@SCHEMANAME = @SCHEMANAME_1 ,@OBJECTTYPE ='SP' ,@OBJECTNAME = @SP_TABLE_NAME_1
    ,@STARTTIME =@CURRENTTIME ,@ENDTIME =null  ,@STATUS = 'In Progress' ,@ROWS_AFFECTED = '0', @ID = @LOGID_SP  OUTPUT

	DECLARE @CIRCNAMES TABLE
	(
	CIRCNAME VARCHAR(100) NULL
	)

	BEGIN TRANSACTION
	BEGIN TRY 

	INSERT INTO @CIRCNAMES
	SELECT DISTINCT CIRCNAME FROM CD_BI.DBO.PROMOS;

	INSERT INTO CD_BI.DBO.PROMOS
	SELECT [HHID]
		,[INDID]
		,[ADDID]
		,[COMPID]
		,[ACCTNO]
		,[PRENAME]
		,[FNAME]
		,[MNAME]
		,[LNAME]
		,[SUFNAME]
		,[COMPANY]
		,[TITLE]
		,[ADD1]
		,[ADD2]
		,[CITY]
		,[STATE]
		,[ZIP]
		,[PLUS4]
		,[DELPT]
		,[CKDIGIT]
		,[CRRT]
		,[CASSCODE]
		,[CNTRYCODE]
		,[CNTYCODE]
		,[CNTYNAME]
		,[DPV]
		,[DPVFTNOTE]
		,[DPV_VACANT]
		,[LACSINDC]
		,[LOT]
		,[LOTORDER]
		,[DPVNOSTAT]
		,[EMAIL]
		,[PHONE]
		,[DNMFLAG]
		,[DNRFLAG]
		,[DNCFLAG]
		,[DNEFLAG]
		,[MAILABLE]
		,[EMAILFLAG]
		,[GENDER]
		,[BDAY]
		,[MAILDATE]
		,[INHOME]
		,[CIRCNAME]
		,[CIRCDESC]
		,[PROMTYPE]
		,[MAILKEY]
		,[MKEYDESC]
		,[DEMO]
		,[LDATE]
		,[FREQ]
		,[TDOL]
		,[ADOL]
	FROM [CD_RAW].[dbo].[PROMO_LTD] LTD WHERE NOT EXISTS(SELECT 1 FROM @CIRCNAMES CIRC  WHERE CIRC.CIRCNAME=LTD.CIRCNAME)
	
	COMMIT TRANSACTION

	SELECT @CURRENTTIME = getdate()  --take start time of table
	
	EXECUTE [CD_ADMIN].[dbo].[INSERT_RUN_LOG] @LOGID = @LOGID_SP, @ENDTIME =@CURRENTTIME  ,@STATUS = 'Completed' ,@ROWS_AFFECTED = null, @ID = @LOGID_SP  OUTPUT

	END TRY 
  
	BEGIN CATCH  
	DECLARE @allerrors AS VARCHAR(500)=(SELECT CONCAT(ERROR_MESSAGE(), CHAR(13),
		'Error Number: ',ERROR_NUMBER(),CHAR(13),
		'Error Severity: ',ERROR_SEVERITY(),CHAR(13),
		'Error State: ',ERROR_STATE(),CHAR(13),
		'Error Proc: ',ERROR_PROCEDURE(),CHAR(13),
		'Error Line: ',ERROR_LINE()));
	DECLARE @ErrorSeverity INT;
	SELECT @ErrorSeverity = ERROR_SEVERITY() 
	DECLARE @ErrorState INT; 
	SELECT @ErrorState = ERROR_STATE()
	RAISERROR(@allerrors, --Message Text,
			@ErrorSeverity, -- Severity,
			@ErrorState, --State,
			N'number', --First argument,
			5); --Second argument.
		ROLLBACK TRANSACTION

	SELECT @CURRENTTIME = getdate()  --take start time of table
	
	EXECUTE [CD_ADMIN].[dbo].[INSERT_RUN_LOG] @LOGID = @LOGID_SP, @ENDTIME =@CURRENTTIME  ,@STATUS = 'Failed' ,@ROWS_AFFECTED = null, @ID = @LOGID_SP  OUTPUT

	END CATCH  

END

GO
