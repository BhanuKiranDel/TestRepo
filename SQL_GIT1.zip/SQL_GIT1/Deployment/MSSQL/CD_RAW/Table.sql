﻿USE [CD_RAW]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DATA_FEED_MAPPING]') AND type in (N'U'))
ALTER TABLE [dbo].[DATA_FEED_MAPPING] DROP CONSTRAINT IF EXISTS [DF__DATA_FEED__IS_MA__7BB1235D]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DATA_FEED_CATALOG]') AND type in (N'U'))
ALTER TABLE [dbo].[DATA_FEED_CATALOG] DROP CONSTRAINT IF EXISTS [DF__DATA_FEED__JOB_C__6502C82F]
GO
DROP INDEX IF EXISTS [IX_NCI_ITMNO] ON [dbo].[RETAIL_ITEMS_LTD]
GO
DROP INDEX IF EXISTS [idxCircname] ON [dbo].[PROMO_LTD]
GO
DROP INDEX IF EXISTS [IX_NCI_ITMNO] ON [dbo].[DIRECT_ITEMS_LTD]
GO
DROP TABLE IF EXISTS [dbo].[STORE_MASTER_RAW]
GO
DROP TABLE IF EXISTS [dbo].[STORE_MASTER_LTD]
GO
DROP TABLE IF EXISTS [dbo].[RETAIL_ORDERS_RAW]
GO
DROP TABLE IF EXISTS [dbo].[RETAIL_ORDERS_LTD]
GO
DROP TABLE IF EXISTS [dbo].[RETAIL_ORDERS_DAILY]
GO
DROP TABLE IF EXISTS [dbo].[RETAIL_ITEMS_RAW]
GO
DROP TABLE IF EXISTS [dbo].[RETAIL_ITEMS_LTD]
GO
DROP TABLE IF EXISTS [dbo].[RETAIL_ITEMS_DAILY]
GO
DROP TABLE IF EXISTS [dbo].[REQUESTORS_RAW]
GO
DROP TABLE IF EXISTS [dbo].[REQUESTORS_LTD]
GO
DROP TABLE IF EXISTS [dbo].[REQUESTORS_DAILY]
GO
DROP TABLE IF EXISTS [dbo].[PROMO_RAW]
GO
DROP TABLE IF EXISTS [dbo].[PROMO_LTD]
GO
DROP TABLE IF EXISTS [dbo].[PROMO_DAILY]
GO
DROP TABLE IF EXISTS [dbo].[PRODUCT_MASTER_RAW]
GO
DROP TABLE IF EXISTS [dbo].[PRODUCT_MASTER_LTD]
GO
DROP TABLE IF EXISTS [dbo].[MATCHED]
GO
DROP TABLE IF EXISTS [dbo].[JOB_DURATION]
GO
DROP TABLE IF EXISTS [dbo].[JOB_AUDIT_LOG1]
GO
DROP TABLE IF EXISTS [dbo].[JOB_AUDIT_LOG]
GO
DROP TABLE IF EXISTS [dbo].[ITEM_MASTER_RAW]
GO
DROP TABLE IF EXISTS [dbo].[ITEM_MASTER_LTD]
GO
DROP TABLE IF EXISTS [dbo].[HIT_DATA_LTD]
GO
DROP TABLE IF EXISTS [dbo].[HIT_DATA]
GO
DROP TABLE IF EXISTS [dbo].[GDPR_PII_FIELD_MAPPING]
GO
DROP TABLE IF EXISTS [dbo].[GDPR_DELETION_REQUEST]
GO
DROP TABLE IF EXISTS [dbo].[GDPR_AUDIT_TABLE_11_20_2019_14_12_17]
GO
DROP TABLE IF EXISTS [dbo].[EMAIL_UNSUBS_RAW]
GO
DROP TABLE IF EXISTS [dbo].[EMAIL_UNSUBS_LTD]
GO
DROP TABLE IF EXISTS [dbo].[EMAIL_SUBS_RAW_API]
GO
DROP TABLE IF EXISTS [dbo].[EMAIL_SUBS_RAW]
GO
DROP TABLE IF EXISTS [dbo].[EMAIL_SUBS_LTD]
GO
DROP TABLE IF EXISTS [dbo].[EMAIL_SUBS_DAILY]
GO
DROP TABLE IF EXISTS [dbo].[EMAIL_SENDS_RAW]
GO
DROP TABLE IF EXISTS [dbo].[EMAIL_SENDS_LTD]
GO
DROP TABLE IF EXISTS [dbo].[EMAIL_SENDS_DAILY]
GO
DROP TABLE IF EXISTS [dbo].[EMAIL_OPTOUTS_DAILY]
GO
DROP TABLE IF EXISTS [dbo].[EMAIL_OPENS_RAW]
GO
DROP TABLE IF EXISTS [dbo].[EMAIL_OPENS_LTD]
GO
DROP TABLE IF EXISTS [dbo].[EMAIL_OPENS_DAILY]
GO
DROP TABLE IF EXISTS [dbo].[EMAIL_CLICKS_RAW]
GO
DROP TABLE IF EXISTS [dbo].[EMAIL_CLICKS_LTD]
GO
DROP TABLE IF EXISTS [dbo].[EMAIL_CLICKS_DAILY]
GO
DROP TABLE IF EXISTS [dbo].[EMAIL_BOUNCES_RAW]
GO
DROP TABLE IF EXISTS [dbo].[EMAIL_BOUNCES_LTD]
GO
DROP TABLE IF EXISTS [dbo].[EMAIL_BOUNCES_DAILY]
GO
DROP TABLE IF EXISTS [dbo].[DIRECT_ORDERS_RAW_API]
GO
DROP TABLE IF EXISTS [dbo].[DIRECT_ORDERS_RAW]
GO
DROP TABLE IF EXISTS [dbo].[DIRECT_ORDERS_LTD]
GO
DROP TABLE IF EXISTS [dbo].[DIRECT_ORDERS_DAILY]
GO
DROP TABLE IF EXISTS [dbo].[DIRECT_ITEMS_RAW_API]
GO
DROP TABLE IF EXISTS [dbo].[DIRECT_ITEMS_RAW]
GO
DROP TABLE IF EXISTS [dbo].[DIRECT_ITEMS_LTD]
GO
DROP TABLE IF EXISTS [dbo].[DIRECT_ITEMS_DAILY]
GO
DROP TABLE IF EXISTS [dbo].[DATA_FEED_MAPPING]
GO
DROP TABLE IF EXISTS [dbo].[DATA_FEED_CATALOG]
GO
DROP TABLE IF EXISTS [dbo].[CUSTOMERS_RAW_API]
GO
DROP TABLE IF EXISTS [dbo].[CUSTOMERS_RAW]
GO
DROP TABLE IF EXISTS [dbo].[CUSTOMERS_LTD]
GO
DROP TABLE IF EXISTS [dbo].[CUSTOMERS_EMAIL]
GO
DROP TABLE IF EXISTS [dbo].[CUSTOMERS_DAILY]
GO
DROP TABLE IF EXISTS [dbo].[ADOBE_SEARCH_ENGINES_REF]
GO
DROP TABLE IF EXISTS [dbo].[ADOBE_RESOLUTION_REF]
GO
DROP TABLE IF EXISTS [dbo].[ADOBE_REFERRER_TYPE_REF]
GO
DROP TABLE IF EXISTS [dbo].[ADOBE_PLUGINS_REF]
GO
DROP TABLE IF EXISTS [dbo].[ADOBE_OPERATING_SYSTEMS_REF]
GO
DROP TABLE IF EXISTS [dbo].[ADOBE_LANGUAGES_REF]
GO
DROP TABLE IF EXISTS [dbo].[ADOBE_JAVASCRIPT_VERSION_REF]
GO
DROP TABLE IF EXISTS [dbo].[ADOBE_HIT_DATA_REF_LTD]
GO
DROP TABLE IF EXISTS [dbo].[ADOBE_HIT_DATA_REF]
GO
DROP TABLE IF EXISTS [dbo].[ADOBE_EVENT_REF]
GO
DROP TABLE IF EXISTS [dbo].[ADOBE_COUNTRY_REF]
GO
DROP TABLE IF EXISTS [dbo].[ADOBE_CONNECTION_TYPE_REF]
GO
DROP TABLE IF EXISTS [dbo].[ADOBE_COLOR_DEPTH_REF]
GO
DROP TABLE IF EXISTS [dbo].[ADOBE_BROWSER_TYPE_REF]
GO
DROP TABLE IF EXISTS [dbo].[ADOBE_BROWSER_REF]
GO
DROP TABLE IF EXISTS [dbo].[ACCTNUM_PINS_REF]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ACCTNUM_PINS_REF]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[ACCTNUM_PINS_REF](
	[HHID] [varchar](250) NULL,
	[INDID] [varchar](250) NULL,
	[ADDID] [varchar](250) NULL,
	[COMPID] [varchar](250) NULL,
	[ACCTNO] [varchar](50) NULL,
	[rownum] [bigint] NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ADOBE_BROWSER_REF]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[ADOBE_BROWSER_REF](
	[ID] [varchar](50) NULL,
	[VALUE] [varchar](1000) NULL,
	[FILENAME] [varchar](100) NULL,
	[SEQ] [varchar](20) NULL,
	[FILEDATE] [varchar](20) NULL,
	[FILESOURCE] [varchar](100) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ADOBE_BROWSER_TYPE_REF]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[ADOBE_BROWSER_TYPE_REF](
	[ID] [varchar](50) NULL,
	[VALUE] [varchar](1000) NULL,
	[FILENAME] [varchar](100) NULL,
	[SEQ] [varchar](20) NULL,
	[FILEDATE] [varchar](20) NULL,
	[FILESOURCE] [varchar](100) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ADOBE_COLOR_DEPTH_REF]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[ADOBE_COLOR_DEPTH_REF](
	[ID] [varchar](50) NULL,
	[VALUE] [varchar](1000) NULL,
	[FILENAME] [varchar](100) NULL,
	[SEQ] [varchar](20) NULL,
	[FILEDATE] [varchar](20) NULL,
	[FILESOURCE] [varchar](100) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ADOBE_CONNECTION_TYPE_REF]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[ADOBE_CONNECTION_TYPE_REF](
	[ID] [varchar](50) NULL,
	[VALUE] [varchar](1000) NULL,
	[FILENAME] [varchar](100) NULL,
	[SEQ] [varchar](20) NULL,
	[FILEDATE] [varchar](20) NULL,
	[FILESOURCE] [varchar](100) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ADOBE_COUNTRY_REF]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[ADOBE_COUNTRY_REF](
	[ID] [varchar](50) NULL,
	[VALUE] [varchar](1000) NULL,
	[FILENAME] [varchar](100) NULL,
	[SEQ] [varchar](20) NULL,
	[FILEDATE] [varchar](20) NULL,
	[FILESOURCE] [varchar](100) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ADOBE_EVENT_REF]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[ADOBE_EVENT_REF](
	[ID] [varchar](50) NULL,
	[VALUE] [varchar](1000) NULL,
	[FILENAME] [varchar](100) NULL,
	[SEQ] [varchar](20) NULL,
	[FILEDATE] [varchar](20) NULL,
	[FILESOURCE] [varchar](100) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ADOBE_HIT_DATA_REF]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[ADOBE_HIT_DATA_REF](
	[ID] [varchar](100) NULL,
	[VALUE] [varchar](500) NULL,
	[FILENAME] [varchar](100) NULL,
	[SEQ] [varchar](10) NULL,
	[FILEDATE] [varchar](8) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ADOBE_HIT_DATA_REF_LTD]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[ADOBE_HIT_DATA_REF_LTD](
	[ID] [varchar](100) NULL,
	[VALUE] [varchar](500) NULL,
	[FILENAME] [varchar](100) NULL,
	[SEQ] [varchar](10) NULL,
	[FILEDATE] [varchar](8) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ADOBE_JAVASCRIPT_VERSION_REF]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[ADOBE_JAVASCRIPT_VERSION_REF](
	[ID] [varchar](50) NULL,
	[VALUE] [varchar](1000) NULL,
	[FILENAME] [varchar](100) NULL,
	[SEQ] [varchar](20) NULL,
	[FILEDATE] [varchar](20) NULL,
	[FILESOURCE] [varchar](100) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ADOBE_LANGUAGES_REF]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[ADOBE_LANGUAGES_REF](
	[ID] [varchar](50) NULL,
	[VALUE] [varchar](1000) NULL,
	[FILENAME] [varchar](100) NULL,
	[SEQ] [varchar](20) NULL,
	[FILEDATE] [varchar](20) NULL,
	[FILESOURCE] [varchar](100) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ADOBE_OPERATING_SYSTEMS_REF]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[ADOBE_OPERATING_SYSTEMS_REF](
	[ID] [varchar](50) NULL,
	[VALUE] [varchar](1000) NULL,
	[FILENAME] [varchar](100) NULL,
	[SEQ] [varchar](20) NULL,
	[FILEDATE] [varchar](20) NULL,
	[FILESOURCE] [varchar](100) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ADOBE_PLUGINS_REF]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[ADOBE_PLUGINS_REF](
	[ID] [varchar](50) NULL,
	[VALUE] [varchar](1000) NULL,
	[FILENAME] [varchar](100) NULL,
	[SEQ] [varchar](20) NULL,
	[FILEDATE] [varchar](20) NULL,
	[FILESOURCE] [varchar](100) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ADOBE_REFERRER_TYPE_REF]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[ADOBE_REFERRER_TYPE_REF](
	[ID] [varchar](50) NULL,
	[VALUE] [varchar](1000) NULL,
	[FILENAME] [varchar](100) NULL,
	[SEQ] [varchar](20) NULL,
	[FILEDATE] [varchar](20) NULL,
	[FILESOURCE] [varchar](100) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ADOBE_RESOLUTION_REF]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[ADOBE_RESOLUTION_REF](
	[ID] [varchar](50) NULL,
	[VALUE] [varchar](1000) NULL,
	[FILENAME] [varchar](100) NULL,
	[SEQ] [varchar](20) NULL,
	[FILEDATE] [varchar](20) NULL,
	[FILESOURCE] [varchar](100) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ADOBE_SEARCH_ENGINES_REF]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[ADOBE_SEARCH_ENGINES_REF](
	[ID] [varchar](50) NULL,
	[VALUE] [varchar](1000) NULL,
	[FILENAME] [varchar](100) NULL,
	[SEQ] [varchar](20) NULL,
	[FILEDATE] [varchar](20) NULL,
	[FILESOURCE] [varchar](100) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CUSTOMERS_DAILY]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[CUSTOMERS_DAILY](
	[ACCTNO] [varchar](250) NULL,
	[FNAME] [varchar](250) NULL,
	[LNAME] [varchar](250) NULL,
	[ADD1] [varchar](250) NULL,
	[ADD2] [varchar](250) NULL,
	[CITY] [varchar](250) NULL,
	[STATE] [varchar](250) NULL,
	[ZIP] [varchar](250) NULL,
	[EMAIL] [varchar](250) NULL,
	[COUNTRY] [varchar](250) NULL,
	[PHONE] [varchar](250) NULL,
	[PRENAME] [varchar](50) NULL,
	[MNAME] [varchar](50) NULL,
	[SUFNAME] [varchar](50) NULL,
	[COMPANY] [varchar](250) NULL,
	[TITLE] [varchar](250) NULL,
	[BDAY] [varchar](257) NOT NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CUSTOMERS_EMAIL]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[CUSTOMERS_EMAIL](
	[NEWESTREC] [bigint] NULL,
	[FNAME] [varchar](250) NULL,
	[LNAME] [varchar](250) NULL,
	[ADD1] [varchar](250) NULL,
	[ADD2] [varchar](250) NULL,
	[CITY] [varchar](250) NULL,
	[STATE] [varchar](250) NULL,
	[ZIP] [varchar](250) NULL,
	[PLUS4] [varchar](250) NULL,
	[COMPANY] [varchar](250) NULL,
	[PRINUM] [varchar](250) NULL,
	[STREET] [varchar](250) NULL,
	[UNITNUM] [varchar](250) NULL,
	[FNAMEKEY] [varchar](250) NULL,
	[LNAMEKEY] [varchar](250) NULL,
	[COMPKEY] [varchar](250) NULL,
	[STREETKEY] [varchar](250) NULL,
	[EMAIL] [varchar](250) NULL,
	[PHONE] [varchar](250) NULL,
	[PIN] [varchar](250) NULL,
	[INDID] [varchar](250) NULL,
	[HHID] [varchar](250) NULL,
	[ADDID] [varchar](250) NULL,
	[COMPID] [varchar](250) NULL,
	[PINSOURCE] [varchar](250) NULL,
	[PINSEQ] [varchar](250) NULL,
	[ACCTNO] [varchar](250) NULL,
	[ONFILEDATE] [varchar](250) NULL,
	[BUYER_FLAG] [varchar](250) NULL,
	[MAIL_ST] [varchar](250) NULL,
	[ADD3] [varchar](250) NULL,
	[ADD4] [varchar](250) NULL,
	[OZIP] [varchar](250) NULL,
	[P4] [varchar](250) NULL,
	[ADDR_CODE] [varchar](250) NULL,
	[COUNTRY] [varchar](250) NULL,
	[ORG_SRC_CD] [varchar](250) NULL,
	[LST_TRN_DT] [varchar](250) NULL,
	[LST_TRN_CD] [varchar](250) NULL,
	[LST_COA_DT] [varchar](250) NULL,
	[LST_COA_ID] [varchar](250) NULL,
	[RENTFLAG] [varchar](250) NULL,
	[RENTFLAGDT] [varchar](250) NULL,
	[DEACT_DATE] [varchar](250) NULL,
	[DOB_MONTH] [varchar](250) NULL,
	[ORGACCTNO] [varchar](250) NULL,
	[FILENAME] [varchar](250) NULL,
	[SEQ] [varchar](250) NULL,
	[FILEDATE] [varchar](250) NULL,
	[PRENAME] [varchar](250) NULL,
	[MNAME] [varchar](250) NULL,
	[FULLNAME] [varchar](250) NULL,
	[SUFNAME] [varchar](250) NULL,
	[TITLE] [varchar](250) NULL,
	[GENDER] [varchar](250) NULL,
	[DOMAIN] [varchar](250) NULL,
	[CVTDATE] [varchar](250) NULL,
	[ADSUFFIX] [varchar](250) NULL,
	[ADDTYPE] [varchar](250) NULL,
	[CRRT] [varchar](250) NULL,
	[CASSCODE] [varchar](250) NULL,
	[CKDIGIT] [varchar](250) NULL,
	[CNTRYCODE] [varchar](250) NULL,
	[CNTYCODE] [varchar](250) NULL,
	[CNTYNAME] [varchar](250) NULL,
	[DELPT] [varchar](250) NULL,
	[DPV] [varchar](250) NULL,
	[DPVFTNOTE] [varchar](250) NULL,
	[DPV_VACANT] [varchar](250) NULL,
	[LACSINDC] [varchar](250) NULL,
	[LOT] [varchar](250) NULL,
	[LOTORDER] [varchar](250) NULL,
	[DPVNOSTAT] [varchar](250) NULL,
	[POSDIR] [varchar](250) NULL,
	[PREDIR] [varchar](250) NULL,
	[UNITTYPE] [varchar](250) NULL,
	[INSERTDATE] [varchar](50) NULL,
	[rownum] [bigint] NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CUSTOMERS_LTD]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[CUSTOMERS_LTD](
	[FNAME] [varchar](250) NULL,
	[LNAME] [varchar](250) NULL,
	[ADD1] [varchar](250) NULL,
	[ADD2] [varchar](250) NULL,
	[CITY] [varchar](250) NULL,
	[STATE] [varchar](250) NULL,
	[ZIP] [varchar](25) NULL,
	[PLUS4] [varchar](250) NULL,
	[COMPANY] [varchar](250) NULL,
	[PRINUM] [varchar](250) NULL,
	[STREET] [varchar](250) NULL,
	[UNITNUM] [varchar](250) NULL,
	[FNAMEKEY] [varchar](250) NULL,
	[LNAMEKEY] [varchar](250) NULL,
	[COMPKEY] [varchar](250) NULL,
	[STREETKEY] [varchar](250) NULL,
	[EMAIL] [varchar](250) NULL,
	[PHONE] [varchar](25) NULL,
	[PIN] [varchar](250) NULL,
	[INDID] [varchar](250) NULL,
	[HHID] [varchar](250) NULL,
	[ADDID] [varchar](250) NULL,
	[COMPID] [varchar](250) NULL,
	[PINSOURCE] [varchar](250) NULL,
	[PINSEQ] [varchar](250) NULL,
	[ACCTNO] [varchar](50) NULL,
	[COUNTRY] [varchar](250) NULL,
	[PRENAME] [varchar](250) NULL,
	[MNAME] [varchar](250) NULL,
	[SUFNAME] [varchar](250) NULL,
	[TITLE] [varchar](250) NULL,
	[BDAY] [varchar](25) NULL,
	[FILENAME] [varchar](250) NULL,
	[SEQ] [varchar](250) NULL,
	[FILEDATE] [varchar](250) NULL,
	[FULLNAME] [varchar](250) NULL,
	[GENDER] [varchar](250) NULL,
	[ADD3] [varchar](250) NULL,
	[DOMAIN] [varchar](250) NULL,
	[CVTDATE] [varchar](250) NULL,
	[ADSUFFIX] [varchar](250) NULL,
	[ADDTYPE] [varchar](250) NULL,
	[CRRT] [varchar](250) NULL,
	[CASSCODE] [varchar](250) NULL,
	[CKDIGIT] [varchar](250) NULL,
	[CNTRYCODE] [varchar](250) NULL,
	[CNTYCODE] [varchar](250) NULL,
	[CNTYNAME] [varchar](250) NULL,
	[DELPT] [varchar](250) NULL,
	[DPV] [varchar](250) NULL,
	[DPVFTNOTE] [varchar](250) NULL,
	[DPV_VACANT] [varchar](250) NULL,
	[LACSINDC] [varchar](250) NULL,
	[LOT] [varchar](250) NULL,
	[LOTORDER] [varchar](250) NULL,
	[DPVNOSTAT] [varchar](250) NULL,
	[POSDIR] [varchar](250) NULL,
	[PREDIR] [varchar](250) NULL,
	[UNITTYPE] [varchar](250) NULL,
	[INSERTDATE] [varchar](50) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CUSTOMERS_RAW]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[CUSTOMERS_RAW](
	[FNAME] [varchar](250) NULL,
	[LNAME] [varchar](250) NULL,
	[ADD1] [varchar](250) NULL,
	[ADD2] [varchar](250) NULL,
	[CITY] [varchar](250) NULL,
	[STATE] [varchar](250) NULL,
	[ZIP] [varchar](25) NULL,
	[PLUS4] [varchar](250) NULL,
	[COMPANY] [varchar](250) NULL,
	[PRINUM] [varchar](250) NULL,
	[STREET] [varchar](250) NULL,
	[UNITNUM] [varchar](250) NULL,
	[FNAMEKEY] [varchar](250) NULL,
	[LNAMEKEY] [varchar](250) NULL,
	[COMPKEY] [varchar](250) NULL,
	[STREETKEY] [varchar](250) NULL,
	[EMAIL] [varchar](250) NULL,
	[PHONE] [varchar](25) NULL,
	[PIN] [varchar](250) NULL,
	[INDID] [varchar](250) NULL,
	[HHID] [varchar](250) NULL,
	[ADDID] [varchar](250) NULL,
	[COMPID] [varchar](250) NULL,
	[PINSOURCE] [varchar](250) NULL,
	[PINSEQ] [varchar](250) NULL,
	[ACCTNO] [varchar](50) NULL,
	[COUNTRY] [varchar](250) NULL,
	[PRENAME] [varchar](250) NULL,
	[MNAME] [varchar](250) NULL,
	[SUFNAME] [varchar](250) NULL,
	[TITLE] [varchar](250) NULL,
	[BDAY] [varchar](25) NULL,
	[FILENAME] [varchar](250) NULL,
	[SEQ] [varchar](250) NULL,
	[FILEDATE] [varchar](250) NULL,
	[FULLNAME] [varchar](250) NULL,
	[GENDER] [varchar](250) NULL,
	[ADD3] [varchar](250) NULL,
	[DOMAIN] [varchar](250) NULL,
	[CVTDATE] [varchar](250) NULL,
	[ADSUFFIX] [varchar](250) NULL,
	[ADDTYPE] [varchar](250) NULL,
	[CRRT] [varchar](250) NULL,
	[CASSCODE] [varchar](250) NULL,
	[CKDIGIT] [varchar](250) NULL,
	[CNTRYCODE] [varchar](250) NULL,
	[CNTYCODE] [varchar](250) NULL,
	[CNTYNAME] [varchar](250) NULL,
	[DELPT] [varchar](250) NULL,
	[DPV] [varchar](250) NULL,
	[DPVFTNOTE] [varchar](250) NULL,
	[DPV_VACANT] [varchar](250) NULL,
	[LACSINDC] [varchar](250) NULL,
	[LOT] [varchar](250) NULL,
	[LOTORDER] [varchar](250) NULL,
	[DPVNOSTAT] [varchar](250) NULL,
	[POSDIR] [varchar](250) NULL,
	[PREDIR] [varchar](250) NULL,
	[UNITTYPE] [varchar](250) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CUSTOMERS_RAW_API]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[CUSTOMERS_RAW_API](
	[FNAME] [varchar](250) NULL,
	[LNAME] [varchar](250) NULL,
	[ADD1] [varchar](250) NULL,
	[ADD2] [varchar](250) NULL,
	[CITY] [varchar](250) NULL,
	[STATE] [varchar](250) NULL,
	[ZIP] [varchar](250) NULL,
	[PLUS4] [varchar](250) NULL,
	[COMPANY] [varchar](250) NULL,
	[PRINUM] [varchar](250) NULL,
	[STREET] [varchar](250) NULL,
	[UNITNUM] [varchar](250) NULL,
	[FNAMEKEY] [varchar](250) NULL,
	[LNAMEKEY] [varchar](250) NULL,
	[COMPKEY] [varchar](250) NULL,
	[STREETKEY] [varchar](250) NULL,
	[EMAIL] [varchar](250) NULL,
	[PHONE] [varchar](250) NULL,
	[PIN] [varchar](250) NULL,
	[INDID] [varchar](250) NULL,
	[HHID] [varchar](250) NULL,
	[ADDID] [varchar](250) NULL,
	[COMPID] [varchar](250) NULL,
	[PINSOURCE] [varchar](250) NULL,
	[PINSEQ] [varchar](250) NULL,
	[ACCTNO] [varchar](250) NULL,
	[ONFILEDATE] [varchar](250) NULL,
	[BUYER_FLAG] [varchar](250) NULL,
	[MAIL_ST] [varchar](250) NULL,
	[ADD3] [varchar](250) NULL,
	[ADD4] [varchar](250) NULL,
	[OZIP] [varchar](250) NULL,
	[P4] [varchar](250) NULL,
	[ADDR_CODE] [varchar](250) NULL,
	[COUNTRY] [varchar](250) NULL,
	[ORG_SRC_CD] [varchar](250) NULL,
	[LST_TRN_DT] [varchar](250) NULL,
	[LST_TRN_CD] [varchar](250) NULL,
	[LST_COA_DT] [varchar](250) NULL,
	[LST_COA_ID] [varchar](250) NULL,
	[RENTFLAG] [varchar](250) NULL,
	[RENTFLAGDT] [varchar](250) NULL,
	[DEACT_DATE] [varchar](250) NULL,
	[DOB_MONTH] [varchar](250) NULL,
	[ORGACCTNO] [varchar](250) NULL,
	[FILENAME] [varchar](250) NULL,
	[SEQ] [varchar](250) NULL,
	[FILEDATE] [varchar](250) NULL,
	[PRENAME] [varchar](250) NULL,
	[MNAME] [varchar](250) NULL,
	[FULLNAME] [varchar](250) NULL,
	[SUFNAME] [varchar](250) NULL,
	[TITLE] [varchar](250) NULL,
	[GENDER] [varchar](250) NULL,
	[DOMAIN] [varchar](250) NULL,
	[CVTDATE] [varchar](250) NULL,
	[ADSUFFIX] [varchar](250) NULL,
	[ADDTYPE] [varchar](250) NULL,
	[CRRT] [varchar](250) NULL,
	[CASSCODE] [varchar](250) NULL,
	[CKDIGIT] [varchar](250) NULL,
	[CNTRYCODE] [varchar](250) NULL,
	[CNTYCODE] [varchar](250) NULL,
	[CNTYNAME] [varchar](250) NULL,
	[DELPT] [varchar](250) NULL,
	[DPV] [varchar](250) NULL,
	[DPVFTNOTE] [varchar](250) NULL,
	[DPV_VACANT] [varchar](250) NULL,
	[LACSINDC] [varchar](250) NULL,
	[LOT] [varchar](250) NULL,
	[LOTORDER] [varchar](250) NULL,
	[DPVNOSTAT] [varchar](250) NULL,
	[POSDIR] [varchar](250) NULL,
	[PREDIR] [varchar](250) NULL,
	[UNITTYPE] [varchar](250) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DATA_FEED_CATALOG]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[DATA_FEED_CATALOG](
	[CATALOG_ID] [bigint] IDENTITY(1,1) NOT NULL,
	[FEED_ID] [varchar](10) NULL,
	[FEED_TYPE] [varchar](50) NULL,
	[FEED_MASK] [varchar](50) NULL,
	[TABLE_PREFIX] [varchar](50) NULL,
	[ETL_JOB] [varchar](50) NULL,
	[FEED_GROUP] [varchar](50) NULL,
	[FEED_GROUP_STEPS] [int] NULL,
	[FEED_GROUP_STEPS_NO] [int] NULL,
	[FEED_GROUP_DATE_RANGE] [varchar](50) NULL,
	[JOB_CONTEXT] [varchar](10) NULL,
	[FIELD_SEPRATOR] [varchar](5) NULL,
	[FILE_EXTENSION] [varchar](5) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DATA_FEED_MAPPING]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[DATA_FEED_MAPPING](
	[MAP_ID] [bigint] IDENTITY(1,1) NOT NULL,
	[FEED_ID] [varchar](10) NULL,
	[INPUT_FEED_COLUMN] [varchar](50) NULL,
	[OUTPUT_LTD_COLUMN] [varchar](50) NULL,
	[MIN_LENGTH] [int] NULL,
	[MAX_LENGTH] [int] NULL,
	[COLUMN_ORDER] [int] NULL,
	[PII_TYPE] [varchar](50) NULL,
	[IS_MANDATORY] [bit] NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DIRECT_ITEMS_DAILY]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[DIRECT_ITEMS_DAILY](
	[ACCTNO] [varchar](150) NULL,
	[ITMORDNO] [varchar](53) NOT NULL,
	[ITMDATE] [varchar](50) NULL,
	[LINENUM] [varchar](150) NULL,
	[ITMNO] [varchar](150) NULL,
	[ITMQTY] [varchar](20) NULL,
	[ITMPRICE] [varchar](20) NULL,
	[ITMSOURCE] [varchar](150) NULL,
	[ITMDESC] [varchar](250) NULL,
	[ITMSTATUS] [varchar](250) NULL,
	[ITMCOST] [varchar](20) NULL,
	[ITMCANCEL] [varchar](20) NULL,
	[ITMRETURN] [varchar](20) NULL,
	[ITMRTNDATE] [varchar](20) NULL,
	[ITMDISCNT] [varchar](20) NULL,
	[ITMTAX] [varchar](20) NULL,
	[RETREASON] [varchar](150) NULL,
	[ITMCOUPON] [varchar](250) NULL,
	[ISTORENO] [varchar](250) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DIRECT_ITEMS_LTD]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[DIRECT_ITEMS_LTD](
	[ACCTNO] [varchar](150) NULL,
	[ITMORDNO] [varchar](150) NULL,
	[LINENUM] [varchar](150) NULL,
	[ITMNO] [varchar](150) NULL,
	[ITMDATE] [varchar](50) NULL,
	[ITMQTY] [varchar](150) NULL,
	[ITMPRICE] [varchar](150) NULL,
	[ITMSOURCE] [varchar](150) NULL,
	[ITMDESC] [varchar](150) NULL,
	[ITMSTATUS] [varchar](150) NULL,
	[ITMCOST] [varchar](150) NULL,
	[ITMCANCEL] [varchar](150) NULL,
	[ITMRETURN] [varchar](150) NULL,
	[ITMRTNDATE] [varchar](150) NULL,
	[ITMDISCNT] [varchar](150) NULL,
	[ITMTAX] [varchar](150) NULL,
	[RETREASON] [varchar](150) NULL,
	[ITMCOUPON] [varchar](150) NULL,
	[ISTORENO] [varchar](150) NULL,
	[FILENAME] [varchar](150) NULL,
	[SEQ] [varchar](150) NULL,
	[FILEDATE] [varchar](150) NULL,
	[INSERTDATE] [varchar](50) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DIRECT_ITEMS_RAW]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[DIRECT_ITEMS_RAW](
	[ACCTNO] [varchar](150) NULL,
	[ITMORDNO] [varchar](150) NULL,
	[LINENUM] [varchar](150) NULL,
	[ITMNO] [varchar](150) NULL,
	[ITMDATE] [varchar](50) NULL,
	[ITMQTY] [varchar](150) NULL,
	[ITMPRICE] [varchar](150) NULL,
	[ITMSOURCE] [varchar](150) NULL,
	[ITMDESC] [varchar](150) NULL,
	[ITMSTATUS] [varchar](150) NULL,
	[ITMCOST] [varchar](150) NULL,
	[ITMCANCEL] [varchar](150) NULL,
	[ITMRETURN] [varchar](150) NULL,
	[ITMRTNDATE] [varchar](150) NULL,
	[ITMDISCNT] [varchar](150) NULL,
	[ITMTAX] [varchar](150) NULL,
	[RETREASON] [varchar](150) NULL,
	[ITMCOUPON] [varchar](150) NULL,
	[ISTORENO] [varchar](150) NULL,
	[FILENAME] [varchar](150) NULL,
	[SEQ] [varchar](150) NULL,
	[FILEDATE] [varchar](150) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DIRECT_ITEMS_RAW_API]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[DIRECT_ITEMS_RAW_API](
	[ACCTNO] [varchar](150) NULL,
	[COUNTRYFLG] [varchar](150) NULL,
	[CATALOG] [varchar](150) NULL,
	[ITMCHANNEL] [varchar](150) NULL,
	[DEPT] [varchar](150) NULL,
	[DEPTRFS] [varchar](150) NULL,
	[DSCNTCODE] [varchar](150) NULL,
	[DSCNTTYPE] [varchar](150) NULL,
	[INITIALDTE] [varchar](150) NULL,
	[ITEMNO] [varchar](150) NULL,
	[ITMDATE] [varchar](150) NULL,
	[LINENUM] [varchar](150) NULL,
	[ORDERTYPE] [varchar](150) NULL,
	[ITEMORDNO] [varchar](150) NULL,
	[ORIGLINENO] [varchar](150) NULL,
	[ORIGORDNO] [varchar](150) NULL,
	[ORIGSHIPTO] [varchar](150) NULL,
	[PAGENUM] [varchar](150) NULL,
	[DEMANDFLAG] [varchar](150) NULL,
	[RECORDTYPE] [varchar](150) NULL,
	[RETAILAMT] [varchar](150) NULL,
	[RETREASON] [varchar](150) NULL,
	[SEQNO] [varchar](150) NULL,
	[SIZE] [varchar](150) NULL,
	[COLOR] [varchar](150) NULL,
	[SKU] [varchar](150) NULL,
	[ITMSTORENO] [varchar](150) NULL,
	[ITMSUBCHAN] [varchar](150) NULL,
	[TRANSNO] [varchar](150) NULL,
	[TRANSTYPE] [varchar](150) NULL,
	[ITMALTLOC] [varchar](150) NULL,
	[MERCHCNCPT] [varchar](150) NULL,
	[RETURNNO] [varchar](150) NULL,
	[SOURCECODE] [varchar](150) NULL,
	[ORGPRICE] [varchar](150) NULL,
	[DISCNTAMT] [varchar](150) NULL,
	[FILENAME] [varchar](150) NULL,
	[SEQ] [varchar](150) NULL,
	[FILEDATE] [varchar](150) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DIRECT_ORDERS_DAILY]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[DIRECT_ORDERS_DAILY](
	[ACCTNO] [varchar](150) NULL,
	[ORDNO] [varchar](53) NOT NULL,
	[ORDDATE] [varchar](50) NULL,
	[ORDTDOL] [varchar](20) NULL,
	[ORDCHANNEL] [varchar](250) NULL,
	[EMAIL] [varchar](250) NULL,
	[PHONE] [varchar](25) NULL,
	[ORDITEMQTY] [varchar](20) NULL,
	[ORDSOURCE] [varchar](150) NULL,
	[ORDCOGS] [varchar](20) NULL,
	[ORDCANCEL] [varchar](20) NULL,
	[ORDRETURN] [varchar](20) NULL,
	[ORDDISCNT] [varchar](20) NULL,
	[ORDPOSTAGE] [varchar](20) NULL,
	[TAXAMT] [varchar](20) NULL,
	[STORENO] [varchar](150) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DIRECT_ORDERS_LTD]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[DIRECT_ORDERS_LTD](
	[ACCTNO] [varchar](50) NULL,
	[ORDNO] [varchar](250) NULL,
	[ORDDATE] [varchar](50) NULL,
	[ORDTDOL] [varchar](30) NULL,
	[ORDCHANNEL] [varchar](250) NULL,
	[EMAIL] [varchar](250) NULL,
	[PHONE] [varchar](25) NULL,
	[ORDITEMQTY] [varchar](30) NULL,
	[ORDSOURCE] [varchar](250) NULL,
	[ORDCOGS] [varchar](30) NULL,
	[ORDCANCEL] [varchar](30) NULL,
	[ORDRETURN] [varchar](30) NULL,
	[ORDDISCNT] [varchar](30) NULL,
	[ORDPOSTAGE] [varchar](30) NULL,
	[TAXAMT] [varchar](30) NULL,
	[STORENO] [varchar](250) NULL,
	[FILENAME] [varchar](150) NULL,
	[SEQ] [varchar](150) NULL,
	[FILEDATE] [varchar](150) NULL,
	[INSERTDATE] [varchar](50) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DIRECT_ORDERS_RAW]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[DIRECT_ORDERS_RAW](
	[ACCTNO] [varchar](50) NULL,
	[ORDNO] [varchar](250) NULL,
	[ORDDATE] [varchar](50) NULL,
	[ORDTDOL] [varchar](30) NULL,
	[ORDCHANNEL] [varchar](250) NULL,
	[EMAIL] [varchar](250) NULL,
	[PHONE] [varchar](25) NULL,
	[ORDITEMQTY] [varchar](30) NULL,
	[ORDSOURCE] [varchar](250) NULL,
	[ORDCOGS] [varchar](30) NULL,
	[ORDCANCEL] [varchar](30) NULL,
	[ORDRETURN] [varchar](30) NULL,
	[ORDDISCNT] [varchar](30) NULL,
	[ORDPOSTAGE] [varchar](30) NULL,
	[TAXAMT] [varchar](30) NULL,
	[STORENO] [varchar](250) NULL,
	[FILENAME] [varchar](150) NULL,
	[SEQ] [varchar](150) NULL,
	[FILEDATE] [varchar](150) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DIRECT_ORDERS_RAW_API]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[DIRECT_ORDERS_RAW_API](
	[ORDDATE] [varchar](150) NULL,
	[ACCTNO] [varchar](150) NULL,
	[STORENO] [varchar](150) NULL,
	[ORDALTLOC] [varchar](150) NULL,
	[ORDERTYPE] [varchar](150) NULL,
	[ORDNO] [varchar](150) NULL,
	[ORDSOURCE] [varchar](150) NULL,
	[SOURCETYPE] [varchar](150) NULL,
	[FILENAME] [varchar](150) NULL,
	[SEQ] [varchar](150) NULL,
	[FILEDATE] [varchar](150) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[EMAIL_BOUNCES_DAILY]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[EMAIL_BOUNCES_DAILY](
	[EMAILTYPE] [varchar](250) NULL,
	[INTSOURCE] [varchar](250) NULL,
	[EMAIL] [varchar](250) NULL,
	[ACCTNO] [varchar](50) NULL,
	[INTDATE] [varchar](150) NULL,
	[DNEFLAG] [varchar](10) NULL,
	[EMAILPREF] [varchar](20) NULL,
	[IPADDRESS] [varchar](25) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[EMAIL_BOUNCES_LTD]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[EMAIL_BOUNCES_LTD](
	[EMAILTYPE] [varchar](100) NULL,
	[INTSOURCE] [varchar](100) NULL,
	[EMAIL] [varchar](100) NULL,
	[ACCTNO] [varchar](100) NULL,
	[INTDATE] [varchar](150) NULL,
	[DNEFLAG] [varchar](100) NULL,
	[EMAILPREF] [varchar](100) NULL,
	[IPADDRESS] [varchar](250) NULL,
	[FILENAME] [varchar](100) NULL,
	[SEQ] [varchar](100) NULL,
	[FILEDATE] [varchar](100) NULL,
	[INSERTDATE] [varchar](50) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[EMAIL_BOUNCES_RAW]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[EMAIL_BOUNCES_RAW](
	[EMAILTYPE] [varchar](100) NULL,
	[INTSOURCE] [varchar](100) NULL,
	[EMAIL] [varchar](100) NULL,
	[ACCTNO] [varchar](100) NULL,
	[INTDATE] [varchar](150) NULL,
	[DNEFLAG] [varchar](100) NULL,
	[EMAILPREF] [varchar](100) NULL,
	[IPADDRESS] [varchar](250) NULL,
	[FILENAME] [varchar](100) NULL,
	[SEQ] [varchar](100) NULL,
	[FILEDATE] [varchar](100) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[EMAIL_CLICKS_DAILY]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[EMAIL_CLICKS_DAILY](
	[EMAILTYPE] [varchar](250) NULL,
	[INTSOURCE] [varchar](250) NULL,
	[EMAIL] [varchar](250) NULL,
	[ACCTNO] [varchar](50) NULL,
	[INTDATE] [varchar](150) NULL,
	[DNEFLAG] [varchar](10) NULL,
	[EMAILPREF] [varchar](20) NULL,
	[IPADDRESS] [varchar](25) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[EMAIL_CLICKS_LTD]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[EMAIL_CLICKS_LTD](
	[EMAILTYPE] [varchar](100) NULL,
	[INTSOURCE] [varchar](100) NULL,
	[EMAIL] [varchar](100) NULL,
	[ACCTNO] [varchar](100) NULL,
	[INTDATE] [varchar](150) NULL,
	[DNEFLAG] [varchar](100) NULL,
	[EMAILPREF] [varchar](100) NULL,
	[IPADDRESS] [varchar](250) NULL,
	[FILENAME] [varchar](100) NULL,
	[SEQ] [varchar](100) NULL,
	[FILEDATE] [varchar](100) NULL,
	[INSERTDATE] [varchar](50) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[EMAIL_CLICKS_RAW]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[EMAIL_CLICKS_RAW](
	[EMAILTYPE] [varchar](250) NULL,
	[INTSOURCE] [varchar](250) NULL,
	[EMAIL] [varchar](250) NOT NULL,
	[ACCTNO] [varchar](50) NULL,
	[INTDATE] [varchar](50) NOT NULL,
	[DNEFLAG] [varchar](10) NULL,
	[EMAILPREF] [varchar](10) NULL,
	[IPADDRESS] [varchar](25) NULL,
	[FILENAME] [varchar](100) NULL,
	[SEQ] [varchar](100) NULL,
	[FILEDATE] [varchar](100) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[EMAIL_OPENS_DAILY]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[EMAIL_OPENS_DAILY](
	[EMAILTYPE] [varchar](250) NULL,
	[INTSOURCE] [varchar](250) NULL,
	[EMAIL] [varchar](250) NULL,
	[ACCTNO] [varchar](50) NULL,
	[INTDATE] [varchar](150) NULL,
	[DNEFLAG] [varchar](10) NULL,
	[EMAILPREF] [varchar](20) NULL,
	[IPADDRESS] [varchar](25) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[EMAIL_OPENS_LTD]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[EMAIL_OPENS_LTD](
	[EMAILTYPE] [varchar](100) NULL,
	[INTSOURCE] [varchar](100) NULL,
	[EMAIL] [varchar](100) NULL,
	[ACCTNO] [varchar](100) NULL,
	[INTDATE] [varchar](150) NULL,
	[DNEFLAG] [varchar](100) NULL,
	[EMAILPREF] [varchar](100) NULL,
	[IPADDRESS] [varchar](250) NULL,
	[FILENAME] [varchar](100) NULL,
	[SEQ] [varchar](100) NULL,
	[FILEDATE] [varchar](100) NULL,
	[INSERTDATE] [varchar](50) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[EMAIL_OPENS_RAW]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[EMAIL_OPENS_RAW](
	[EMAILTYPE] [varchar](250) NULL,
	[INTSOURCE] [varchar](250) NULL,
	[EMAIL] [varchar](250) NULL,
	[ACCTNO] [varchar](50) NULL,
	[INTDATE] [datetime] NULL,
	[DNEFLAG] [varchar](10) NULL,
	[EMAILPREF] [varchar](10) NULL,
	[IPADDRESS] [varchar](25) NULL,
	[FILENAME] [varchar](100) NULL,
	[SEQ] [varchar](100) NULL,
	[FILEDATE] [varchar](100) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[EMAIL_OPTOUTS_DAILY]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[EMAIL_OPTOUTS_DAILY](
	[EMAILTYPE] [varchar](250) NULL,
	[INTSOURCE] [varchar](250) NULL,
	[EMAIL] [varchar](250) NULL,
	[ACCTNO] [varchar](50) NULL,
	[INTDATE] [varchar](50) NULL,
	[DNEFLAG] [varchar](10) NULL,
	[EMAILPREF] [varchar](20) NULL,
	[IPADDRESS] [varchar](25) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[EMAIL_SENDS_DAILY]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[EMAIL_SENDS_DAILY](
	[EMAILTYPE] [varchar](250) NULL,
	[INTSOURCE] [varchar](250) NULL,
	[EMAIL] [varchar](250) NULL,
	[ACCTNO] [varchar](50) NULL,
	[INTDATE] [varchar](50) NULL,
	[DNEFLAG] [varchar](10) NULL,
	[EMAILPREF] [varchar](20) NULL,
	[IPADDRESS] [varchar](25) NULL,
	[MESSAGEID] [varchar](40) NULL,
	[CAMPAIGNID] [varchar](40) NULL,
	[CAMPNAME] [varchar](250) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[EMAIL_SENDS_LTD]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[EMAIL_SENDS_LTD](
	[EMAILTYPE] [varchar](250) NULL,
	[INTSOURCE] [varchar](250) NULL,
	[EMAIL] [varchar](250) NULL,
	[ACCTNO] [varchar](50) NULL,
	[INTDATE] [varchar](50) NULL,
	[DNEFLAG] [varchar](10) NULL,
	[EMAILPREF] [varchar](20) NULL,
	[IPADDRESS] [varchar](25) NULL,
	[MESSAGEID] [varchar](40) NULL,
	[CAMPAIGNID] [varchar](40) NULL,
	[CAMPNAME] [varchar](250) NULL,
	[FILENAME] [varchar](150) NULL,
	[SEQ] [varchar](50) NULL,
	[FILEDATE] [varchar](50) NULL,
	[INSERTDATE] [varchar](50) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[EMAIL_SENDS_RAW]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[EMAIL_SENDS_RAW](
	[EMAILTYPE] [varchar](250) NULL,
	[INTSOURCE] [varchar](250) NULL,
	[EMAIL] [varchar](250) NULL,
	[ACCTNO] [varchar](50) NULL,
	[INTDATE] [varchar](50) NULL,
	[DNEFLAG] [varchar](10) NULL,
	[EMAILPREF] [varchar](20) NULL,
	[IPADDRESS] [varchar](25) NULL,
	[MESSAGEID] [varchar](40) NULL,
	[CAMPAIGNID] [varchar](40) NULL,
	[CAMPNAME] [varchar](250) NULL,
	[FILENAME] [varchar](150) NULL,
	[SEQ] [varchar](50) NULL,
	[FILEDATE] [varchar](50) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[EMAIL_SUBS_DAILY]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[EMAIL_SUBS_DAILY](
	[EMAILTYPE] [varchar](250) NULL,
	[INTSOURCE] [varchar](250) NULL,
	[EMAIL] [varchar](250) NULL,
	[ACCTNO] [varchar](50) NULL,
	[INTDATE] [varchar](50) NULL,
	[DNEFLAG] [varchar](10) NULL,
	[EMAILPREF] [varchar](20) NULL,
	[IPADDRESS] [varchar](25) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[EMAIL_SUBS_LTD]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[EMAIL_SUBS_LTD](
	[EMAILTYPE] [varchar](100) NULL,
	[INTSOURCE] [varchar](100) NULL,
	[EMAIL] [varchar](250) NULL,
	[ACCTNO] [varchar](100) NULL,
	[INTDATE] [varchar](150) NULL,
	[DNEFLAG] [varchar](100) NULL,
	[EMAILPREF] [varchar](100) NULL,
	[IPADDRESS] [varchar](250) NULL,
	[FILENAME] [varchar](100) NULL,
	[SEQ] [varchar](100) NULL,
	[FILEDATE] [varchar](100) NULL,
	[INSERTDATE] [varchar](50) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[EMAIL_SUBS_RAW]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[EMAIL_SUBS_RAW](
	[EMAILTYPE] [varchar](250) NULL,
	[INTSOURCE] [varchar](250) NULL,
	[EMAIL] [varchar](250) NOT NULL,
	[ACCTNO] [varchar](50) NULL,
	[INTDATE] [varchar](50) NOT NULL,
	[DNEFLAG] [varchar](10) NULL,
	[EMAILPREF] [varchar](10) NULL,
	[IPADDRESS] [varchar](25) NULL,
	[FILENAME] [varchar](100) NULL,
	[SEQ] [varchar](100) NULL,
	[FILEDATE] [varchar](100) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[EMAIL_SUBS_RAW_API]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[EMAIL_SUBS_RAW_API](
	[EMAIL] [varchar](250) NULL,
	[DATE_SUB] [varchar](50) NULL,
	[RCODE] [varchar](50) NULL,
	[AFFILIATE_ID] [varchar](50) NULL,
	[EMAIL_CONTACT_PREFERENCE] [varchar](50) NULL,
	[EVENT_DATE] [varchar](50) NULL,
	[EXP_AD] [varchar](50) NULL,
	[FILENAME] [varchar](50) NULL,
	[SEQ] [varchar](50) NULL,
	[FILEDATE] [varchar](50) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[EMAIL_UNSUBS_LTD]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[EMAIL_UNSUBS_LTD](
	[EMAILTYPE] [varchar](100) NULL,
	[INTSOURCE] [varchar](100) NULL,
	[EMAIL] [varchar](100) NULL,
	[ACCTNO] [varchar](100) NULL,
	[INTDATE] [varchar](150) NULL,
	[DNEFLAG] [varchar](100) NULL,
	[EMAILPREF] [varchar](100) NULL,
	[IPADDRESS] [varchar](250) NULL,
	[FILENAME] [varchar](100) NULL,
	[SEQ] [varchar](100) NULL,
	[FILEDATE] [varchar](100) NULL,
	[INSERTDATE] [varchar](50) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[EMAIL_UNSUBS_RAW]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[EMAIL_UNSUBS_RAW](
	[EMAILTYPE] [varchar](250) NULL,
	[INTSOURCE] [varchar](250) NULL,
	[EMAIL] [varchar](250) NOT NULL,
	[ACCTNO] [varchar](50) NULL,
	[INTDATE] [varchar](50) NOT NULL,
	[DNEFLAG] [varchar](10) NULL,
	[EMAILPREF] [varchar](10) NULL,
	[IPADDRESS] [varchar](25) NULL,
	[FILENAME] [varchar](100) NULL,
	[SEQ] [varchar](100) NULL,
	[FILEDATE] [varchar](100) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GDPR_AUDIT_TABLE_11_20_2019_14_12_17]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[GDPR_AUDIT_TABLE_11_20_2019_14_12_17](
	[DELETION_KEY] [nvarchar](50) NULL,
	[DELETION_KEY_VALUE] [nvarchar](50) NULL,
	[DELETION_REQUEST_ID] [nvarchar](50) NULL,
	[DELETION_TABLE] [nvarchar](50) NULL,
	[DELETION_COLUMN] [nvarchar](50) NULL,
	[DELETION_REQUEST_STEP] [nvarchar](50) NULL,
	[DELETION_COLUMN_VALUE] [nvarchar](50) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GDPR_DELETION_REQUEST]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[GDPR_DELETION_REQUEST](
	[REQUEST_ID] [varchar](100) NOT NULL,
	[REQUEST_SOURCE] [varchar](100) NULL,
	[IDENTIFIED_NAME] [varchar](100) NULL,
	[IDENTIFIED_VALUE] [varchar](100) NULL,
	[PROCESS_STATUS] [varchar](100) NULL,
	[PROCESS_DATE] [datetime] NULL,
	[CLIENT_REQUEST_ID] [varchar](100) NULL,
	[CLIENT_REQUEST_DATE] [varchar](100) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[GDPR_PII_FIELD_MAPPING]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[GDPR_PII_FIELD_MAPPING](
	[DB_NAME] [nvarchar](50) NOT NULL,
	[TABLE_SCHEMA] [nvarchar](50) NOT NULL,
	[TABLE_NAME] [nvarchar](50) NOT NULL,
	[COLUMN_NAME] [nvarchar](50) NOT NULL,
	[PII_TYPE] [nvarchar](50) NULL,
	[MASK_TYPE] [nvarchar](50) NULL,
	[COLUMN_PII_DESC] [nvarchar](50) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[HIT_DATA]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[HIT_DATA](
	[accept_language] [varchar](5000) NULL,
	[adclassificationcreative] [varchar](5000) NULL,
	[adload] [varchar](5000) NULL,
	[aemassetid] [varchar](5000) NULL,
	[aemassetsource] [varchar](5000) NULL,
	[aemclickedassetid] [varchar](5000) NULL,
	[browser] [varchar](5000) NULL,
	[browser_height] [varchar](5000) NULL,
	[browser_width] [varchar](5000) NULL,
	[c_color] [varchar](5000) NULL,
	[campaign] [varchar](5000) NULL,
	[carrier] [varchar](5000) NULL,
	[channel] [varchar](5000) NULL,
	[click_action] [varchar](5000) NULL,
	[click_action_type] [varchar](5000) NULL,
	[click_context] [varchar](5000) NULL,
	[click_context_type] [varchar](5000) NULL,
	[click_sourceid] [varchar](5000) NULL,
	[click_tag] [varchar](5000) NULL,
	[clickmaplink] [varchar](5000) NULL,
	[clickmaplinkbyregion] [varchar](5000) NULL,
	[clickmappage] [varchar](5000) NULL,
	[clickmapregion] [varchar](5000) NULL,
	[code_ver] [varchar](5000) NULL,
	[color] [varchar](5000) NULL,
	[connection_type] [varchar](5000) NULL,
	[cookies] [varchar](5000) NULL,
	[country] [varchar](5000) NULL,
	[ct_connect_type] [varchar](5000) NULL,
	[curr_factor] [varchar](5000) NULL,
	[curr_rate] [varchar](5000) NULL,
	[currency] [varchar](5000) NULL,
	[cust_hit_time_gmt] [varchar](5000) NULL,
	[cust_visid] [varchar](5000) NULL,
	[daily_visitor] [varchar](5000) NULL,
	[date_time] [varchar](5000) NULL,
	[domain] [varchar](5000) NULL,
	[duplicate_events] [varchar](5000) NULL,
	[duplicate_purchase] [varchar](5000) NULL,
	[duplicated_from] [varchar](5000) NULL,
	[ef_id] [varchar](5000) NULL,
	[evar1] [varchar](5000) NULL,
	[evar2] [varchar](5000) NULL,
	[evar3] [varchar](5000) NULL,
	[evar4] [varchar](5000) NULL,
	[evar5] [varchar](5000) NULL,
	[evar6] [varchar](5000) NULL,
	[evar7] [varchar](5000) NULL,
	[evar8] [varchar](5000) NULL,
	[evar9] [varchar](5000) NULL,
	[evar10] [varchar](5000) NULL,
	[evar11] [varchar](5000) NULL,
	[evar12] [varchar](5000) NULL,
	[evar13] [varchar](5000) NULL,
	[evar14] [varchar](5000) NULL,
	[evar15] [varchar](5000) NULL,
	[evar16] [varchar](5000) NULL,
	[evar17] [varchar](5000) NULL,
	[evar18] [varchar](5000) NULL,
	[evar19] [varchar](5000) NULL,
	[evar20] [varchar](5000) NULL,
	[evar21] [varchar](5000) NULL,
	[evar22] [varchar](5000) NULL,
	[evar23] [varchar](5000) NULL,
	[evar24] [varchar](5000) NULL,
	[evar25] [varchar](5000) NULL,
	[evar26] [varchar](5000) NULL,
	[evar27] [varchar](5000) NULL,
	[evar28] [varchar](5000) NULL,
	[evar29] [varchar](5000) NULL,
	[evar30] [varchar](5000) NULL,
	[evar31] [varchar](5000) NULL,
	[evar32] [varchar](5000) NULL,
	[evar33] [varchar](5000) NULL,
	[evar34] [varchar](5000) NULL,
	[evar35] [varchar](5000) NULL,
	[evar36] [varchar](5000) NULL,
	[evar37] [varchar](5000) NULL,
	[evar38] [varchar](5000) NULL,
	[evar39] [varchar](5000) NULL,
	[evar40] [varchar](5000) NULL,
	[evar41] [varchar](5000) NULL,
	[evar42] [varchar](5000) NULL,
	[evar43] [varchar](5000) NULL,
	[evar44] [varchar](5000) NULL,
	[evar45] [varchar](5000) NULL,
	[evar46] [varchar](5000) NULL,
	[evar47] [varchar](5000) NULL,
	[evar48] [varchar](5000) NULL,
	[evar49] [varchar](5000) NULL,
	[evar50] [varchar](5000) NULL,
	[evar51] [varchar](5000) NULL,
	[evar52] [varchar](5000) NULL,
	[evar53] [varchar](5000) NULL,
	[evar54] [varchar](5000) NULL,
	[evar55] [varchar](5000) NULL,
	[evar56] [varchar](5000) NULL,
	[evar57] [varchar](5000) NULL,
	[evar58] [varchar](5000) NULL,
	[evar59] [varchar](5000) NULL,
	[evar60] [varchar](5000) NULL,
	[evar61] [varchar](5000) NULL,
	[evar62] [varchar](5000) NULL,
	[evar63] [varchar](5000) NULL,
	[evar64] [varchar](5000) NULL,
	[evar65] [varchar](5000) NULL,
	[evar66] [varchar](5000) NULL,
	[evar67] [varchar](5000) NULL,
	[evar68] [varchar](5000) NULL,
	[evar69] [varchar](5000) NULL,
	[evar70] [varchar](5000) NULL,
	[evar71] [varchar](5000) NULL,
	[evar72] [varchar](5000) NULL,
	[evar73] [varchar](5000) NULL,
	[evar74] [varchar](5000) NULL,
	[evar75] [varchar](5000) NULL,
	[evar76] [varchar](5000) NULL,
	[evar77] [varchar](5000) NULL,
	[evar78] [varchar](5000) NULL,
	[evar79] [varchar](5000) NULL,
	[evar80] [varchar](5000) NULL,
	[evar81] [varchar](5000) NULL,
	[evar82] [varchar](5000) NULL,
	[evar83] [varchar](5000) NULL,
	[evar84] [varchar](5000) NULL,
	[evar85] [varchar](5000) NULL,
	[evar86] [varchar](5000) NULL,
	[evar87] [varchar](5000) NULL,
	[evar88] [varchar](5000) NULL,
	[evar89] [varchar](5000) NULL,
	[evar90] [varchar](5000) NULL,
	[evar91] [varchar](5000) NULL,
	[evar92] [varchar](5000) NULL,
	[evar93] [varchar](5000) NULL,
	[evar94] [varchar](5000) NULL,
	[evar95] [varchar](5000) NULL,
	[evar96] [varchar](5000) NULL,
	[evar97] [varchar](5000) NULL,
	[evar98] [varchar](5000) NULL,
	[evar99] [varchar](5000) NULL,
	[evar100] [varchar](5000) NULL,
	[exclude_hit] [varchar](5000) NULL,
	[first_hit_page_url] [varchar](5000) NULL,
	[first_hit_pagename] [varchar](5000) NULL,
	[first_hit_ref_domain] [varchar](5000) NULL,
	[first_hit_ref_type] [varchar](5000) NULL,
	[first_hit_referrer] [varchar](5000) NULL,
	[first_hit_time_gmt] [varchar](5000) NULL,
	[geo_city] [varchar](5000) NULL,
	[geo_country] [varchar](5000) NULL,
	[geo_dma] [varchar](5000) NULL,
	[geo_region] [varchar](5000) NULL,
	[geo_zip] [varchar](5000) NULL,
	[hier1] [varchar](5000) NULL,
	[hier2] [varchar](5000) NULL,
	[hier3] [varchar](5000) NULL,
	[hier4] [varchar](5000) NULL,
	[hier5] [varchar](5000) NULL,
	[hit_source] [varchar](5000) NULL,
	[hit_time_gmt] [varchar](5000) NULL,
	[hitid_high] [varchar](5000) NULL,
	[hitid_low] [varchar](5000) NULL,
	[homepage] [varchar](5000) NULL,
	[hourly_visitor] [varchar](5000) NULL,
	[ip] [varchar](5000) NULL,
	[ip2] [varchar](5000) NULL,
	[j_jscript] [varchar](5000) NULL,
	[java_enabled] [varchar](5000) NULL,
	[javascript] [varchar](5000) NULL,
	[language] [varchar](5000) NULL,
	[last_hit_time_gmt] [varchar](5000) NULL,
	[last_purchase_num] [varchar](5000) NULL,
	[last_purchase_time_gmt] [varchar](5000) NULL,
	[latlon1] [varchar](5000) NULL,
	[latlon23] [varchar](5000) NULL,
	[latlon45] [varchar](5000) NULL,
	[mc_audiences] [varchar](5000) NULL,
	[mcvisid] [varchar](5000) NULL,
	[mobile_id] [varchar](5000) NULL,
	[mobileacquisitionclicks] [varchar](5000) NULL,
	[mobileaction] [varchar](5000) NULL,
	[mobileactioninapptime] [varchar](5000) NULL,
	[mobileactiontotaltime] [varchar](5000) NULL,
	[mobileappid] [varchar](5000) NULL,
	[mobileappperformanceaffectedusers] [varchar](5000) NULL,
	[mobileappperformanceappid] [varchar](5000) NULL,
	[mobileappperformanceappid_app_perf_app_name] [varchar](5000) NULL,
	[mobileappperformanceappid_app_perf_platform] [varchar](5000) NULL,
	[mobileappperformancecrashes] [varchar](5000) NULL,
	[mobileappperformancecrashid] [varchar](5000) NULL,
	[mobileappperformancecrashid_app_perf_crash_name] [varchar](5000) NULL,
	[mobileappperformanceloads] [varchar](5000) NULL,
	[mobileappstoreavgrating] [varchar](5000) NULL,
	[mobileappstoredownloads] [varchar](5000) NULL,
	[mobileappstoreinapprevenue] [varchar](5000) NULL,
	[mobileappstoreinapproyalties] [varchar](5000) NULL,
	[mobileappstoreobjectid] [varchar](5000) NULL,
	[mobileappstoreobjectid_app_store_user] [varchar](5000) NULL,
	[mobileappstoreobjectid_application_name] [varchar](5000) NULL,
	[mobileappstoreobjectid_application_version] [varchar](5000) NULL,
	[mobileappstoreobjectid_appstore_name] [varchar](5000) NULL,
	[mobileappstoreobjectid_category_name] [varchar](5000) NULL,
	[mobileappstoreobjectid_country_name] [varchar](5000) NULL,
	[mobileappstoreobjectid_device_manufacturer] [varchar](5000) NULL,
	[mobileappstoreobjectid_device_name] [varchar](5000) NULL,
	[mobileappstoreobjectid_in_app_name] [varchar](5000) NULL,
	[mobileappstoreobjectid_platform_name_version] [varchar](5000) NULL,
	[mobileappstoreobjectid_rank_category_type] [varchar](5000) NULL,
	[mobileappstoreobjectid_region_name] [varchar](5000) NULL,
	[mobileappstoreobjectid_review_comment] [varchar](5000) NULL,
	[mobileappstoreobjectid_review_title] [varchar](5000) NULL,
	[mobileappstoreoneoffrevenue] [varchar](5000) NULL,
	[mobileappstoreoneoffroyalties] [varchar](5000) NULL,
	[mobileappstorepurchases] [varchar](5000) NULL,
	[mobileappstorerank] [varchar](5000) NULL,
	[mobileappstorerankdivisor] [varchar](5000) NULL,
	[mobileappstorerating] [varchar](5000) NULL,
	[mobileappstoreratingdivisor] [varchar](5000) NULL,
	[mobileavgprevsessionlength] [varchar](5000) NULL,
	[mobilebeaconmajor] [varchar](5000) NULL,
	[mobilebeaconminor] [varchar](5000) NULL,
	[mobilebeaconproximity] [varchar](5000) NULL,
	[mobilebeaconuuid] [varchar](5000) NULL,
	[mobilecampaigncontent] [varchar](5000) NULL,
	[mobilecampaignmedium] [varchar](5000) NULL,
	[mobilecampaignname] [varchar](5000) NULL,
	[mobilecampaignsource] [varchar](5000) NULL,
	[mobilecampaignterm] [varchar](5000) NULL,
	[mobilecrashes] [varchar](5000) NULL,
	[mobilecrashrate] [varchar](5000) NULL,
	[mobiledailyengagedusers] [varchar](5000) NULL,
	[mobiledayofweek] [varchar](5000) NULL,
	[mobiledayssincefirstuse] [varchar](5000) NULL,
	[mobiledayssincelastupgrade] [varchar](5000) NULL,
	[mobiledayssincelastuse] [varchar](5000) NULL,
	[mobiledeeplinkid] [varchar](5000) NULL,
	[mobiledeeplinkid_name] [varchar](5000) NULL,
	[mobiledevice] [varchar](5000) NULL,
	[mobilehourofday] [varchar](5000) NULL,
	[mobileinstalldate] [varchar](5000) NULL,
	[mobileinstalls] [varchar](5000) NULL,
	[mobilelaunches] [varchar](5000) NULL,
	[mobilelaunchessincelastupgrade] [varchar](5000) NULL,
	[mobilelaunchnumber] [varchar](5000) NULL,
	[mobileltv] [varchar](5000) NULL,
	[mobileltvtotal] [varchar](5000) NULL,
	[mobilemessagebuttonname] [varchar](5000) NULL,
	[mobilemessageclicks] [varchar](5000) NULL,
	[mobilemessageid] [varchar](5000) NULL,
	[mobilemessageid_dest] [varchar](5000) NULL,
	[mobilemessageid_name] [varchar](5000) NULL,
	[mobilemessageid_type] [varchar](5000) NULL,
	[mobilemessageimpressions] [varchar](5000) NULL,
	[mobilemessageonline] [varchar](5000) NULL,
	[mobilemessagepushoptin] [varchar](5000) NULL,
	[mobilemessagepushpayloadid] [varchar](5000) NULL,
	[mobilemessagepushpayloadid_name] [varchar](5000) NULL,
	[mobilemessageviews] [varchar](5000) NULL,
	[mobilemonthlyengagedusers] [varchar](5000) NULL,
	[mobileosenvironment] [varchar](5000) NULL,
	[mobileosversion] [varchar](5000) NULL,
	[mobileplaceaccuracy] [varchar](5000) NULL,
	[mobileplacecategory] [varchar](5000) NULL,
	[mobileplacedwelltime] [varchar](5000) NULL,
	[mobileplaceentry] [varchar](5000) NULL,
	[mobileplaceexit] [varchar](5000) NULL,
	[mobileplaceid] [varchar](5000) NULL,
	[mobileprevsessionlength] [varchar](5000) NULL,
	[mobilepushoptin] [varchar](5000) NULL,
	[mobilepushpayloadid] [varchar](5000) NULL,
	[mobilerelaunchcampaigncontent] [varchar](5000) NULL,
	[mobilerelaunchcampaignmedium] [varchar](5000) NULL,
	[mobilerelaunchcampaignsource] [varchar](5000) NULL,
	[mobilerelaunchcampaignterm] [varchar](5000) NULL,
	[mobilerelaunchcampaigntrackingcode] [varchar](5000) NULL,
	[mobilerelaunchcampaigntrackingcode_name] [varchar](5000) NULL,
	[mobileresolution] [varchar](5000) NULL,
	[mobileupgrades] [varchar](5000) NULL,
	[monthly_visitor] [varchar](5000) NULL,
	[mvvar1] [varchar](5000) NULL,
	[mvvar2] [varchar](5000) NULL,
	[mvvar3] [varchar](5000) NULL,
	[namespace] [varchar](5000) NULL,
	[new_visit] [varchar](5000) NULL,
	[os] [varchar](5000) NULL,
	[p_plugins] [varchar](5000) NULL,
	[page_event] [varchar](5000) NULL,
	[page_event_var1] [varchar](5000) NULL,
	[page_event_var2] [varchar](5000) NULL,
	[page_event_var3] [varchar](5000) NULL,
	[page_type] [varchar](5000) NULL,
	[page_url] [varchar](5000) NULL,
	[pagename] [varchar](5000) NULL,
	[paid_search] [varchar](5000) NULL,
	[partner_plugins] [varchar](5000) NULL,
	[persistent_cookie] [varchar](5000) NULL,
	[plugins] [varchar](5000) NULL,
	[pointofinterest] [varchar](5000) NULL,
	[pointofinterestdistance] [varchar](5000) NULL,
	[post_adclassificationcreative] [varchar](5000) NULL,
	[post_adload] [varchar](5000) NULL,
	[post_browser_height] [varchar](5000) NULL,
	[post_browser_width] [varchar](5000) NULL,
	[post_campaign] [varchar](5000) NULL,
	[post_channel] [varchar](5000) NULL,
	[post_clickmaplink] [varchar](5000) NULL,
	[post_clickmaplinkbyregion] [varchar](5000) NULL,
	[post_clickmappage] [varchar](5000) NULL,
	[post_clickmapregion] [varchar](5000) NULL,
	[post_cookies] [varchar](5000) NULL,
	[post_currency] [varchar](5000) NULL,
	[post_cust_hit_time_gmt] [varchar](5000) NULL,
	[post_cust_visid] [varchar](5000) NULL,
	[post_ef_id] [varchar](5000) NULL,
	[post_evar1] [varchar](5000) NULL,
	[post_evar2] [varchar](5000) NULL,
	[post_evar3] [varchar](5000) NULL,
	[post_evar4] [varchar](5000) NULL,
	[post_evar5] [varchar](5000) NULL,
	[post_evar6] [varchar](5000) NULL,
	[post_evar7] [varchar](5000) NULL,
	[post_evar8] [varchar](5000) NULL,
	[post_evar9] [varchar](5000) NULL,
	[post_evar10] [varchar](5000) NULL,
	[post_evar11] [varchar](5000) NULL,
	[post_evar12] [varchar](5000) NULL,
	[post_evar13] [varchar](5000) NULL,
	[post_evar14] [varchar](5000) NULL,
	[post_evar15] [varchar](5000) NULL,
	[post_evar16] [varchar](5000) NULL,
	[post_evar17] [varchar](5000) NULL,
	[post_evar18] [varchar](5000) NULL,
	[post_evar19] [varchar](5000) NULL,
	[post_evar20] [varchar](5000) NULL,
	[post_evar21] [varchar](5000) NULL,
	[post_evar22] [varchar](5000) NULL,
	[post_evar23] [varchar](5000) NULL,
	[post_evar24] [varchar](5000) NULL,
	[post_evar25] [varchar](5000) NULL,
	[post_evar26] [varchar](5000) NULL,
	[post_evar27] [varchar](5000) NULL,
	[post_evar28] [varchar](5000) NULL,
	[post_evar29] [varchar](5000) NULL,
	[post_evar30] [varchar](5000) NULL,
	[post_evar31] [varchar](5000) NULL,
	[post_evar32] [varchar](5000) NULL,
	[post_evar33] [varchar](5000) NULL,
	[post_evar34] [varchar](5000) NULL,
	[post_evar35] [varchar](5000) NULL,
	[post_evar36] [varchar](5000) NULL,
	[post_evar37] [varchar](5000) NULL,
	[post_evar38] [varchar](5000) NULL,
	[post_evar39] [varchar](5000) NULL,
	[post_evar40] [varchar](5000) NULL,
	[post_evar41] [varchar](5000) NULL,
	[post_evar42] [varchar](5000) NULL,
	[post_evar43] [varchar](5000) NULL,
	[post_evar44] [varchar](5000) NULL,
	[post_evar45] [varchar](5000) NULL,
	[post_evar46] [varchar](5000) NULL,
	[post_evar47] [varchar](5000) NULL,
	[post_evar48] [varchar](5000) NULL,
	[post_evar49] [varchar](5000) NULL,
	[post_evar50] [varchar](5000) NULL,
	[post_evar51] [varchar](5000) NULL,
	[post_evar52] [varchar](5000) NULL,
	[post_evar53] [varchar](5000) NULL,
	[post_evar54] [varchar](5000) NULL,
	[post_evar55] [varchar](5000) NULL,
	[post_evar56] [varchar](5000) NULL,
	[post_evar57] [varchar](5000) NULL,
	[post_evar58] [varchar](5000) NULL,
	[post_evar59] [varchar](5000) NULL,
	[post_evar60] [varchar](5000) NULL,
	[post_evar61] [varchar](5000) NULL,
	[post_evar62] [varchar](5000) NULL,
	[post_evar63] [varchar](5000) NULL,
	[post_evar64] [varchar](5000) NULL,
	[post_evar65] [varchar](5000) NULL,
	[post_evar66] [varchar](5000) NULL,
	[post_evar67] [varchar](5000) NULL,
	[post_evar68] [varchar](5000) NULL,
	[post_evar69] [varchar](5000) NULL,
	[post_evar70] [varchar](5000) NULL,
	[post_evar71] [varchar](5000) NULL,
	[post_evar72] [varchar](5000) NULL,
	[post_evar73] [varchar](5000) NULL,
	[post_evar74] [varchar](5000) NULL,
	[post_evar75] [varchar](5000) NULL,
	[post_evar76] [varchar](5000) NULL,
	[post_evar77] [varchar](5000) NULL,
	[post_evar78] [varchar](5000) NULL,
	[post_evar79] [varchar](5000) NULL,
	[post_evar80] [varchar](5000) NULL,
	[post_evar81] [varchar](5000) NULL,
	[post_evar82] [varchar](5000) NULL,
	[post_evar83] [varchar](5000) NULL,
	[post_evar84] [varchar](5000) NULL,
	[post_evar85] [varchar](5000) NULL,
	[post_evar86] [varchar](5000) NULL,
	[post_evar87] [varchar](5000) NULL,
	[post_evar88] [varchar](5000) NULL,
	[post_evar89] [varchar](5000) NULL,
	[post_evar90] [varchar](5000) NULL,
	[post_evar91] [varchar](5000) NULL,
	[post_evar92] [varchar](5000) NULL,
	[post_evar93] [varchar](5000) NULL,
	[post_evar94] [varchar](5000) NULL,
	[post_evar95] [varchar](5000) NULL,
	[post_evar96] [varchar](5000) NULL,
	[post_evar97] [varchar](5000) NULL,
	[post_evar98] [varchar](5000) NULL,
	[post_evar99] [varchar](5000) NULL,
	[post_evar100] [varchar](5000) NULL,
	[post_event_list] [varchar](5000) NULL,
	[post_hier1] [varchar](5000) NULL,
	[post_hier2] [varchar](5000) NULL,
	[post_hier3] [varchar](5000) NULL,
	[post_hier4] [varchar](5000) NULL,
	[post_hier5] [varchar](5000) NULL,
	[post_java_enabled] [varchar](5000) NULL,
	[post_keywords] [varchar](5000) NULL,
	[post_mc_audiences] [varchar](5000) NULL,
	[post_mobileaction] [varchar](5000) NULL,
	[post_mobileappid] [varchar](5000) NULL,
	[post_mobilecampaigncontent] [varchar](5000) NULL,
	[post_mobilecampaignmedium] [varchar](5000) NULL,
	[post_mobilecampaignname] [varchar](5000) NULL,
	[post_mobilecampaignsource] [varchar](5000) NULL,
	[post_mobilecampaignterm] [varchar](5000) NULL,
	[post_mobiledayofweek] [varchar](5000) NULL,
	[post_mobiledayssincefirstuse] [varchar](5000) NULL,
	[post_mobiledayssincelastuse] [varchar](5000) NULL,
	[post_mobiledevice] [varchar](5000) NULL,
	[post_mobilehourofday] [varchar](5000) NULL,
	[post_mobileinstalldate] [varchar](5000) NULL,
	[post_mobilelaunchnumber] [varchar](5000) NULL,
	[post_mobileltv] [varchar](5000) NULL,
	[post_mobilemessagebuttonname] [varchar](5000) NULL,
	[post_mobilemessageclicks] [varchar](5000) NULL,
	[post_mobilemessageid] [varchar](5000) NULL,
	[post_mobilemessageid_dest] [varchar](5000) NULL,
	[post_mobilemessageid_name] [varchar](5000) NULL,
	[post_mobilemessageid_type] [varchar](5000) NULL,
	[post_mobilemessageimpressions] [varchar](5000) NULL,
	[post_mobilemessageonline] [varchar](5000) NULL,
	[post_mobilemessagepushoptin] [varchar](5000) NULL,
	[post_mobilemessagepushpayloadid] [varchar](5000) NULL,
	[post_mobilemessagepushpayloadid_name] [varchar](5000) NULL,
	[post_mobilemessageviews] [varchar](5000) NULL,
	[post_mobileosversion] [varchar](5000) NULL,
	[post_mobilepushoptin] [varchar](5000) NULL,
	[post_mobilepushpayloadid] [varchar](5000) NULL,
	[post_mobileresolution] [varchar](5000) NULL,
	[post_mvvar1] [varchar](5000) NULL,
	[post_mvvar2] [varchar](5000) NULL,
	[post_mvvar3] [varchar](5000) NULL,
	[post_page_event] [varchar](5000) NULL,
	[post_page_event_var1] [varchar](5000) NULL,
	[post_page_event_var2] [varchar](5000) NULL,
	[post_page_event_var3] [varchar](5000) NULL,
	[post_page_type] [varchar](5000) NULL,
	[post_page_url] [varchar](5000) NULL,
	[post_pagename] [varchar](5000) NULL,
	[post_pagename_no_url] [varchar](5000) NULL,
	[post_partner_plugins] [varchar](5000) NULL,
	[post_persistent_cookie] [varchar](5000) NULL,
	[post_pointofinterest] [varchar](5000) NULL,
	[post_pointofinterestdistance] [varchar](5000) NULL,
	[post_product_list] [varchar](5000) NULL,
	[post_prop1] [varchar](5000) NULL,
	[post_prop2] [varchar](5000) NULL,
	[post_prop3] [varchar](5000) NULL,
	[post_prop4] [varchar](5000) NULL,
	[post_prop5] [varchar](5000) NULL,
	[post_prop6] [varchar](5000) NULL,
	[post_prop7] [varchar](5000) NULL,
	[post_prop8] [varchar](5000) NULL,
	[post_prop9] [varchar](5000) NULL,
	[post_prop10] [varchar](5000) NULL,
	[post_prop11] [varchar](5000) NULL,
	[post_prop12] [varchar](5000) NULL,
	[post_prop13] [varchar](5000) NULL,
	[post_prop14] [varchar](5000) NULL,
	[post_prop15] [varchar](5000) NULL,
	[post_prop16] [varchar](5000) NULL,
	[post_prop17] [varchar](5000) NULL,
	[post_prop18] [varchar](5000) NULL,
	[post_prop19] [varchar](5000) NULL,
	[post_prop20] [varchar](5000) NULL,
	[post_prop21] [varchar](5000) NULL,
	[post_prop22] [varchar](5000) NULL,
	[post_prop23] [varchar](5000) NULL,
	[post_prop24] [varchar](5000) NULL,
	[post_prop25] [varchar](5000) NULL,
	[post_prop26] [varchar](5000) NULL,
	[post_prop27] [varchar](5000) NULL,
	[post_prop28] [varchar](5000) NULL,
	[post_prop29] [varchar](5000) NULL,
	[post_prop30] [varchar](5000) NULL,
	[post_prop31] [varchar](5000) NULL,
	[post_prop32] [varchar](5000) NULL,
	[post_prop33] [varchar](5000) NULL,
	[post_prop34] [varchar](5000) NULL,
	[post_prop35] [varchar](5000) NULL,
	[post_prop36] [varchar](5000) NULL,
	[post_prop37] [varchar](5000) NULL,
	[post_prop38] [varchar](5000) NULL,
	[post_prop39] [varchar](5000) NULL,
	[post_prop40] [varchar](5000) NULL,
	[post_prop41] [varchar](5000) NULL,
	[post_prop42] [varchar](5000) NULL,
	[post_prop43] [varchar](5000) NULL,
	[post_prop44] [varchar](5000) NULL,
	[post_prop45] [varchar](5000) NULL,
	[post_prop46] [varchar](5000) NULL,
	[post_prop47] [varchar](5000) NULL,
	[post_prop48] [varchar](5000) NULL,
	[post_prop49] [varchar](5000) NULL,
	[post_prop50] [varchar](5000) NULL,
	[post_prop51] [varchar](5000) NULL,
	[post_prop52] [varchar](5000) NULL,
	[post_prop53] [varchar](5000) NULL,
	[post_prop54] [varchar](5000) NULL,
	[post_prop55] [varchar](5000) NULL,
	[post_prop56] [varchar](5000) NULL,
	[post_prop57] [varchar](5000) NULL,
	[post_prop58] [varchar](5000) NULL,
	[post_prop59] [varchar](5000) NULL,
	[post_prop60] [varchar](5000) NULL,
	[post_prop61] [varchar](5000) NULL,
	[post_prop62] [varchar](5000) NULL,
	[post_prop63] [varchar](5000) NULL,
	[post_prop64] [varchar](5000) NULL,
	[post_prop65] [varchar](5000) NULL,
	[post_prop66] [varchar](5000) NULL,
	[post_prop67] [varchar](5000) NULL,
	[post_prop68] [varchar](5000) NULL,
	[post_prop69] [varchar](5000) NULL,
	[post_prop70] [varchar](5000) NULL,
	[post_prop71] [varchar](5000) NULL,
	[post_prop72] [varchar](5000) NULL,
	[post_prop73] [varchar](5000) NULL,
	[post_prop74] [varchar](5000) NULL,
	[post_prop75] [varchar](5000) NULL,
	[post_purchaseid] [varchar](5000) NULL,
	[post_referrer] [varchar](5000) NULL,
	[post_s_kwcid] [varchar](5000) NULL,
	[post_search_engine] [varchar](5000) NULL,
	[post_socialaccountandappids] [varchar](5000) NULL,
	[post_socialassettrackingcode] [varchar](5000) NULL,
	[post_socialauthor] [varchar](5000) NULL,
	[post_socialaveragesentiment] [varchar](5000) NULL,
	[post_socialaveragesentiment_(deprecated)] [varchar](5000) NULL,
	[post_socialcontentprovider] [varchar](5000) NULL,
	[post_socialfbstories] [varchar](5000) NULL,
	[post_socialfbstorytellers] [varchar](5000) NULL,
	[post_socialinteractioncount] [varchar](5000) NULL,
	[post_socialinteractiontype] [varchar](5000) NULL,
	[post_sociallanguage] [varchar](5000) NULL,
	[post_sociallatlong] [varchar](5000) NULL,
	[post_sociallikeadds] [varchar](5000) NULL,
	[post_sociallink] [varchar](5000) NULL,
	[post_sociallink_(deprecated)] [varchar](5000) NULL,
	[post_socialmentions] [varchar](5000) NULL,
	[post_socialowneddefinitioninsighttype] [varchar](5000) NULL,
	[post_socialowneddefinitioninsightvalue] [varchar](5000) NULL,
	[post_socialowneddefinitionmetric] [varchar](5000) NULL,
	[post_socialowneddefinitionpropertyvspost] [varchar](5000) NULL,
	[post_socialownedpostids] [varchar](5000) NULL,
	[post_socialownedpropertyid] [varchar](5000) NULL,
	[post_socialownedpropertyname] [varchar](5000) NULL,
	[post_socialownedpropertypropertyvsapp] [varchar](5000) NULL,
	[post_socialpageviews] [varchar](5000) NULL,
	[post_socialpostviews] [varchar](5000) NULL,
	[post_socialproperty] [varchar](5000) NULL,
	[post_socialproperty_(deprecated)] [varchar](5000) NULL,
	[post_socialpubcomments] [varchar](5000) NULL,
	[post_socialpubposts] [varchar](5000) NULL,
	[post_socialpubrecommends] [varchar](5000) NULL,
	[post_socialpubsubscribers] [varchar](5000) NULL,
	[post_socialterm] [varchar](5000) NULL,
	[post_socialtermslist] [varchar](5000) NULL,
	[post_socialtermslist_(deprecated)] [varchar](5000) NULL,
	[post_socialtotalsentiment] [varchar](5000) NULL,
	[post_state] [varchar](5000) NULL,
	[post_survey] [varchar](5000) NULL,
	[post_t_time_info] [varchar](5000) NULL,
	[post_tnt] [varchar](5000) NULL,
	[post_tnt_action] [varchar](5000) NULL,
	[post_transactionid] [varchar](5000) NULL,
	[post_video] [varchar](5000) NULL,
	[post_videoad] [varchar](5000) NULL,
	[post_videoadinpod] [varchar](5000) NULL,
	[post_videoadlength] [varchar](5000) NULL,
	[post_videoadname] [varchar](5000) NULL,
	[post_videoadplayername] [varchar](5000) NULL,
	[post_videoadpod] [varchar](5000) NULL,
	[post_videoadvertiser] [varchar](5000) NULL,
	[post_videoauthorized] [varchar](5000) NULL,
	[post_videocampaign] [varchar](5000) NULL,
	[post_videochannel] [varchar](5000) NULL,
	[post_videochapter] [varchar](5000) NULL,
	[post_videocontenttype] [varchar](5000) NULL,
	[post_videodaypart] [varchar](5000) NULL,
	[post_videoepisode] [varchar](5000) NULL,
	[post_videofeedtype] [varchar](5000) NULL,
	[post_videogenre] [varchar](5000) NULL,
	[post_videolength] [varchar](5000) NULL,
	[post_videomvpd] [varchar](5000) NULL,
	[post_videoname] [varchar](5000) NULL,
	[post_videonetwork] [varchar](5000) NULL,
	[post_videopath] [varchar](5000) NULL,
	[post_videoplayername] [varchar](5000) NULL,
	[post_videoqoebitrateaverageevar] [varchar](5000) NULL,
	[post_videoqoebitratechangecountevar] [varchar](5000) NULL,
	[post_videoqoebuffercountevar] [varchar](5000) NULL,
	[post_videoqoebuffertimeevar] [varchar](5000) NULL,
	[post_videoqoedroppedframecountevar] [varchar](5000) NULL,
	[post_videoqoeerrorcountevar] [varchar](5000) NULL,
	[post_videoqoetimetostartevar] [varchar](5000) NULL,
	[post_videoseason] [varchar](5000) NULL,
	[post_videosegment] [varchar](5000) NULL,
	[post_videoshow] [varchar](5000) NULL,
	[post_videoshowtype] [varchar](5000) NULL,
	[post_visid_high] [varchar](5000) NULL,
	[post_visid_low] [varchar](5000) NULL,
	[post_visid_type] [varchar](5000) NULL,
	[post_zip] [varchar](5000) NULL,
	[prev_page] [varchar](5000) NULL,
	[product_list] [varchar](5000) NULL,
	[product_merchandising] [varchar](5000) NULL,
	[prop1] [varchar](5000) NULL,
	[prop2] [varchar](5000) NULL,
	[prop3] [varchar](5000) NULL,
	[prop4] [varchar](5000) NULL,
	[prop5] [varchar](5000) NULL,
	[prop6] [varchar](5000) NULL,
	[prop7] [varchar](5000) NULL,
	[prop8] [varchar](5000) NULL,
	[prop9] [varchar](5000) NULL,
	[prop10] [varchar](5000) NULL,
	[prop11] [varchar](5000) NULL,
	[prop12] [varchar](5000) NULL,
	[prop13] [varchar](5000) NULL,
	[prop14] [varchar](5000) NULL,
	[prop15] [varchar](5000) NULL,
	[prop16] [varchar](5000) NULL,
	[prop17] [varchar](5000) NULL,
	[prop18] [varchar](5000) NULL,
	[prop19] [varchar](5000) NULL,
	[prop20] [varchar](5000) NULL,
	[prop21] [varchar](5000) NULL,
	[prop22] [varchar](5000) NULL,
	[prop23] [varchar](5000) NULL,
	[prop24] [varchar](5000) NULL,
	[prop25] [varchar](5000) NULL,
	[prop26] [varchar](5000) NULL,
	[prop27] [varchar](5000) NULL,
	[prop28] [varchar](5000) NULL,
	[prop29] [varchar](5000) NULL,
	[prop30] [varchar](5000) NULL,
	[prop31] [varchar](5000) NULL,
	[prop32] [varchar](5000) NULL,
	[prop33] [varchar](5000) NULL,
	[prop34] [varchar](5000) NULL,
	[prop35] [varchar](5000) NULL,
	[prop36] [varchar](5000) NULL,
	[prop37] [varchar](5000) NULL,
	[prop38] [varchar](5000) NULL,
	[prop39] [varchar](5000) NULL,
	[prop40] [varchar](5000) NULL,
	[prop41] [varchar](5000) NULL,
	[prop42] [varchar](5000) NULL,
	[prop43] [varchar](5000) NULL,
	[prop44] [varchar](5000) NULL,
	[prop45] [varchar](5000) NULL,
	[prop46] [varchar](5000) NULL,
	[prop47] [varchar](5000) NULL,
	[prop48] [varchar](5000) NULL,
	[prop49] [varchar](5000) NULL,
	[prop50] [varchar](5000) NULL,
	[prop51] [varchar](5000) NULL,
	[prop52] [varchar](5000) NULL,
	[prop53] [varchar](5000) NULL,
	[prop54] [varchar](5000) NULL,
	[prop55] [varchar](5000) NULL,
	[prop56] [varchar](5000) NULL,
	[prop57] [varchar](5000) NULL,
	[prop58] [varchar](5000) NULL,
	[prop59] [varchar](5000) NULL,
	[prop60] [varchar](5000) NULL,
	[prop61] [varchar](5000) NULL,
	[prop62] [varchar](5000) NULL,
	[prop63] [varchar](5000) NULL,
	[prop64] [varchar](5000) NULL,
	[prop65] [varchar](5000) NULL,
	[prop66] [varchar](5000) NULL,
	[prop67] [varchar](5000) NULL,
	[prop68] [varchar](5000) NULL,
	[prop69] [varchar](5000) NULL,
	[prop70] [varchar](5000) NULL,
	[prop71] [varchar](5000) NULL,
	[prop72] [varchar](5000) NULL,
	[prop73] [varchar](5000) NULL,
	[prop74] [varchar](5000) NULL,
	[prop75] [varchar](5000) NULL,
	[purchaseid] [varchar](5000) NULL,
	[quarterly_visitor] [varchar](5000) NULL,
	[ref_domain] [varchar](5000) NULL,
	[ref_type] [varchar](5000) NULL,
	[referrer] [varchar](5000) NULL,
	[resolution] [varchar](5000) NULL,
	[s_kwcid] [varchar](5000) NULL,
	[s_resolution] [varchar](5000) NULL,
	[sampled_hit] [varchar](5000) NULL,
	[search_engine] [varchar](5000) NULL,
	[search_page_num] [varchar](5000) NULL,
	[secondary_hit] [varchar](5000) NULL,
	[service] [varchar](5000) NULL,
	[socialaccountandappids] [varchar](5000) NULL,
	[socialassettrackingcode] [varchar](5000) NULL,
	[socialauthor] [varchar](5000) NULL,
	[socialaveragesentiment] [varchar](5000) NULL,
	[socialaveragesentiment_(deprecated)] [varchar](5000) NULL,
	[socialcontentprovider] [varchar](5000) NULL,
	[socialfbstories] [varchar](5000) NULL,
	[socialfbstorytellers] [varchar](5000) NULL,
	[socialinteractioncount] [varchar](5000) NULL,
	[socialinteractiontype] [varchar](5000) NULL,
	[sociallanguage] [varchar](5000) NULL,
	[sociallatlong] [varchar](5000) NULL,
	[sociallikeadds] [varchar](5000) NULL,
	[sociallink] [varchar](5000) NULL,
	[sociallink_(deprecated)] [varchar](5000) NULL,
	[socialmentions] [varchar](5000) NULL,
	[socialowneddefinitioninsighttype] [varchar](5000) NULL,
	[socialowneddefinitioninsightvalue] [varchar](5000) NULL,
	[socialowneddefinitionmetric] [varchar](5000) NULL,
	[socialowneddefinitionpropertyvspost] [varchar](5000) NULL,
	[socialownedpostids] [varchar](5000) NULL,
	[socialownedpropertyid] [varchar](5000) NULL,
	[socialownedpropertyname] [varchar](5000) NULL,
	[socialownedpropertypropertyvsapp] [varchar](5000) NULL,
	[socialpageviews] [varchar](5000) NULL,
	[socialpostviews] [varchar](5000) NULL,
	[socialproperty] [varchar](5000) NULL,
	[socialproperty_(deprecated)] [varchar](5000) NULL,
	[socialpubcomments] [varchar](5000) NULL,
	[socialpubposts] [varchar](5000) NULL,
	[socialpubrecommends] [varchar](5000) NULL,
	[socialpubsubscribers] [varchar](5000) NULL,
	[socialterm] [varchar](5000) NULL,
	[socialtermslist] [varchar](5000) NULL,
	[socialtermslist_(deprecated)] [varchar](5000) NULL,
	[socialtotalsentiment] [varchar](5000) NULL,
	[sourceid] [varchar](5000) NULL,
	[state] [varchar](5000) NULL,
	[stats_server] [varchar](5000) NULL,
	[t_time_info] [varchar](5000) NULL,
	[tnt] [varchar](5000) NULL,
	[tnt_action] [varchar](5000) NULL,
	[tnt_post_vista] [varchar](5000) NULL,
	[transactionid] [varchar](5000) NULL,
	[truncated_hit] [varchar](5000) NULL,
	[ua_color] [varchar](5000) NULL,
	[ua_os] [varchar](5000) NULL,
	[ua_pixels] [varchar](5000) NULL,
	[user_agent] [varchar](5000) NULL,
	[user_hash] [varchar](5000) NULL,
	[user_server] [varchar](5000) NULL,
	[userid] [varchar](5000) NULL,
	[username] [varchar](5000) NULL,
	[va_closer_detail] [varchar](5000) NULL,
	[va_closer_id] [varchar](5000) NULL,
	[va_finder_detail] [varchar](5000) NULL,
	[va_finder_id] [varchar](5000) NULL,
	[va_instance_event] [varchar](5000) NULL,
	[va_new_engagement] [varchar](5000) NULL,
	[video] [varchar](5000) NULL,
	[videoad] [varchar](5000) NULL,
	[videoadinpod] [varchar](5000) NULL,
	[videoadlength] [varchar](5000) NULL,
	[videoadname] [varchar](5000) NULL,
	[videoadplayername] [varchar](5000) NULL,
	[videoadpod] [varchar](5000) NULL,
	[videoadvertiser] [varchar](5000) NULL,
	[videoaudioalbum] [varchar](5000) NULL,
	[videoaudioartist] [varchar](5000) NULL,
	[videoaudioauthor] [varchar](5000) NULL,
	[videoaudiolabel] [varchar](5000) NULL,
	[videoaudiopublisher] [varchar](5000) NULL,
	[videoaudiostation] [varchar](5000) NULL,
	[videoauthorized] [varchar](5000) NULL,
	[videoaverageminuteaudience] [varchar](5000) NULL,
	[videocampaign] [varchar](5000) NULL,
	[videochannel] [varchar](5000) NULL,
	[videochapter] [varchar](5000) NULL,
	[videochaptercomplete] [varchar](5000) NULL,
	[videochapterstart] [varchar](5000) NULL,
	[videochaptertime] [varchar](5000) NULL,
	[videocontenttype] [varchar](5000) NULL,
	[videodaypart] [varchar](5000) NULL,
	[videoepisode] [varchar](5000) NULL,
	[videofeedtype] [varchar](5000) NULL,
	[videogenre] [varchar](5000) NULL,
	[videolength] [varchar](5000) NULL,
	[videomvpd] [varchar](5000) NULL,
	[videoname] [varchar](5000) NULL,
	[videonetwork] [varchar](5000) NULL,
	[videopath] [varchar](5000) NULL,
	[videopause] [varchar](5000) NULL,
	[videopausecount] [varchar](5000) NULL,
	[videopausetime] [varchar](5000) NULL,
	[videoplay] [varchar](5000) NULL,
	[videoplayername] [varchar](5000) NULL,
	[videoprogress10] [varchar](5000) NULL,
	[videoprogress25] [varchar](5000) NULL,
	[videoprogress50] [varchar](5000) NULL,
	[videoprogress75] [varchar](5000) NULL,
	[videoprogress96] [varchar](5000) NULL,
	[videoqoebitrateaverage] [varchar](5000) NULL,
	[videoqoebitrateaverageevar] [varchar](5000) NULL,
	[videoqoebitratechange] [varchar](5000) NULL,
	[videoqoebitratechangecountevar] [varchar](5000) NULL,
	[videoqoebuffer] [varchar](5000) NULL,
	[videoqoebuffercountevar] [varchar](5000) NULL,
	[videoqoebuffertimeevar] [varchar](5000) NULL,
	[videoqoedropbeforestart] [varchar](5000) NULL,
	[videoqoedroppedframecountevar] [varchar](5000) NULL,
	[videoqoedroppedframes] [varchar](5000) NULL,
	[videoqoeerror] [varchar](5000) NULL,
	[videoqoeerrorcountevar] [varchar](5000) NULL,
	[videoqoeextneralerrors] [varchar](5000) NULL,
	[videoqoeplayersdkerrors] [varchar](5000) NULL,
	[videoqoetimetostartevar] [varchar](5000) NULL,
	[videoresume] [varchar](5000) NULL,
	[videoseason] [varchar](5000) NULL,
	[videosegment] [varchar](5000) NULL,
	[videoshow] [varchar](5000) NULL,
	[videoshowtype] [varchar](5000) NULL,
	[videostreamtype] [varchar](5000) NULL,
	[videototaltime] [varchar](5000) NULL,
	[videouniquetimeplayed] [varchar](5000) NULL,
	[visid_high] [varchar](5000) NULL,
	[visid_low] [varchar](5000) NULL,
	[visid_new] [varchar](5000) NULL,
	[visid_timestamp] [varchar](5000) NULL,
	[visid_type] [varchar](5000) NULL,
	[visit_keywords] [varchar](5000) NULL,
	[visit_num] [varchar](5000) NULL,
	[visit_page_num] [varchar](5000) NULL,
	[visit_ref_domain] [varchar](5000) NULL,
	[visit_ref_type] [varchar](5000) NULL,
	[visit_referrer] [varchar](5000) NULL,
	[visit_search_engine] [varchar](5000) NULL,
	[visit_start_page_url] [varchar](5000) NULL,
	[visit_start_pagename] [varchar](5000) NULL,
	[visit_start_time_gmt] [varchar](5000) NULL,
	[weekly_visitor] [varchar](5000) NULL,
	[yearly_visitor] [varchar](5000) NULL,
	[zip] [varchar](5000) NULL,
	[event_list] [varchar](5000) NULL,
	[FILENAME] [varchar](5000) NULL,
	[SEQ] [varchar](5000) NULL,
	[FILEDATE] [varchar](5000) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[HIT_DATA_LTD]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[HIT_DATA_LTD](
	[accept_language] [varchar](5000) NULL,
	[adclassificationcreative] [varchar](5000) NULL,
	[adload] [varchar](5000) NULL,
	[aemassetid] [varchar](5000) NULL,
	[aemassetsource] [varchar](5000) NULL,
	[aemclickedassetid] [varchar](5000) NULL,
	[browser] [varchar](5000) NULL,
	[browser_height] [varchar](5000) NULL,
	[browser_width] [varchar](5000) NULL,
	[c_color] [varchar](5000) NULL,
	[campaign] [varchar](5000) NULL,
	[carrier] [varchar](5000) NULL,
	[channel] [varchar](5000) NULL,
	[click_action] [varchar](5000) NULL,
	[click_action_type] [varchar](5000) NULL,
	[click_context] [varchar](5000) NULL,
	[click_context_type] [varchar](5000) NULL,
	[click_sourceid] [varchar](5000) NULL,
	[click_tag] [varchar](5000) NULL,
	[clickmaplink] [varchar](5000) NULL,
	[clickmaplinkbyregion] [varchar](5000) NULL,
	[clickmappage] [varchar](5000) NULL,
	[clickmapregion] [varchar](5000) NULL,
	[code_ver] [varchar](5000) NULL,
	[color] [varchar](5000) NULL,
	[connection_type] [varchar](5000) NULL,
	[cookies] [varchar](5000) NULL,
	[country] [varchar](5000) NULL,
	[ct_connect_type] [varchar](5000) NULL,
	[curr_factor] [varchar](5000) NULL,
	[curr_rate] [varchar](5000) NULL,
	[currency] [varchar](5000) NULL,
	[cust_hit_time_gmt] [varchar](5000) NULL,
	[cust_visid] [varchar](5000) NULL,
	[daily_visitor] [varchar](5000) NULL,
	[date_time] [varchar](5000) NULL,
	[domain] [varchar](5000) NULL,
	[duplicate_events] [varchar](5000) NULL,
	[duplicate_purchase] [varchar](5000) NULL,
	[duplicated_from] [varchar](5000) NULL,
	[ef_id] [varchar](5000) NULL,
	[evar1] [varchar](5000) NULL,
	[evar2] [varchar](5000) NULL,
	[evar3] [varchar](5000) NULL,
	[evar4] [varchar](5000) NULL,
	[evar5] [varchar](5000) NULL,
	[evar6] [varchar](5000) NULL,
	[evar7] [varchar](5000) NULL,
	[evar8] [varchar](5000) NULL,
	[evar9] [varchar](5000) NULL,
	[evar10] [varchar](5000) NULL,
	[evar11] [varchar](5000) NULL,
	[evar12] [varchar](5000) NULL,
	[evar13] [varchar](5000) NULL,
	[evar14] [varchar](5000) NULL,
	[evar15] [varchar](5000) NULL,
	[evar16] [varchar](5000) NULL,
	[evar17] [varchar](5000) NULL,
	[evar18] [varchar](5000) NULL,
	[evar19] [varchar](5000) NULL,
	[evar20] [varchar](5000) NULL,
	[evar21] [varchar](5000) NULL,
	[evar22] [varchar](5000) NULL,
	[evar23] [varchar](5000) NULL,
	[evar24] [varchar](5000) NULL,
	[evar25] [varchar](5000) NULL,
	[evar26] [varchar](5000) NULL,
	[evar27] [varchar](5000) NULL,
	[evar28] [varchar](5000) NULL,
	[evar29] [varchar](5000) NULL,
	[evar30] [varchar](5000) NULL,
	[evar31] [varchar](5000) NULL,
	[evar32] [varchar](5000) NULL,
	[evar33] [varchar](5000) NULL,
	[evar34] [varchar](5000) NULL,
	[evar35] [varchar](5000) NULL,
	[evar36] [varchar](5000) NULL,
	[evar37] [varchar](5000) NULL,
	[evar38] [varchar](5000) NULL,
	[evar39] [varchar](5000) NULL,
	[evar40] [varchar](5000) NULL,
	[evar41] [varchar](5000) NULL,
	[evar42] [varchar](5000) NULL,
	[evar43] [varchar](5000) NULL,
	[evar44] [varchar](5000) NULL,
	[evar45] [varchar](5000) NULL,
	[evar46] [varchar](5000) NULL,
	[evar47] [varchar](5000) NULL,
	[evar48] [varchar](5000) NULL,
	[evar49] [varchar](5000) NULL,
	[evar50] [varchar](5000) NULL,
	[evar51] [varchar](5000) NULL,
	[evar52] [varchar](5000) NULL,
	[evar53] [varchar](5000) NULL,
	[evar54] [varchar](5000) NULL,
	[evar55] [varchar](5000) NULL,
	[evar56] [varchar](5000) NULL,
	[evar57] [varchar](5000) NULL,
	[evar58] [varchar](5000) NULL,
	[evar59] [varchar](5000) NULL,
	[evar60] [varchar](5000) NULL,
	[evar61] [varchar](5000) NULL,
	[evar62] [varchar](5000) NULL,
	[evar63] [varchar](5000) NULL,
	[evar64] [varchar](5000) NULL,
	[evar65] [varchar](5000) NULL,
	[evar66] [varchar](5000) NULL,
	[evar67] [varchar](5000) NULL,
	[evar68] [varchar](5000) NULL,
	[evar69] [varchar](5000) NULL,
	[evar70] [varchar](5000) NULL,
	[evar71] [varchar](5000) NULL,
	[evar72] [varchar](5000) NULL,
	[evar73] [varchar](5000) NULL,
	[evar74] [varchar](5000) NULL,
	[evar75] [varchar](5000) NULL,
	[evar76] [varchar](5000) NULL,
	[evar77] [varchar](5000) NULL,
	[evar78] [varchar](5000) NULL,
	[evar79] [varchar](5000) NULL,
	[evar80] [varchar](5000) NULL,
	[evar81] [varchar](5000) NULL,
	[evar82] [varchar](5000) NULL,
	[evar83] [varchar](5000) NULL,
	[evar84] [varchar](5000) NULL,
	[evar85] [varchar](5000) NULL,
	[evar86] [varchar](5000) NULL,
	[evar87] [varchar](5000) NULL,
	[evar88] [varchar](5000) NULL,
	[evar89] [varchar](5000) NULL,
	[evar90] [varchar](5000) NULL,
	[evar91] [varchar](5000) NULL,
	[evar92] [varchar](5000) NULL,
	[evar93] [varchar](5000) NULL,
	[evar94] [varchar](5000) NULL,
	[evar95] [varchar](5000) NULL,
	[evar96] [varchar](5000) NULL,
	[evar97] [varchar](5000) NULL,
	[evar98] [varchar](5000) NULL,
	[evar99] [varchar](5000) NULL,
	[evar100] [varchar](5000) NULL,
	[exclude_hit] [varchar](5000) NULL,
	[first_hit_page_url] [varchar](5000) NULL,
	[first_hit_pagename] [varchar](5000) NULL,
	[first_hit_ref_domain] [varchar](5000) NULL,
	[first_hit_ref_type] [varchar](5000) NULL,
	[first_hit_referrer] [varchar](5000) NULL,
	[first_hit_time_gmt] [varchar](5000) NULL,
	[geo_city] [varchar](5000) NULL,
	[geo_country] [varchar](5000) NULL,
	[geo_dma] [varchar](5000) NULL,
	[geo_region] [varchar](5000) NULL,
	[geo_zip] [varchar](5000) NULL,
	[hier1] [varchar](5000) NULL,
	[hier2] [varchar](5000) NULL,
	[hier3] [varchar](5000) NULL,
	[hier4] [varchar](5000) NULL,
	[hier5] [varchar](5000) NULL,
	[hit_source] [varchar](5000) NULL,
	[hit_time_gmt] [varchar](5000) NULL,
	[hitid_high] [varchar](5000) NULL,
	[hitid_low] [varchar](5000) NULL,
	[homepage] [varchar](5000) NULL,
	[hourly_visitor] [varchar](5000) NULL,
	[ip] [varchar](5000) NULL,
	[ip2] [varchar](5000) NULL,
	[j_jscript] [varchar](5000) NULL,
	[java_enabled] [varchar](5000) NULL,
	[javascript] [varchar](5000) NULL,
	[language] [varchar](5000) NULL,
	[last_hit_time_gmt] [varchar](5000) NULL,
	[last_purchase_num] [varchar](5000) NULL,
	[last_purchase_time_gmt] [varchar](5000) NULL,
	[latlon1] [varchar](5000) NULL,
	[latlon23] [varchar](5000) NULL,
	[latlon45] [varchar](5000) NULL,
	[mc_audiences] [varchar](5000) NULL,
	[mcvisid] [varchar](5000) NULL,
	[mobile_id] [varchar](5000) NULL,
	[mobileacquisitionclicks] [varchar](5000) NULL,
	[mobileaction] [varchar](5000) NULL,
	[mobileactioninapptime] [varchar](5000) NULL,
	[mobileactiontotaltime] [varchar](5000) NULL,
	[mobileappid] [varchar](5000) NULL,
	[mobileappperformanceaffectedusers] [varchar](5000) NULL,
	[mobileappperformanceappid] [varchar](5000) NULL,
	[mobileappperformanceappid_app_perf_app_name] [varchar](5000) NULL,
	[mobileappperformanceappid_app_perf_platform] [varchar](5000) NULL,
	[mobileappperformancecrashes] [varchar](5000) NULL,
	[mobileappperformancecrashid] [varchar](5000) NULL,
	[mobileappperformancecrashid_app_perf_crash_name] [varchar](5000) NULL,
	[mobileappperformanceloads] [varchar](5000) NULL,
	[mobileappstoreavgrating] [varchar](5000) NULL,
	[mobileappstoredownloads] [varchar](5000) NULL,
	[mobileappstoreinapprevenue] [varchar](5000) NULL,
	[mobileappstoreinapproyalties] [varchar](5000) NULL,
	[mobileappstoreobjectid] [varchar](5000) NULL,
	[mobileappstoreobjectid_app_store_user] [varchar](5000) NULL,
	[mobileappstoreobjectid_application_name] [varchar](5000) NULL,
	[mobileappstoreobjectid_application_version] [varchar](5000) NULL,
	[mobileappstoreobjectid_appstore_name] [varchar](5000) NULL,
	[mobileappstoreobjectid_category_name] [varchar](5000) NULL,
	[mobileappstoreobjectid_country_name] [varchar](5000) NULL,
	[mobileappstoreobjectid_device_manufacturer] [varchar](5000) NULL,
	[mobileappstoreobjectid_device_name] [varchar](5000) NULL,
	[mobileappstoreobjectid_in_app_name] [varchar](5000) NULL,
	[mobileappstoreobjectid_platform_name_version] [varchar](5000) NULL,
	[mobileappstoreobjectid_rank_category_type] [varchar](5000) NULL,
	[mobileappstoreobjectid_region_name] [varchar](5000) NULL,
	[mobileappstoreobjectid_review_comment] [varchar](5000) NULL,
	[mobileappstoreobjectid_review_title] [varchar](5000) NULL,
	[mobileappstoreoneoffrevenue] [varchar](5000) NULL,
	[mobileappstoreoneoffroyalties] [varchar](5000) NULL,
	[mobileappstorepurchases] [varchar](5000) NULL,
	[mobileappstorerank] [varchar](5000) NULL,
	[mobileappstorerankdivisor] [varchar](5000) NULL,
	[mobileappstorerating] [varchar](5000) NULL,
	[mobileappstoreratingdivisor] [varchar](5000) NULL,
	[mobileavgprevsessionlength] [varchar](5000) NULL,
	[mobilebeaconmajor] [varchar](5000) NULL,
	[mobilebeaconminor] [varchar](5000) NULL,
	[mobilebeaconproximity] [varchar](5000) NULL,
	[mobilebeaconuuid] [varchar](5000) NULL,
	[mobilecampaigncontent] [varchar](5000) NULL,
	[mobilecampaignmedium] [varchar](5000) NULL,
	[mobilecampaignname] [varchar](5000) NULL,
	[mobilecampaignsource] [varchar](5000) NULL,
	[mobilecampaignterm] [varchar](5000) NULL,
	[mobilecrashes] [varchar](5000) NULL,
	[mobilecrashrate] [varchar](5000) NULL,
	[mobiledailyengagedusers] [varchar](5000) NULL,
	[mobiledayofweek] [varchar](5000) NULL,
	[mobiledayssincefirstuse] [varchar](5000) NULL,
	[mobiledayssincelastupgrade] [varchar](5000) NULL,
	[mobiledayssincelastuse] [varchar](5000) NULL,
	[mobiledeeplinkid] [varchar](5000) NULL,
	[mobiledeeplinkid_name] [varchar](5000) NULL,
	[mobiledevice] [varchar](5000) NULL,
	[mobilehourofday] [varchar](5000) NULL,
	[mobileinstalldate] [varchar](5000) NULL,
	[mobileinstalls] [varchar](5000) NULL,
	[mobilelaunches] [varchar](5000) NULL,
	[mobilelaunchessincelastupgrade] [varchar](5000) NULL,
	[mobilelaunchnumber] [varchar](5000) NULL,
	[mobileltv] [varchar](5000) NULL,
	[mobileltvtotal] [varchar](5000) NULL,
	[mobilemessagebuttonname] [varchar](5000) NULL,
	[mobilemessageclicks] [varchar](5000) NULL,
	[mobilemessageid] [varchar](5000) NULL,
	[mobilemessageid_dest] [varchar](5000) NULL,
	[mobilemessageid_name] [varchar](5000) NULL,
	[mobilemessageid_type] [varchar](5000) NULL,
	[mobilemessageimpressions] [varchar](5000) NULL,
	[mobilemessageonline] [varchar](5000) NULL,
	[mobilemessagepushoptin] [varchar](5000) NULL,
	[mobilemessagepushpayloadid] [varchar](5000) NULL,
	[mobilemessagepushpayloadid_name] [varchar](5000) NULL,
	[mobilemessageviews] [varchar](5000) NULL,
	[mobilemonthlyengagedusers] [varchar](5000) NULL,
	[mobileosenvironment] [varchar](5000) NULL,
	[mobileosversion] [varchar](5000) NULL,
	[mobileplaceaccuracy] [varchar](5000) NULL,
	[mobileplacecategory] [varchar](5000) NULL,
	[mobileplacedwelltime] [varchar](5000) NULL,
	[mobileplaceentry] [varchar](5000) NULL,
	[mobileplaceexit] [varchar](5000) NULL,
	[mobileplaceid] [varchar](5000) NULL,
	[mobileprevsessionlength] [varchar](5000) NULL,
	[mobilepushoptin] [varchar](5000) NULL,
	[mobilepushpayloadid] [varchar](5000) NULL,
	[mobilerelaunchcampaigncontent] [varchar](5000) NULL,
	[mobilerelaunchcampaignmedium] [varchar](5000) NULL,
	[mobilerelaunchcampaignsource] [varchar](5000) NULL,
	[mobilerelaunchcampaignterm] [varchar](5000) NULL,
	[mobilerelaunchcampaigntrackingcode] [varchar](5000) NULL,
	[mobilerelaunchcampaigntrackingcode_name] [varchar](5000) NULL,
	[mobileresolution] [varchar](5000) NULL,
	[mobileupgrades] [varchar](5000) NULL,
	[monthly_visitor] [varchar](5000) NULL,
	[mvvar1] [varchar](5000) NULL,
	[mvvar2] [varchar](5000) NULL,
	[mvvar3] [varchar](5000) NULL,
	[namespace] [varchar](5000) NULL,
	[new_visit] [varchar](5000) NULL,
	[os] [varchar](5000) NULL,
	[p_plugins] [varchar](5000) NULL,
	[page_event] [varchar](5000) NULL,
	[page_event_var1] [varchar](5000) NULL,
	[page_event_var2] [varchar](5000) NULL,
	[page_event_var3] [varchar](5000) NULL,
	[page_type] [varchar](5000) NULL,
	[page_url] [varchar](5000) NULL,
	[pagename] [varchar](5000) NULL,
	[paid_search] [varchar](5000) NULL,
	[partner_plugins] [varchar](5000) NULL,
	[persistent_cookie] [varchar](5000) NULL,
	[plugins] [varchar](5000) NULL,
	[pointofinterest] [varchar](5000) NULL,
	[pointofinterestdistance] [varchar](5000) NULL,
	[post_adclassificationcreative] [varchar](5000) NULL,
	[post_adload] [varchar](5000) NULL,
	[post_browser_height] [varchar](5000) NULL,
	[post_browser_width] [varchar](5000) NULL,
	[post_campaign] [varchar](5000) NULL,
	[post_channel] [varchar](5000) NULL,
	[post_clickmaplink] [varchar](5000) NULL,
	[post_clickmaplinkbyregion] [varchar](5000) NULL,
	[post_clickmappage] [varchar](5000) NULL,
	[post_clickmapregion] [varchar](5000) NULL,
	[post_cookies] [varchar](5000) NULL,
	[post_currency] [varchar](5000) NULL,
	[post_cust_hit_time_gmt] [varchar](5000) NULL,
	[post_cust_visid] [varchar](5000) NULL,
	[post_ef_id] [varchar](5000) NULL,
	[post_evar1] [varchar](5000) NULL,
	[post_evar2] [varchar](5000) NULL,
	[post_evar3] [varchar](5000) NULL,
	[post_evar4] [varchar](5000) NULL,
	[post_evar5] [varchar](5000) NULL,
	[post_evar6] [varchar](5000) NULL,
	[post_evar7] [varchar](5000) NULL,
	[post_evar8] [varchar](5000) NULL,
	[post_evar9] [varchar](5000) NULL,
	[post_evar10] [varchar](5000) NULL,
	[post_evar11] [varchar](5000) NULL,
	[post_evar12] [varchar](5000) NULL,
	[post_evar13] [varchar](5000) NULL,
	[post_evar14] [varchar](5000) NULL,
	[post_evar15] [varchar](5000) NULL,
	[post_evar16] [varchar](5000) NULL,
	[post_evar17] [varchar](5000) NULL,
	[post_evar18] [varchar](5000) NULL,
	[post_evar19] [varchar](5000) NULL,
	[post_evar20] [varchar](5000) NULL,
	[post_evar21] [varchar](5000) NULL,
	[post_evar22] [varchar](5000) NULL,
	[post_evar23] [varchar](5000) NULL,
	[post_evar24] [varchar](5000) NULL,
	[post_evar25] [varchar](5000) NULL,
	[post_evar26] [varchar](5000) NULL,
	[post_evar27] [varchar](5000) NULL,
	[post_evar28] [varchar](5000) NULL,
	[post_evar29] [varchar](5000) NULL,
	[post_evar30] [varchar](5000) NULL,
	[post_evar31] [varchar](5000) NULL,
	[post_evar32] [varchar](5000) NULL,
	[post_evar33] [varchar](5000) NULL,
	[post_evar34] [varchar](5000) NULL,
	[post_evar35] [varchar](5000) NULL,
	[post_evar36] [varchar](5000) NULL,
	[post_evar37] [varchar](5000) NULL,
	[post_evar38] [varchar](5000) NULL,
	[post_evar39] [varchar](5000) NULL,
	[post_evar40] [varchar](5000) NULL,
	[post_evar41] [varchar](5000) NULL,
	[post_evar42] [varchar](5000) NULL,
	[post_evar43] [varchar](5000) NULL,
	[post_evar44] [varchar](5000) NULL,
	[post_evar45] [varchar](5000) NULL,
	[post_evar46] [varchar](5000) NULL,
	[post_evar47] [varchar](5000) NULL,
	[post_evar48] [varchar](5000) NULL,
	[post_evar49] [varchar](5000) NULL,
	[post_evar50] [varchar](5000) NULL,
	[post_evar51] [varchar](5000) NULL,
	[post_evar52] [varchar](5000) NULL,
	[post_evar53] [varchar](5000) NULL,
	[post_evar54] [varchar](5000) NULL,
	[post_evar55] [varchar](5000) NULL,
	[post_evar56] [varchar](5000) NULL,
	[post_evar57] [varchar](5000) NULL,
	[post_evar58] [varchar](5000) NULL,
	[post_evar59] [varchar](5000) NULL,
	[post_evar60] [varchar](5000) NULL,
	[post_evar61] [varchar](5000) NULL,
	[post_evar62] [varchar](5000) NULL,
	[post_evar63] [varchar](5000) NULL,
	[post_evar64] [varchar](5000) NULL,
	[post_evar65] [varchar](5000) NULL,
	[post_evar66] [varchar](5000) NULL,
	[post_evar67] [varchar](5000) NULL,
	[post_evar68] [varchar](5000) NULL,
	[post_evar69] [varchar](5000) NULL,
	[post_evar70] [varchar](5000) NULL,
	[post_evar71] [varchar](5000) NULL,
	[post_evar72] [varchar](5000) NULL,
	[post_evar73] [varchar](5000) NULL,
	[post_evar74] [varchar](5000) NULL,
	[post_evar75] [varchar](5000) NULL,
	[post_evar76] [varchar](5000) NULL,
	[post_evar77] [varchar](5000) NULL,
	[post_evar78] [varchar](5000) NULL,
	[post_evar79] [varchar](5000) NULL,
	[post_evar80] [varchar](5000) NULL,
	[post_evar81] [varchar](5000) NULL,
	[post_evar82] [varchar](5000) NULL,
	[post_evar83] [varchar](5000) NULL,
	[post_evar84] [varchar](5000) NULL,
	[post_evar85] [varchar](5000) NULL,
	[post_evar86] [varchar](5000) NULL,
	[post_evar87] [varchar](5000) NULL,
	[post_evar88] [varchar](5000) NULL,
	[post_evar89] [varchar](5000) NULL,
	[post_evar90] [varchar](5000) NULL,
	[post_evar91] [varchar](5000) NULL,
	[post_evar92] [varchar](5000) NULL,
	[post_evar93] [varchar](5000) NULL,
	[post_evar94] [varchar](5000) NULL,
	[post_evar95] [varchar](5000) NULL,
	[post_evar96] [varchar](5000) NULL,
	[post_evar97] [varchar](5000) NULL,
	[post_evar98] [varchar](5000) NULL,
	[post_evar99] [varchar](5000) NULL,
	[post_evar100] [varchar](5000) NULL,
	[post_event_list] [varchar](5000) NULL,
	[post_hier1] [varchar](5000) NULL,
	[post_hier2] [varchar](5000) NULL,
	[post_hier3] [varchar](5000) NULL,
	[post_hier4] [varchar](5000) NULL,
	[post_hier5] [varchar](5000) NULL,
	[post_java_enabled] [varchar](5000) NULL,
	[post_keywords] [varchar](5000) NULL,
	[post_mc_audiences] [varchar](5000) NULL,
	[post_mobileaction] [varchar](5000) NULL,
	[post_mobileappid] [varchar](5000) NULL,
	[post_mobilecampaigncontent] [varchar](5000) NULL,
	[post_mobilecampaignmedium] [varchar](5000) NULL,
	[post_mobilecampaignname] [varchar](5000) NULL,
	[post_mobilecampaignsource] [varchar](5000) NULL,
	[post_mobilecampaignterm] [varchar](5000) NULL,
	[post_mobiledayofweek] [varchar](5000) NULL,
	[post_mobiledayssincefirstuse] [varchar](5000) NULL,
	[post_mobiledayssincelastuse] [varchar](5000) NULL,
	[post_mobiledevice] [varchar](5000) NULL,
	[post_mobilehourofday] [varchar](5000) NULL,
	[post_mobileinstalldate] [varchar](5000) NULL,
	[post_mobilelaunchnumber] [varchar](5000) NULL,
	[post_mobileltv] [varchar](5000) NULL,
	[post_mobilemessagebuttonname] [varchar](5000) NULL,
	[post_mobilemessageclicks] [varchar](5000) NULL,
	[post_mobilemessageid] [varchar](5000) NULL,
	[post_mobilemessageid_dest] [varchar](5000) NULL,
	[post_mobilemessageid_name] [varchar](5000) NULL,
	[post_mobilemessageid_type] [varchar](5000) NULL,
	[post_mobilemessageimpressions] [varchar](5000) NULL,
	[post_mobilemessageonline] [varchar](5000) NULL,
	[post_mobilemessagepushoptin] [varchar](5000) NULL,
	[post_mobilemessagepushpayloadid] [varchar](5000) NULL,
	[post_mobilemessagepushpayloadid_name] [varchar](5000) NULL,
	[post_mobilemessageviews] [varchar](5000) NULL,
	[post_mobileosversion] [varchar](5000) NULL,
	[post_mobilepushoptin] [varchar](5000) NULL,
	[post_mobilepushpayloadid] [varchar](5000) NULL,
	[post_mobileresolution] [varchar](5000) NULL,
	[post_mvvar1] [varchar](5000) NULL,
	[post_mvvar2] [varchar](5000) NULL,
	[post_mvvar3] [varchar](5000) NULL,
	[post_page_event] [varchar](5000) NULL,
	[post_page_event_var1] [varchar](5000) NULL,
	[post_page_event_var2] [varchar](5000) NULL,
	[post_page_event_var3] [varchar](5000) NULL,
	[post_page_type] [varchar](5000) NULL,
	[post_page_url] [varchar](5000) NULL,
	[post_pagename] [varchar](5000) NULL,
	[post_pagename_no_url] [varchar](5000) NULL,
	[post_partner_plugins] [varchar](5000) NULL,
	[post_persistent_cookie] [varchar](5000) NULL,
	[post_pointofinterest] [varchar](5000) NULL,
	[post_pointofinterestdistance] [varchar](5000) NULL,
	[post_product_list] [varchar](5000) NULL,
	[post_prop1] [varchar](5000) NULL,
	[post_prop2] [varchar](5000) NULL,
	[post_prop3] [varchar](5000) NULL,
	[post_prop4] [varchar](5000) NULL,
	[post_prop5] [varchar](5000) NULL,
	[post_prop6] [varchar](5000) NULL,
	[post_prop7] [varchar](5000) NULL,
	[post_prop8] [varchar](5000) NULL,
	[post_prop9] [varchar](5000) NULL,
	[post_prop10] [varchar](5000) NULL,
	[post_prop11] [varchar](5000) NULL,
	[post_prop12] [varchar](5000) NULL,
	[post_prop13] [varchar](5000) NULL,
	[post_prop14] [varchar](5000) NULL,
	[post_prop15] [varchar](5000) NULL,
	[post_prop16] [varchar](5000) NULL,
	[post_prop17] [varchar](5000) NULL,
	[post_prop18] [varchar](5000) NULL,
	[post_prop19] [varchar](5000) NULL,
	[post_prop20] [varchar](5000) NULL,
	[post_prop21] [varchar](5000) NULL,
	[post_prop22] [varchar](5000) NULL,
	[post_prop23] [varchar](5000) NULL,
	[post_prop24] [varchar](5000) NULL,
	[post_prop25] [varchar](5000) NULL,
	[post_prop26] [varchar](5000) NULL,
	[post_prop27] [varchar](5000) NULL,
	[post_prop28] [varchar](5000) NULL,
	[post_prop29] [varchar](5000) NULL,
	[post_prop30] [varchar](5000) NULL,
	[post_prop31] [varchar](5000) NULL,
	[post_prop32] [varchar](5000) NULL,
	[post_prop33] [varchar](5000) NULL,
	[post_prop34] [varchar](5000) NULL,
	[post_prop35] [varchar](5000) NULL,
	[post_prop36] [varchar](5000) NULL,
	[post_prop37] [varchar](5000) NULL,
	[post_prop38] [varchar](5000) NULL,
	[post_prop39] [varchar](5000) NULL,
	[post_prop40] [varchar](5000) NULL,
	[post_prop41] [varchar](5000) NULL,
	[post_prop42] [varchar](5000) NULL,
	[post_prop43] [varchar](5000) NULL,
	[post_prop44] [varchar](5000) NULL,
	[post_prop45] [varchar](5000) NULL,
	[post_prop46] [varchar](5000) NULL,
	[post_prop47] [varchar](5000) NULL,
	[post_prop48] [varchar](5000) NULL,
	[post_prop49] [varchar](5000) NULL,
	[post_prop50] [varchar](5000) NULL,
	[post_prop51] [varchar](5000) NULL,
	[post_prop52] [varchar](5000) NULL,
	[post_prop53] [varchar](5000) NULL,
	[post_prop54] [varchar](5000) NULL,
	[post_prop55] [varchar](5000) NULL,
	[post_prop56] [varchar](5000) NULL,
	[post_prop57] [varchar](5000) NULL,
	[post_prop58] [varchar](5000) NULL,
	[post_prop59] [varchar](5000) NULL,
	[post_prop60] [varchar](5000) NULL,
	[post_prop61] [varchar](5000) NULL,
	[post_prop62] [varchar](5000) NULL,
	[post_prop63] [varchar](5000) NULL,
	[post_prop64] [varchar](5000) NULL,
	[post_prop65] [varchar](5000) NULL,
	[post_prop66] [varchar](5000) NULL,
	[post_prop67] [varchar](5000) NULL,
	[post_prop68] [varchar](5000) NULL,
	[post_prop69] [varchar](5000) NULL,
	[post_prop70] [varchar](5000) NULL,
	[post_prop71] [varchar](5000) NULL,
	[post_prop72] [varchar](5000) NULL,
	[post_prop73] [varchar](5000) NULL,
	[post_prop74] [varchar](5000) NULL,
	[post_prop75] [varchar](5000) NULL,
	[post_purchaseid] [varchar](5000) NULL,
	[post_referrer] [varchar](5000) NULL,
	[post_s_kwcid] [varchar](5000) NULL,
	[post_search_engine] [varchar](5000) NULL,
	[post_socialaccountandappids] [varchar](5000) NULL,
	[post_socialassettrackingcode] [varchar](5000) NULL,
	[post_socialauthor] [varchar](5000) NULL,
	[post_socialaveragesentiment] [varchar](5000) NULL,
	[post_socialaveragesentiment_(deprecated)] [varchar](5000) NULL,
	[post_socialcontentprovider] [varchar](5000) NULL,
	[post_socialfbstories] [varchar](5000) NULL,
	[post_socialfbstorytellers] [varchar](5000) NULL,
	[post_socialinteractioncount] [varchar](5000) NULL,
	[post_socialinteractiontype] [varchar](5000) NULL,
	[post_sociallanguage] [varchar](5000) NULL,
	[post_sociallatlong] [varchar](5000) NULL,
	[post_sociallikeadds] [varchar](5000) NULL,
	[post_sociallink] [varchar](5000) NULL,
	[post_sociallink_(deprecated)] [varchar](5000) NULL,
	[post_socialmentions] [varchar](5000) NULL,
	[post_socialowneddefinitioninsighttype] [varchar](5000) NULL,
	[post_socialowneddefinitioninsightvalue] [varchar](5000) NULL,
	[post_socialowneddefinitionmetric] [varchar](5000) NULL,
	[post_socialowneddefinitionpropertyvspost] [varchar](5000) NULL,
	[post_socialownedpostids] [varchar](5000) NULL,
	[post_socialownedpropertyid] [varchar](5000) NULL,
	[post_socialownedpropertyname] [varchar](5000) NULL,
	[post_socialownedpropertypropertyvsapp] [varchar](5000) NULL,
	[post_socialpageviews] [varchar](5000) NULL,
	[post_socialpostviews] [varchar](5000) NULL,
	[post_socialproperty] [varchar](5000) NULL,
	[post_socialproperty_(deprecated)] [varchar](5000) NULL,
	[post_socialpubcomments] [varchar](5000) NULL,
	[post_socialpubposts] [varchar](5000) NULL,
	[post_socialpubrecommends] [varchar](5000) NULL,
	[post_socialpubsubscribers] [varchar](5000) NULL,
	[post_socialterm] [varchar](5000) NULL,
	[post_socialtermslist] [varchar](5000) NULL,
	[post_socialtermslist_(deprecated)] [varchar](5000) NULL,
	[post_socialtotalsentiment] [varchar](5000) NULL,
	[post_state] [varchar](5000) NULL,
	[post_survey] [varchar](5000) NULL,
	[post_t_time_info] [varchar](5000) NULL,
	[post_tnt] [varchar](5000) NULL,
	[post_tnt_action] [varchar](5000) NULL,
	[post_transactionid] [varchar](5000) NULL,
	[post_video] [varchar](5000) NULL,
	[post_videoad] [varchar](5000) NULL,
	[post_videoadinpod] [varchar](5000) NULL,
	[post_videoadlength] [varchar](5000) NULL,
	[post_videoadname] [varchar](5000) NULL,
	[post_videoadplayername] [varchar](5000) NULL,
	[post_videoadpod] [varchar](5000) NULL,
	[post_videoadvertiser] [varchar](5000) NULL,
	[post_videoauthorized] [varchar](5000) NULL,
	[post_videocampaign] [varchar](5000) NULL,
	[post_videochannel] [varchar](5000) NULL,
	[post_videochapter] [varchar](5000) NULL,
	[post_videocontenttype] [varchar](5000) NULL,
	[post_videodaypart] [varchar](5000) NULL,
	[post_videoepisode] [varchar](5000) NULL,
	[post_videofeedtype] [varchar](5000) NULL,
	[post_videogenre] [varchar](5000) NULL,
	[post_videolength] [varchar](5000) NULL,
	[post_videomvpd] [varchar](5000) NULL,
	[post_videoname] [varchar](5000) NULL,
	[post_videonetwork] [varchar](5000) NULL,
	[post_videopath] [varchar](5000) NULL,
	[post_videoplayername] [varchar](5000) NULL,
	[post_videoqoebitrateaverageevar] [varchar](5000) NULL,
	[post_videoqoebitratechangecountevar] [varchar](5000) NULL,
	[post_videoqoebuffercountevar] [varchar](5000) NULL,
	[post_videoqoebuffertimeevar] [varchar](5000) NULL,
	[post_videoqoedroppedframecountevar] [varchar](5000) NULL,
	[post_videoqoeerrorcountevar] [varchar](5000) NULL,
	[post_videoqoetimetostartevar] [varchar](5000) NULL,
	[post_videoseason] [varchar](5000) NULL,
	[post_videosegment] [varchar](5000) NULL,
	[post_videoshow] [varchar](5000) NULL,
	[post_videoshowtype] [varchar](5000) NULL,
	[post_visid_high] [varchar](5000) NULL,
	[post_visid_low] [varchar](5000) NULL,
	[post_visid_type] [varchar](5000) NULL,
	[post_zip] [varchar](5000) NULL,
	[prev_page] [varchar](5000) NULL,
	[product_list] [varchar](5000) NULL,
	[product_merchandising] [varchar](5000) NULL,
	[prop1] [varchar](5000) NULL,
	[prop2] [varchar](5000) NULL,
	[prop3] [varchar](5000) NULL,
	[prop4] [varchar](5000) NULL,
	[prop5] [varchar](5000) NULL,
	[prop6] [varchar](5000) NULL,
	[prop7] [varchar](5000) NULL,
	[prop8] [varchar](5000) NULL,
	[prop9] [varchar](5000) NULL,
	[prop10] [varchar](5000) NULL,
	[prop11] [varchar](5000) NULL,
	[prop12] [varchar](5000) NULL,
	[prop13] [varchar](5000) NULL,
	[prop14] [varchar](5000) NULL,
	[prop15] [varchar](5000) NULL,
	[prop16] [varchar](5000) NULL,
	[prop17] [varchar](5000) NULL,
	[prop18] [varchar](5000) NULL,
	[prop19] [varchar](5000) NULL,
	[prop20] [varchar](5000) NULL,
	[prop21] [varchar](5000) NULL,
	[prop22] [varchar](5000) NULL,
	[prop23] [varchar](5000) NULL,
	[prop24] [varchar](5000) NULL,
	[prop25] [varchar](5000) NULL,
	[prop26] [varchar](5000) NULL,
	[prop27] [varchar](5000) NULL,
	[prop28] [varchar](5000) NULL,
	[prop29] [varchar](5000) NULL,
	[prop30] [varchar](5000) NULL,
	[prop31] [varchar](5000) NULL,
	[prop32] [varchar](5000) NULL,
	[prop33] [varchar](5000) NULL,
	[prop34] [varchar](5000) NULL,
	[prop35] [varchar](5000) NULL,
	[prop36] [varchar](5000) NULL,
	[prop37] [varchar](5000) NULL,
	[prop38] [varchar](5000) NULL,
	[prop39] [varchar](5000) NULL,
	[prop40] [varchar](5000) NULL,
	[prop41] [varchar](5000) NULL,
	[prop42] [varchar](5000) NULL,
	[prop43] [varchar](5000) NULL,
	[prop44] [varchar](5000) NULL,
	[prop45] [varchar](5000) NULL,
	[prop46] [varchar](5000) NULL,
	[prop47] [varchar](5000) NULL,
	[prop48] [varchar](5000) NULL,
	[prop49] [varchar](5000) NULL,
	[prop50] [varchar](5000) NULL,
	[prop51] [varchar](5000) NULL,
	[prop52] [varchar](5000) NULL,
	[prop53] [varchar](5000) NULL,
	[prop54] [varchar](5000) NULL,
	[prop55] [varchar](5000) NULL,
	[prop56] [varchar](5000) NULL,
	[prop57] [varchar](5000) NULL,
	[prop58] [varchar](5000) NULL,
	[prop59] [varchar](5000) NULL,
	[prop60] [varchar](5000) NULL,
	[prop61] [varchar](5000) NULL,
	[prop62] [varchar](5000) NULL,
	[prop63] [varchar](5000) NULL,
	[prop64] [varchar](5000) NULL,
	[prop65] [varchar](5000) NULL,
	[prop66] [varchar](5000) NULL,
	[prop67] [varchar](5000) NULL,
	[prop68] [varchar](5000) NULL,
	[prop69] [varchar](5000) NULL,
	[prop70] [varchar](5000) NULL,
	[prop71] [varchar](5000) NULL,
	[prop72] [varchar](5000) NULL,
	[prop73] [varchar](5000) NULL,
	[prop74] [varchar](5000) NULL,
	[prop75] [varchar](5000) NULL,
	[purchaseid] [varchar](5000) NULL,
	[quarterly_visitor] [varchar](5000) NULL,
	[ref_domain] [varchar](5000) NULL,
	[ref_type] [varchar](5000) NULL,
	[referrer] [varchar](5000) NULL,
	[resolution] [varchar](5000) NULL,
	[s_kwcid] [varchar](5000) NULL,
	[s_resolution] [varchar](5000) NULL,
	[sampled_hit] [varchar](5000) NULL,
	[search_engine] [varchar](5000) NULL,
	[search_page_num] [varchar](5000) NULL,
	[secondary_hit] [varchar](5000) NULL,
	[service] [varchar](5000) NULL,
	[socialaccountandappids] [varchar](5000) NULL,
	[socialassettrackingcode] [varchar](5000) NULL,
	[socialauthor] [varchar](5000) NULL,
	[socialaveragesentiment] [varchar](5000) NULL,
	[socialaveragesentiment_(deprecated)] [varchar](5000) NULL,
	[socialcontentprovider] [varchar](5000) NULL,
	[socialfbstories] [varchar](5000) NULL,
	[socialfbstorytellers] [varchar](5000) NULL,
	[socialinteractioncount] [varchar](5000) NULL,
	[socialinteractiontype] [varchar](5000) NULL,
	[sociallanguage] [varchar](5000) NULL,
	[sociallatlong] [varchar](5000) NULL,
	[sociallikeadds] [varchar](5000) NULL,
	[sociallink] [varchar](5000) NULL,
	[sociallink_(deprecated)] [varchar](5000) NULL,
	[socialmentions] [varchar](5000) NULL,
	[socialowneddefinitioninsighttype] [varchar](5000) NULL,
	[socialowneddefinitioninsightvalue] [varchar](5000) NULL,
	[socialowneddefinitionmetric] [varchar](5000) NULL,
	[socialowneddefinitionpropertyvspost] [varchar](5000) NULL,
	[socialownedpostids] [varchar](5000) NULL,
	[socialownedpropertyid] [varchar](5000) NULL,
	[socialownedpropertyname] [varchar](5000) NULL,
	[socialownedpropertypropertyvsapp] [varchar](5000) NULL,
	[socialpageviews] [varchar](5000) NULL,
	[socialpostviews] [varchar](5000) NULL,
	[socialproperty] [varchar](5000) NULL,
	[socialproperty_(deprecated)] [varchar](5000) NULL,
	[socialpubcomments] [varchar](5000) NULL,
	[socialpubposts] [varchar](5000) NULL,
	[socialpubrecommends] [varchar](5000) NULL,
	[socialpubsubscribers] [varchar](5000) NULL,
	[socialterm] [varchar](5000) NULL,
	[socialtermslist] [varchar](5000) NULL,
	[socialtermslist_(deprecated)] [varchar](5000) NULL,
	[socialtotalsentiment] [varchar](5000) NULL,
	[sourceid] [varchar](5000) NULL,
	[state] [varchar](5000) NULL,
	[stats_server] [varchar](5000) NULL,
	[t_time_info] [varchar](5000) NULL,
	[tnt] [varchar](5000) NULL,
	[tnt_action] [varchar](5000) NULL,
	[tnt_post_vista] [varchar](5000) NULL,
	[transactionid] [varchar](5000) NULL,
	[truncated_hit] [varchar](5000) NULL,
	[ua_color] [varchar](5000) NULL,
	[ua_os] [varchar](5000) NULL,
	[ua_pixels] [varchar](5000) NULL,
	[user_agent] [varchar](5000) NULL,
	[user_hash] [varchar](5000) NULL,
	[user_server] [varchar](5000) NULL,
	[userid] [varchar](5000) NULL,
	[username] [varchar](5000) NULL,
	[va_closer_detail] [varchar](5000) NULL,
	[va_closer_id] [varchar](5000) NULL,
	[va_finder_detail] [varchar](5000) NULL,
	[va_finder_id] [varchar](5000) NULL,
	[va_instance_event] [varchar](5000) NULL,
	[va_new_engagement] [varchar](5000) NULL,
	[video] [varchar](5000) NULL,
	[videoad] [varchar](5000) NULL,
	[videoadinpod] [varchar](5000) NULL,
	[videoadlength] [varchar](5000) NULL,
	[videoadname] [varchar](5000) NULL,
	[videoadplayername] [varchar](5000) NULL,
	[videoadpod] [varchar](5000) NULL,
	[videoadvertiser] [varchar](5000) NULL,
	[videoaudioalbum] [varchar](5000) NULL,
	[videoaudioartist] [varchar](5000) NULL,
	[videoaudioauthor] [varchar](5000) NULL,
	[videoaudiolabel] [varchar](5000) NULL,
	[videoaudiopublisher] [varchar](5000) NULL,
	[videoaudiostation] [varchar](5000) NULL,
	[videoauthorized] [varchar](5000) NULL,
	[videoaverageminuteaudience] [varchar](5000) NULL,
	[videocampaign] [varchar](5000) NULL,
	[videochannel] [varchar](5000) NULL,
	[videochapter] [varchar](5000) NULL,
	[videochaptercomplete] [varchar](5000) NULL,
	[videochapterstart] [varchar](5000) NULL,
	[videochaptertime] [varchar](5000) NULL,
	[videocontenttype] [varchar](5000) NULL,
	[videodaypart] [varchar](5000) NULL,
	[videoepisode] [varchar](5000) NULL,
	[videofeedtype] [varchar](5000) NULL,
	[videogenre] [varchar](5000) NULL,
	[videolength] [varchar](5000) NULL,
	[videomvpd] [varchar](5000) NULL,
	[videoname] [varchar](5000) NULL,
	[videonetwork] [varchar](5000) NULL,
	[videopath] [varchar](5000) NULL,
	[videopause] [varchar](5000) NULL,
	[videopausecount] [varchar](5000) NULL,
	[videopausetime] [varchar](5000) NULL,
	[videoplay] [varchar](5000) NULL,
	[videoplayername] [varchar](5000) NULL,
	[videoprogress10] [varchar](5000) NULL,
	[videoprogress25] [varchar](5000) NULL,
	[videoprogress50] [varchar](5000) NULL,
	[videoprogress75] [varchar](5000) NULL,
	[videoprogress96] [varchar](5000) NULL,
	[videoqoebitrateaverage] [varchar](5000) NULL,
	[videoqoebitrateaverageevar] [varchar](5000) NULL,
	[videoqoebitratechange] [varchar](5000) NULL,
	[videoqoebitratechangecountevar] [varchar](5000) NULL,
	[videoqoebuffer] [varchar](5000) NULL,
	[videoqoebuffercountevar] [varchar](5000) NULL,
	[videoqoebuffertimeevar] [varchar](5000) NULL,
	[videoqoedropbeforestart] [varchar](5000) NULL,
	[videoqoedroppedframecountevar] [varchar](5000) NULL,
	[videoqoedroppedframes] [varchar](5000) NULL,
	[videoqoeerror] [varchar](5000) NULL,
	[videoqoeerrorcountevar] [varchar](5000) NULL,
	[videoqoeextneralerrors] [varchar](5000) NULL,
	[videoqoeplayersdkerrors] [varchar](5000) NULL,
	[videoqoetimetostartevar] [varchar](5000) NULL,
	[videoresume] [varchar](5000) NULL,
	[videoseason] [varchar](5000) NULL,
	[videosegment] [varchar](5000) NULL,
	[videoshow] [varchar](5000) NULL,
	[videoshowtype] [varchar](5000) NULL,
	[videostreamtype] [varchar](5000) NULL,
	[videototaltime] [varchar](5000) NULL,
	[videouniquetimeplayed] [varchar](5000) NULL,
	[visid_high] [varchar](5000) NULL,
	[visid_low] [varchar](5000) NULL,
	[visid_new] [varchar](5000) NULL,
	[visid_timestamp] [varchar](5000) NULL,
	[visid_type] [varchar](5000) NULL,
	[visit_keywords] [varchar](5000) NULL,
	[visit_num] [varchar](5000) NULL,
	[visit_page_num] [varchar](5000) NULL,
	[visit_ref_domain] [varchar](5000) NULL,
	[visit_ref_type] [varchar](5000) NULL,
	[visit_referrer] [varchar](5000) NULL,
	[visit_search_engine] [varchar](5000) NULL,
	[visit_start_page_url] [varchar](5000) NULL,
	[visit_start_pagename] [varchar](5000) NULL,
	[visit_start_time_gmt] [varchar](5000) NULL,
	[weekly_visitor] [varchar](5000) NULL,
	[yearly_visitor] [varchar](5000) NULL,
	[zip] [varchar](5000) NULL,
	[event_list] [varchar](5000) NULL,
	[FILENAME] [varchar](5000) NULL,
	[SEQ] [varchar](5000) NULL,
	[FILEDATE] [varchar](5000) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ITEM_MASTER_LTD]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[ITEM_MASTER_LTD](
	[ITMNO] [varchar](50) NOT NULL,
	[COLORNO] [varchar](20) NULL,
	[COLOR] [varchar](50) NULL,
	[SIZENO] [varchar](20) NULL,
	[SIZE] [varchar](50) NULL,
	[DEPARTMENTNO] [varchar](20) NULL,
	[DEPARTMENT] [varchar](250) NULL,
	[CLASSNO] [varchar](20) NULL,
	[CLASS] [varchar](250) NULL,
	[COST] [varchar](20) NULL,
	[PRICE] [varchar](20) NULL,
	[DESCRIPTION] [varchar](250) NULL,
	[CHANGEDATE] [varchar](50) NULL,
	[FILENAME] [varchar](100) NULL,
	[SEQ] [varchar](100) NULL,
	[FILEDATE] [varchar](100) NULL,
	[INSERTDATE] [varchar](100) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ITEM_MASTER_RAW]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[ITEM_MASTER_RAW](
	[ITMNO] [varchar](50) NOT NULL,
	[COLORNO] [varchar](20) NULL,
	[COLOR] [varchar](50) NULL,
	[SIZENO] [varchar](20) NULL,
	[SIZE] [varchar](50) NULL,
	[DEPARTMENTNO] [varchar](20) NULL,
	[DEPARTMENT] [varchar](250) NULL,
	[CLASSNO] [varchar](20) NULL,
	[CLASS] [varchar](250) NULL,
	[COST] [varchar](20) NULL,
	[PRICE] [varchar](20) NULL,
	[DESCRIPTION] [varchar](250) NULL,
	[CHANGEDATE] [varchar](50) NULL,
	[FILENAME] [varchar](100) NULL,
	[SEQ] [varchar](100) NULL,
	[FILEDATE] [varchar](100) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[JOB_AUDIT_LOG]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[JOB_AUDIT_LOG](
	[JOB_AUDIT_ID] [int] IDENTITY(1,1) NOT NULL,
	[RUN_ID] [varchar](50) NULL,
	[RUN_DATE] [datetime] NULL,
	[JOBNAME] [varchar](50) NULL,
	[START_TIME] [datetime] NULL,
	[END_TIME] [datetime] NULL,
	[DURATION] [varchar](50) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[JOB_AUDIT_LOG1]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[JOB_AUDIT_LOG1](
	[run_id] [varchar](50) NULL,
	[run_date] [datetime] NULL,
	[jobname] [varchar](50) NULL,
	[start_time] [datetime] NULL,
	[end_time] [datetime] NULL,
	[duration] [bigint] NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[JOB_DURATION]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[JOB_DURATION](
	[jobname] [varchar](50) NULL,
	[start_time] [datetime] NULL,
	[end_time] [datetime] NULL,
	[duration] [varchar](50) NULL,
	[run_id] [varchar](50) NULL,
	[run_date] [datetime] NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MATCHED]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[MATCHED](
	[ROWNUM] [int] NULL,
	[DELETION_KEY] [varchar](50) NULL,
	[DELETION_REQUEST_ID] [varchar](50) NULL,
	[DELETION_TABLE] [varchar](50) NULL,
	[DELETION_COLUMN] [varchar](50) NULL,
	[DELETION_REQUEST_STEP] [varchar](50) NULL,
	[DELETION_VALUE] [varchar](50) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PRODUCT_MASTER_LTD]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[PRODUCT_MASTER_LTD](
	[SKU_NUMBER] [varchar](150) NULL,
	[DIVISION] [varchar](150) NULL,
	[DIV_DESC] [varchar](150) NULL,
	[DEPT_NUM] [varchar](150) NULL,
	[DEPT_DESC] [varchar](150) NULL,
	[CLASS] [varchar](150) NULL,
	[CLASS_DESC] [varchar](150) NULL,
	[ITEM_NUMBER] [varchar](150) NULL,
	[SKU_COLOR] [varchar](150) NULL,
	[SKU_COLOR_NUM_DESC] [varchar](150) NULL,
	[CAT_COLOR] [varchar](150) NULL,
	[CAT_COLOR_NUM_DESC] [varchar](150) NULL,
	[SKU_SIZE] [varchar](150) NULL,
	[SKU_SIZE_DESC] [varchar](150) NULL,
	[CAT_SIZE] [varchar](150) NULL,
	[ALPHA_SIZE] [varchar](150) NULL,
	[MERCH_SEASON] [varchar](150) NULL,
	[MERCH_SEASON_DESC] [varchar](150) NULL,
	[SUPER_SEASON] [varchar](150) NULL,
	[SUPER_SEASON_DESC] [varchar](150) NULL,
	[STYLE_NUMBER] [varchar](150) NULL,
	[STYLE_DESC] [varchar](150) NULL,
	[ITEM_CONCEPT] [varchar](150) NULL,
	[ITEM_CONCEPT_DESC] [varchar](150) NULL,
	[ITEM_TYPE] [varchar](150) NULL,
	[ITEM_TYPE_DESC] [varchar](150) NULL,
	[SKU_GROUP] [varchar](150) NULL,
	[SKU_GROUP_DESC] [varchar](150) NULL,
	[ITEM_SKU_NLA_CODE] [varchar](150) NULL,
	[ITEM_SKU_NLA_CODE_DESC] [varchar](150) NULL,
	[FIRST_COST] [varchar](150) NULL,
	[LANDED_COST] [varchar](150) NULL,
	[COST_DEFAULT_FLAG] [varchar](150) NULL,
	[MASTER_ITEM_NUM] [varchar](150) NULL,
	[MARKDOWN_FLAG] [varchar](150) NULL,
	[ITEM_FABRIC] [varchar](150) NULL,
	[ITEM_FABRIC_DESC] [varchar](150) NULL,
	[ITEM_LONG] [varchar](150) NULL,
	[ITEM_LONG_DESC] [varchar](150) NULL,
	[ITEM_SILHOUETTE] [varchar](150) NULL,
	[ITEM_SILHOUETTE_DESC] [varchar](150) NULL,
	[FILENAME] [varchar](150) NULL,
	[SEQ] [varchar](150) NULL,
	[FILEDATE] [varchar](150) NULL,
	[INSERTDATE] [varchar](150) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PRODUCT_MASTER_RAW]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[PRODUCT_MASTER_RAW](
	[SKU_NUMBER] [varchar](150) NULL,
	[DIVISION] [varchar](150) NULL,
	[DIV_DESC] [varchar](150) NULL,
	[DEPT_NUM] [varchar](150) NULL,
	[DEPT_DESC] [varchar](150) NULL,
	[CLASS] [varchar](150) NULL,
	[CLASS_DESC] [varchar](150) NULL,
	[ITEM_NUMBER] [varchar](150) NULL,
	[SKU_COLOR] [varchar](150) NULL,
	[SKU_COLOR_NUM_DESC] [varchar](150) NULL,
	[CAT_COLOR] [varchar](150) NULL,
	[CAT_COLOR_NUM_DESC] [varchar](150) NULL,
	[SKU_SIZE] [varchar](150) NULL,
	[SKU_SIZE_DESC] [varchar](150) NULL,
	[CAT_SIZE] [varchar](150) NULL,
	[ALPHA_SIZE] [varchar](150) NULL,
	[MERCH_SEASON] [varchar](150) NULL,
	[MERCH_SEASON_DESC] [varchar](150) NULL,
	[SUPER_SEASON] [varchar](150) NULL,
	[SUPER_SEASON_DESC] [varchar](150) NULL,
	[STYLE_NUMBER] [varchar](150) NULL,
	[STYLE_DESC] [varchar](150) NULL,
	[ITEM_CONCEPT] [varchar](150) NULL,
	[ITEM_CONCEPT_DESC] [varchar](150) NULL,
	[ITEM_TYPE] [varchar](150) NULL,
	[ITEM_TYPE_DESC] [varchar](150) NULL,
	[SKU_GROUP] [varchar](150) NULL,
	[SKU_GROUP_DESC] [varchar](150) NULL,
	[ITEM_SKU_NLA_CODE] [varchar](150) NULL,
	[ITEM_SKU_NLA_CODE_DESC] [varchar](150) NULL,
	[FIRST_COST] [varchar](150) NULL,
	[LANDED_COST] [varchar](150) NULL,
	[COST_DEFAULT_FLAG] [varchar](150) NULL,
	[MASTER_ITEM_NUM] [varchar](150) NULL,
	[MARKDOWN_FLAG] [varchar](150) NULL,
	[ITEM_FABRIC] [varchar](150) NULL,
	[ITEM_FABRIC_DESC] [varchar](150) NULL,
	[ITEM_LONG] [varchar](150) NULL,
	[ITEM_LONG_DESC] [varchar](150) NULL,
	[ITEM_SILHOUETTE] [varchar](150) NULL,
	[ITEM_SILHOUETTE_DESC] [varchar](150) NULL,
	[FILENAME] [varchar](150) NULL,
	[SEQ] [varchar](150) NULL,
	[FILEDATE] [varchar](150) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PROMO_DAILY]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[PROMO_DAILY](
	[ACCTNO] [varchar](50) NULL,
	[FNAME] [varchar](250) NULL,
	[LNAME] [varchar](250) NULL,
	[COMPANY] [varchar](250) NULL,
	[TITLE] [varchar](250) NULL,
	[ADD1] [varchar](250) NULL,
	[ADD2] [varchar](250) NULL,
	[CITY] [varchar](250) NULL,
	[STATE] [varchar](250) NULL,
	[ZIP] [varchar](25) NULL,
	[EMAIL] [varchar](250) NULL,
	[PHONE] [varchar](25) NULL,
	[DNMFLAG] [varchar](1) NOT NULL,
	[DNRFLAG] [varchar](1) NOT NULL,
	[DNCFLAG] [varchar](1) NOT NULL,
	[DNEFLAG] [varchar](1) NOT NULL,
	[MAILABLE] [varchar](1) NOT NULL,
	[EMAILFLAG] [varchar](1) NOT NULL,
	[BDAY] [varchar](25) NULL,
	[MAILDATE] [varchar](50) NULL,
	[INHOME] [varchar](50) NULL,
	[CIRCNAME] [nvarchar](4000) NOT NULL,
	[CIRCDESC] [nvarchar](4000) NOT NULL,
	[PROMTYPE] [varchar](3) NOT NULL,
	[MAILKEY] [nvarchar](4000) NOT NULL,
	[MKEYDESC] [varchar](1) NOT NULL,
	[DEMO] [varchar](15) NOT NULL,
	[LDATE] [varchar](50) NULL,
	[FREQ] [varchar](10) NULL,
	[TDOL] [varchar](10) NULL,
	[ADOL] [varchar](10) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PROMO_LTD]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[PROMO_LTD](
	[FNAME] [varchar](150) NULL,
	[LNAME] [varchar](150) NULL,
	[ADD1] [varchar](150) NULL,
	[ADD2] [varchar](150) NULL,
	[CITY] [varchar](150) NULL,
	[STATE] [varchar](150) NULL,
	[ZIP] [varchar](150) NULL,
	[PLUS4] [varchar](150) NULL,
	[COMPANY] [varchar](150) NULL,
	[PRINUM] [varchar](150) NULL,
	[STREET] [varchar](150) NULL,
	[UNITNUM] [varchar](150) NULL,
	[FNAMEKEY] [varchar](150) NULL,
	[LNAMEKEY] [varchar](150) NULL,
	[COMPKEY] [varchar](150) NULL,
	[STREETKEY] [varchar](150) NULL,
	[EMAIL] [varchar](150) NULL,
	[PHONE] [varchar](150) NULL,
	[PIN] [varchar](150) NULL,
	[INDID] [varchar](150) NULL,
	[HHID] [varchar](150) NULL,
	[ADDID] [varchar](150) NULL,
	[COMPID] [varchar](150) NULL,
	[PINSOURCE] [varchar](150) NULL,
	[PINSEQ] [varchar](150) NULL,
	[ACCTNO] [varchar](150) NULL,
	[TITLE] [varchar](150) NULL,
	[DNMFLAG] [varchar](150) NULL,
	[DNRFLAG] [varchar](150) NULL,
	[DNCFLAG] [varchar](150) NULL,
	[DNEFLAG] [varchar](150) NULL,
	[MAILABLE] [varchar](150) NULL,
	[EMAILFLAG] [varchar](150) NULL,
	[BDAY] [varchar](150) NULL,
	[MAILDATE] [varchar](150) NULL,
	[INHOME] [varchar](150) NULL,
	[CIRCNAME] [varchar](150) NULL,
	[CIRCDESC] [varchar](150) NULL,
	[PROMTYPE] [varchar](150) NULL,
	[MAILKEY] [varchar](150) NULL,
	[MKEYDESC] [varchar](150) NULL,
	[DEMO] [varchar](150) NULL,
	[LDATE] [varchar](150) NULL,
	[FREQ] [varchar](150) NULL,
	[TDOL] [varchar](150) NULL,
	[ADOL] [varchar](150) NULL,
	[FILENAME] [varchar](150) NULL,
	[SEQ] [varchar](150) NULL,
	[FILEDATE] [varchar](150) NULL,
	[PRENAME] [varchar](150) NULL,
	[MNAME] [varchar](150) NULL,
	[FULLNAME] [varchar](150) NULL,
	[SUFNAME] [varchar](150) NULL,
	[GENDER] [varchar](150) NULL,
	[ADD3] [varchar](150) NULL,
	[DOMAIN] [varchar](150) NULL,
	[CVTDATE] [varchar](150) NULL,
	[ADSUFFIX] [varchar](150) NULL,
	[ADDTYPE] [varchar](150) NULL,
	[CRRT] [varchar](150) NULL,
	[CASSCODE] [varchar](150) NULL,
	[CKDIGIT] [varchar](150) NULL,
	[CNTRYCODE] [varchar](150) NULL,
	[CNTYCODE] [varchar](150) NULL,
	[CNTYNAME] [varchar](150) NULL,
	[DELPT] [varchar](150) NULL,
	[DPV] [varchar](150) NULL,
	[DPVFTNOTE] [varchar](150) NULL,
	[DPV_VACANT] [varchar](150) NULL,
	[LACSINDC] [varchar](150) NULL,
	[LOT] [varchar](150) NULL,
	[LOTORDER] [varchar](150) NULL,
	[DPVNOSTAT] [varchar](150) NULL,
	[POSDIR] [varchar](150) NULL,
	[PREDIR] [varchar](150) NULL,
	[UNITTYPE] [varchar](150) NULL,
	[INSERTDATE] [varchar](50) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PROMO_RAW]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[PROMO_RAW](
	[FNAME] [varchar](150) NULL,
	[LNAME] [varchar](150) NULL,
	[ADD1] [varchar](150) NULL,
	[ADD2] [varchar](150) NULL,
	[CITY] [varchar](150) NULL,
	[STATE] [varchar](150) NULL,
	[ZIP] [varchar](150) NULL,
	[PLUS4] [varchar](150) NULL,
	[COMPANY] [varchar](150) NULL,
	[PRINUM] [varchar](150) NULL,
	[STREET] [varchar](150) NULL,
	[UNITNUM] [varchar](150) NULL,
	[FNAMEKEY] [varchar](150) NULL,
	[LNAMEKEY] [varchar](150) NULL,
	[COMPKEY] [varchar](150) NULL,
	[STREETKEY] [varchar](150) NULL,
	[EMAIL] [varchar](150) NULL,
	[PHONE] [varchar](150) NULL,
	[PIN] [varchar](150) NULL,
	[INDID] [varchar](150) NULL,
	[HHID] [varchar](150) NULL,
	[ADDID] [varchar](150) NULL,
	[COMPID] [varchar](150) NULL,
	[PINSOURCE] [varchar](150) NULL,
	[PINSEQ] [varchar](150) NULL,
	[ACCTNO] [varchar](150) NULL,
	[TITLE] [varchar](150) NULL,
	[DNMFLAG] [varchar](150) NULL,
	[DNRFLAG] [varchar](150) NULL,
	[DNCFLAG] [varchar](150) NULL,
	[DNEFLAG] [varchar](150) NULL,
	[MAILABLE] [varchar](150) NULL,
	[EMAILFLAG] [varchar](150) NULL,
	[BDAY] [varchar](150) NULL,
	[MAILDATE] [varchar](150) NULL,
	[INHOME] [varchar](150) NULL,
	[CIRCNAME] [varchar](150) NULL,
	[CIRCDESC] [varchar](150) NULL,
	[PROMTYPE] [varchar](150) NULL,
	[MAILKEY] [varchar](150) NULL,
	[MKEYDESC] [varchar](150) NULL,
	[DEMO] [varchar](150) NULL,
	[LDATE] [varchar](150) NULL,
	[FREQ] [varchar](150) NULL,
	[TDOL] [varchar](150) NULL,
	[ADOL] [varchar](150) NULL,
	[FILENAME] [varchar](150) NULL,
	[SEQ] [varchar](150) NULL,
	[FILEDATE] [varchar](150) NULL,
	[PRENAME] [varchar](150) NULL,
	[MNAME] [varchar](150) NULL,
	[FULLNAME] [varchar](150) NULL,
	[SUFNAME] [varchar](150) NULL,
	[GENDER] [varchar](150) NULL,
	[ADD3] [varchar](150) NULL,
	[DOMAIN] [varchar](150) NULL,
	[CVTDATE] [varchar](150) NULL,
	[ADSUFFIX] [varchar](150) NULL,
	[ADDTYPE] [varchar](150) NULL,
	[CRRT] [varchar](150) NULL,
	[CASSCODE] [varchar](150) NULL,
	[CKDIGIT] [varchar](150) NULL,
	[CNTRYCODE] [varchar](150) NULL,
	[CNTYCODE] [varchar](150) NULL,
	[CNTYNAME] [varchar](150) NULL,
	[DELPT] [varchar](150) NULL,
	[DPV] [varchar](150) NULL,
	[DPVFTNOTE] [varchar](150) NULL,
	[DPV_VACANT] [varchar](150) NULL,
	[LACSINDC] [varchar](150) NULL,
	[LOT] [varchar](150) NULL,
	[LOTORDER] [varchar](150) NULL,
	[DPVNOSTAT] [varchar](150) NULL,
	[POSDIR] [varchar](150) NULL,
	[PREDIR] [varchar](150) NULL,
	[UNITTYPE] [varchar](150) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[REQUESTORS_DAILY]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[REQUESTORS_DAILY](
	[FNAME] [varchar](250) NULL,
	[LNAME] [varchar](250) NULL,
	[ADD1] [varchar](250) NULL,
	[ADD2] [varchar](250) NULL,
	[CITY] [varchar](250) NULL,
	[STATE] [varchar](250) NULL,
	[ZIP] [varchar](250) NULL,
	[INTDATE] [varchar](50) NULL,
	[INTTYPE] [varchar](9) NOT NULL,
	[EMAIL] [varchar](250) NULL,
	[PHONE] [varchar](250) NULL,
	[ACCTNO] [varchar](1) NOT NULL,
	[IPADDRESS] [varchar](1) NOT NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[REQUESTORS_LTD]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[REQUESTORS_LTD](
	[FNAME] [varchar](250) NULL,
	[LNAME] [varchar](250) NULL,
	[ADD1] [varchar](250) NULL,
	[ADD2] [varchar](250) NULL,
	[CITY] [varchar](250) NULL,
	[STATE] [varchar](250) NULL,
	[ZIP] [varchar](25) NULL,
	[PLUS4] [varchar](250) NULL,
	[COMPANY] [varchar](250) NULL,
	[PRINUM] [varchar](250) NULL,
	[STREET] [varchar](250) NULL,
	[UNITNUM] [varchar](250) NULL,
	[FNAMEKEY] [varchar](250) NULL,
	[LNAMEKEY] [varchar](250) NULL,
	[COMPKEY] [varchar](250) NULL,
	[STREETKEY] [varchar](250) NULL,
	[EMAIL] [varchar](250) NULL,
	[PHONE] [varchar](25) NULL,
	[PIN] [varchar](250) NULL,
	[INDID] [varchar](16) NULL,
	[HHID] [varchar](16) NULL,
	[ADDID] [varchar](16) NULL,
	[COMPID] [varchar](16) NULL,
	[PINSOURCE] [varchar](16) NULL,
	[PINSEQ] [varchar](15) NULL,
	[INTDATE] [varchar](30) NULL,
	[INTTYPE] [varchar](250) NULL,
	[ACCTNO] [varchar](50) NULL,
	[IPADDRESS] [varchar](250) NULL,
	[FILENAME] [varchar](250) NULL,
	[SEQ] [varchar](250) NULL,
	[FILEDATE] [varchar](30) NULL,
	[PRENAME] [varchar](250) NULL,
	[MNAME] [varchar](250) NULL,
	[FULLNAME] [varchar](250) NULL,
	[SUFNAME] [varchar](250) NULL,
	[TITLE] [varchar](250) NULL,
	[GENDER] [varchar](250) NULL,
	[ADD3] [varchar](250) NULL,
	[DOMAIN] [varchar](250) NULL,
	[CVTDATE] [varchar](250) NULL,
	[ADSUFFIX] [varchar](250) NULL,
	[ADDTYPE] [varchar](250) NULL,
	[CRRT] [varchar](250) NULL,
	[CASSCODE] [varchar](250) NULL,
	[CKDIGIT] [varchar](250) NULL,
	[CNTRYCODE] [varchar](250) NULL,
	[CNTYCODE] [varchar](250) NULL,
	[CNTYNAME] [varchar](250) NULL,
	[DELPT] [varchar](250) NULL,
	[DPV] [varchar](250) NULL,
	[DPVFTNOTE] [varchar](250) NULL,
	[DPV_VACANT] [varchar](250) NULL,
	[LACSINDC] [varchar](250) NULL,
	[LOT] [varchar](250) NULL,
	[LOTORDER] [varchar](250) NULL,
	[DPVNOSTAT] [varchar](250) NULL,
	[POSDIR] [varchar](250) NULL,
	[PREDIR] [varchar](250) NULL,
	[UNITTYPE] [varchar](250) NULL,
	[INSERTDATE] [varchar](50) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[REQUESTORS_RAW]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[REQUESTORS_RAW](
	[FNAME] [varchar](250) NULL,
	[LNAME] [varchar](250) NULL,
	[ADD1] [varchar](250) NULL,
	[ADD2] [varchar](250) NULL,
	[CITY] [varchar](250) NULL,
	[STATE] [varchar](250) NULL,
	[ZIP] [varchar](25) NULL,
	[PLUS4] [varchar](250) NULL,
	[COMPANY] [varchar](250) NULL,
	[PRINUM] [varchar](250) NULL,
	[STREET] [varchar](250) NULL,
	[UNITNUM] [varchar](250) NULL,
	[FNAMEKEY] [varchar](250) NULL,
	[LNAMEKEY] [varchar](250) NULL,
	[COMPKEY] [varchar](250) NULL,
	[STREETKEY] [varchar](250) NULL,
	[EMAIL] [varchar](250) NULL,
	[PHONE] [varchar](25) NULL,
	[PIN] [varchar](250) NULL,
	[INDID] [varchar](16) NULL,
	[HHID] [varchar](16) NULL,
	[ADDID] [varchar](16) NULL,
	[COMPID] [varchar](16) NULL,
	[PINSOURCE] [varchar](16) NULL,
	[PINSEQ] [varchar](15) NULL,
	[INTDATE] [varchar](30) NULL,
	[INTTYPE] [varchar](250) NULL,
	[ACCTNO] [varchar](50) NULL,
	[IPADDRESS] [varchar](250) NULL,
	[FILENAME] [varchar](250) NULL,
	[SEQ] [varchar](250) NULL,
	[FILEDATE] [varchar](30) NULL,
	[PRENAME] [varchar](250) NULL,
	[MNAME] [varchar](250) NULL,
	[FULLNAME] [varchar](250) NULL,
	[SUFNAME] [varchar](250) NULL,
	[TITLE] [varchar](250) NULL,
	[GENDER] [varchar](250) NULL,
	[ADD3] [varchar](250) NULL,
	[DOMAIN] [varchar](250) NULL,
	[CVTDATE] [varchar](250) NULL,
	[ADSUFFIX] [varchar](250) NULL,
	[ADDTYPE] [varchar](250) NULL,
	[CRRT] [varchar](250) NULL,
	[CASSCODE] [varchar](250) NULL,
	[CKDIGIT] [varchar](250) NULL,
	[CNTRYCODE] [varchar](250) NULL,
	[CNTYCODE] [varchar](250) NULL,
	[CNTYNAME] [varchar](250) NULL,
	[DELPT] [varchar](250) NULL,
	[DPV] [varchar](250) NULL,
	[DPVFTNOTE] [varchar](250) NULL,
	[DPV_VACANT] [varchar](250) NULL,
	[LACSINDC] [varchar](250) NULL,
	[LOT] [varchar](250) NULL,
	[LOTORDER] [varchar](250) NULL,
	[DPVNOSTAT] [varchar](250) NULL,
	[POSDIR] [varchar](250) NULL,
	[PREDIR] [varchar](250) NULL,
	[UNITTYPE] [varchar](250) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RETAIL_ITEMS_DAILY]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[RETAIL_ITEMS_DAILY](
	[ACCTNO] [varchar](150) NULL,
	[ITMORDNO] [varchar](64) NOT NULL,
	[ITMDATE] [varchar](50) NULL,
	[LINENUM] [varchar](150) NULL,
	[ITMNO] [varchar](150) NULL,
	[ITMQTY] [varchar](20) NULL,
	[ITMPRICE] [varchar](20) NULL,
	[ITMSOURCE] [varchar](150) NULL,
	[ITMDESC] [varchar](250) NULL,
	[ITMSTATUS] [varchar](250) NULL,
	[ITMCOST] [varchar](20) NULL,
	[ITMCANCEL] [varchar](20) NULL,
	[ITMRETURN] [varchar](20) NULL,
	[ITMRTNDATE] [varchar](20) NULL,
	[ITMDISCNT] [varchar](20) NULL,
	[ITMTAX] [varchar](20) NULL,
	[RETREASON] [varchar](150) NULL,
	[ITMCOUPON] [varchar](250) NULL,
	[ISTORENO] [varchar](250) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RETAIL_ITEMS_LTD]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[RETAIL_ITEMS_LTD](
	[ACCTNO] [varchar](150) NULL,
	[ITMORDNO] [varchar](150) NULL,
	[LINENUM] [bigint] NULL,
	[ITMNO] [varchar](150) NULL,
	[ITMDATE] [varchar](50) NULL,
	[ITMQTY] [varchar](150) NULL,
	[ITMPRICE] [varchar](150) NULL,
	[ITMSOURCE] [varchar](150) NULL,
	[ITMDESC] [varchar](150) NULL,
	[ITMSTATUS] [varchar](150) NULL,
	[ITMCOST] [varchar](150) NULL,
	[ITMCANCEL] [varchar](150) NULL,
	[ITMRETURN] [varchar](150) NULL,
	[ITMRTNDATE] [varchar](150) NULL,
	[ITMDISCNT] [varchar](150) NULL,
	[ITMTAX] [varchar](150) NULL,
	[RETREASON] [varchar](150) NULL,
	[ITMCOUPON] [varchar](150) NULL,
	[ISTORENO] [varchar](150) NULL,
	[FILENAME] [varchar](150) NULL,
	[SEQ] [varchar](150) NULL,
	[FILEDATE] [varchar](150) NULL,
	[INSERTDATE] [varchar](50) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RETAIL_ITEMS_RAW]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[RETAIL_ITEMS_RAW](
	[ACCTNO] [varchar](150) NULL,
	[ITMORDNO] [varchar](150) NULL,
	[LINENUM] [varchar](150) NULL,
	[ITMNO] [varchar](150) NULL,
	[ITMDATE] [varchar](50) NULL,
	[ITMQTY] [varchar](150) NULL,
	[ITMPRICE] [varchar](150) NULL,
	[ITMSOURCE] [varchar](150) NULL,
	[ITMDESC] [varchar](150) NULL,
	[ITMSTATUS] [varchar](150) NULL,
	[ITMCOST] [varchar](150) NULL,
	[ITMCANCEL] [varchar](150) NULL,
	[ITMRETURN] [varchar](150) NULL,
	[ITMRTNDATE] [varchar](150) NULL,
	[ITMDISCNT] [varchar](150) NULL,
	[ITMTAX] [varchar](150) NULL,
	[RETREASON] [varchar](150) NULL,
	[ITMCOUPON] [varchar](150) NULL,
	[ISTORENO] [varchar](150) NULL,
	[FILENAME] [varchar](150) NULL,
	[SEQ] [varchar](150) NULL,
	[FILEDATE] [varchar](150) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RETAIL_ORDERS_DAILY]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[RETAIL_ORDERS_DAILY](
	[ACCTNO] [varchar](150) NULL,
	[ORDNO] [varchar](64) NOT NULL,
	[ORDDATE] [varchar](50) NULL,
	[ORDTDOL] [varchar](20) NULL,
	[ORDCHANNEL] [varchar](250) NULL,
	[EMAIL] [varchar](250) NULL,
	[PHONE] [varchar](25) NULL,
	[ORDITEMQTY] [varchar](20) NULL,
	[ORDSOURCE] [varchar](150) NULL,
	[ORDCOGS] [varchar](20) NULL,
	[ORDCANCEL] [varchar](20) NULL,
	[ORDRETURN] [varchar](20) NULL,
	[ORDDISCNT] [varchar](20) NULL,
	[ORDPOSTAGE] [varchar](20) NULL,
	[TAXAMT] [varchar](20) NULL,
	[STORENO] [varchar](150) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RETAIL_ORDERS_LTD]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[RETAIL_ORDERS_LTD](
	[ACCTNO] [varchar](50) NULL,
	[ORDNO] [varchar](250) NULL,
	[ORDDATE] [varchar](50) NULL,
	[ORDTDOL] [varchar](30) NULL,
	[ORDCHANNEL] [varchar](250) NULL,
	[EMAIL] [varchar](250) NULL,
	[PHONE] [varchar](25) NULL,
	[ORDITEMQTY] [varchar](30) NULL,
	[ORDSOURCE] [varchar](250) NULL,
	[ORDCOGS] [varchar](30) NULL,
	[ORDCANCEL] [varchar](30) NULL,
	[ORDRETURN] [varchar](30) NULL,
	[ORDDISCNT] [varchar](30) NULL,
	[ORDPOSTAGE] [varchar](30) NULL,
	[TAXAMT] [varchar](30) NULL,
	[STORENO] [varchar](250) NULL,
	[FILENAME] [varchar](150) NULL,
	[SEQ] [varchar](150) NULL,
	[FILEDATE] [varchar](8) NOT NULL,
	[INSERTDATE] [varchar](50) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RETAIL_ORDERS_RAW]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[RETAIL_ORDERS_RAW](
	[ACCTNO] [varchar](50) NULL,
	[ORDNO] [varchar](250) NULL,
	[ORDDATE] [varchar](50) NULL,
	[ORDTDOL] [varchar](30) NULL,
	[ORDCHANNEL] [varchar](250) NULL,
	[EMAIL] [varchar](250) NULL,
	[PHONE] [varchar](25) NULL,
	[ORDITEMQTY] [varchar](30) NULL,
	[ORDSOURCE] [varchar](250) NULL,
	[ORDCOGS] [varchar](30) NULL,
	[ORDCANCEL] [varchar](30) NULL,
	[ORDRETURN] [varchar](30) NULL,
	[ORDDISCNT] [varchar](30) NULL,
	[ORDPOSTAGE] [varchar](30) NULL,
	[TAXAMT] [varchar](30) NULL,
	[STORENO] [varchar](250) NULL,
	[FILENAME] [varchar](150) NULL,
	[SEQ] [varchar](150) NULL,
	[FILEDATE] [varchar](150) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[STORE_MASTER_LTD]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[STORE_MASTER_LTD](
	[FNAME] [varchar](100) NULL,
	[LNAME] [varchar](100) NULL,
	[ADD1] [varchar](250) NULL,
	[ADD2] [varchar](250) NULL,
	[CITY] [varchar](250) NULL,
	[STATE] [varchar](50) NULL,
	[ZIP] [varchar](25) NULL,
	[PLUS4] [varchar](4) NULL,
	[COMPANY] [varchar](100) NULL,
	[PRINUM] [varchar](5) NULL,
	[STREET] [varchar](26) NULL,
	[UNITNUM] [varchar](5) NULL,
	[FNAMEKEY] [varchar](100) NULL,
	[LNAMEKEY] [varchar](100) NULL,
	[COMPKEY] [varchar](100) NULL,
	[STREETKEY] [varchar](14) NULL,
	[EMAIL] [varchar](100) NULL,
	[PHONE] [varchar](50) NULL,
	[PIN] [varchar](29) NULL,
	[INDID] [varchar](16) NULL,
	[HHID] [varchar](16) NULL,
	[ADDID] [varchar](16) NULL,
	[COMPID] [varchar](16) NULL,
	[PINSOURCE] [varchar](1) NULL,
	[PINSEQ] [varchar](15) NULL,
	[STORENO] [varchar](50) NULL,
	[COMPANYCD] [varchar](3) NULL,
	[STORENAME] [varchar](250) NULL,
	[DISTRICTNO] [varchar](4) NULL,
	[REGIONNO] [varchar](4) NULL,
	[TERITORYNO] [varchar](4) NULL,
	[COUNTRYNO] [varchar](4) NULL,
	[STOREMAN] [varchar](9) NULL,
	[MDSSTRTYP] [varchar](2) NULL,
	[ALTLOCTYP] [varchar](2) NULL,
	[SQRFTOT] [varchar](9) NULL,
	[SQRFSELL] [varchar](9) NULL,
	[SQRFSTOCK] [varchar](9) NULL,
	[FINSTRTYP] [varchar](2) NULL,
	[COMPDATE] [varchar](10) NULL,
	[LANGUAGECD] [varchar](5) NULL,
	[REGISTERS] [varchar](5) NULL,
	[PRENAME] [varchar](100) NULL,
	[MNAME] [varchar](100) NULL,
	[FULLNAME] [varchar](100) NULL,
	[SUFNAME] [varchar](100) NULL,
	[TITLE] [varchar](100) NULL,
	[GENDER] [varchar](1) NULL,
	[ADD3] [varchar](100) NULL,
	[DOMAIN] [varchar](100) NULL,
	[CVTDATE] [varchar](19) NULL,
	[ADSUFFIX] [varchar](4) NULL,
	[ADDTYPE] [varchar](2) NULL,
	[CRRT] [varchar](4) NULL,
	[CASSCODE] [varchar](4) NULL,
	[CKDIGIT] [varchar](1) NULL,
	[CNTRYCODE] [varchar](100) NULL,
	[CNTYCODE] [varchar](5) NULL,
	[CNTYNAME] [varchar](11) NULL,
	[DELPT] [varchar](2) NULL,
	[DPV] [varchar](1) NULL,
	[DPVFTNOTE] [varchar](4) NULL,
	[DPV_VACANT] [varchar](1) NULL,
	[LACSINDC] [varchar](100) NULL,
	[LOT] [varchar](4) NULL,
	[LOTORDER] [varchar](1) NULL,
	[DPVNOSTAT] [varchar](1) NULL,
	[POSDIR] [varchar](100) NULL,
	[PREDIR] [varchar](1) NULL,
	[UNITTYPE] [varchar](4) NULL,
	[FILENAME] [varchar](100) NULL,
	[SEQ] [varchar](100) NULL,
	[FILEDATE] [varchar](100) NULL,
	[INSERTDATE] [varchar](100) NULL
) ON [PRIMARY]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[STORE_MASTER_RAW]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[STORE_MASTER_RAW](
	[FNAME] [varchar](100) NULL,
	[LNAME] [varchar](100) NULL,
	[ADD1] [varchar](250) NULL,
	[ADD2] [varchar](250) NULL,
	[CITY] [varchar](250) NULL,
	[STATE] [varchar](50) NULL,
	[ZIP] [varchar](25) NULL,
	[PLUS4] [varchar](4) NULL,
	[COMPANY] [varchar](100) NULL,
	[PRINUM] [varchar](5) NULL,
	[STREET] [varchar](26) NULL,
	[UNITNUM] [varchar](5) NULL,
	[FNAMEKEY] [varchar](100) NULL,
	[LNAMEKEY] [varchar](100) NULL,
	[COMPKEY] [varchar](100) NULL,
	[STREETKEY] [varchar](14) NULL,
	[EMAIL] [varchar](100) NULL,
	[PHONE] [varchar](50) NULL,
	[PIN] [varchar](29) NULL,
	[INDID] [varchar](16) NULL,
	[HHID] [varchar](16) NULL,
	[ADDID] [varchar](16) NULL,
	[COMPID] [varchar](16) NULL,
	[PINSOURCE] [varchar](1) NULL,
	[PINSEQ] [varchar](15) NULL,
	[STORENO] [varchar](50) NULL,
	[COMPANYCD] [varchar](3) NULL,
	[STORENAME] [varchar](250) NULL,
	[DISTRICTNO] [varchar](4) NULL,
	[REGIONNO] [varchar](4) NULL,
	[TERITORYNO] [varchar](4) NULL,
	[COUNTRYNO] [varchar](4) NULL,
	[STOREMAN] [varchar](9) NULL,
	[MDSSTRTYP] [varchar](2) NULL,
	[ALTLOCTYP] [varchar](2) NULL,
	[SQRFTOT] [varchar](9) NULL,
	[SQRFSELL] [varchar](9) NULL,
	[SQRFSTOCK] [varchar](9) NULL,
	[FINSTRTYP] [varchar](2) NULL,
	[COMPDATE] [varchar](10) NULL,
	[LANGUAGECD] [varchar](5) NULL,
	[REGISTERS] [varchar](5) NULL,
	[PRENAME] [varchar](100) NULL,
	[MNAME] [varchar](100) NULL,
	[FULLNAME] [varchar](100) NULL,
	[SUFNAME] [varchar](100) NULL,
	[TITLE] [varchar](100) NULL,
	[GENDER] [varchar](1) NULL,
	[ADD3] [varchar](100) NULL,
	[DOMAIN] [varchar](100) NULL,
	[CVTDATE] [varchar](19) NULL,
	[ADSUFFIX] [varchar](4) NULL,
	[ADDTYPE] [varchar](2) NULL,
	[CRRT] [varchar](4) NULL,
	[CASSCODE] [varchar](4) NULL,
	[CKDIGIT] [varchar](1) NULL,
	[CNTRYCODE] [varchar](100) NULL,
	[CNTYCODE] [varchar](5) NULL,
	[CNTYNAME] [varchar](11) NULL,
	[DELPT] [varchar](2) NULL,
	[DPV] [varchar](1) NULL,
	[DPVFTNOTE] [varchar](4) NULL,
	[DPV_VACANT] [varchar](1) NULL,
	[LACSINDC] [varchar](100) NULL,
	[LOT] [varchar](4) NULL,
	[LOTORDER] [varchar](1) NULL,
	[DPVNOSTAT] [varchar](1) NULL,
	[POSDIR] [varchar](100) NULL,
	[PREDIR] [varchar](1) NULL,
	[UNITTYPE] [varchar](4) NULL,
	[FILENAME] [varchar](100) NULL,
	[SEQ] [varchar](100) NULL,
	[FILEDATE] [varchar](100) NULL
) ON [PRIMARY]
END
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[DIRECT_ITEMS_LTD]') AND name = N'IX_NCI_ITMNO')
CREATE NONCLUSTERED INDEX [IX_NCI_ITMNO] ON [dbo].[DIRECT_ITEMS_LTD]
(
	[ITMNO] ASC,
	[ACCTNO] ASC,
	[ITMORDNO] ASC,
	[LINENUM] ASC,
	[SEQ] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[PROMO_LTD]') AND name = N'idxCircname')
CREATE NONCLUSTERED INDEX [idxCircname] ON [dbo].[PROMO_LTD]
(
	[CIRCNAME] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[RETAIL_ITEMS_LTD]') AND name = N'IX_NCI_ITMNO')
CREATE NONCLUSTERED INDEX [IX_NCI_ITMNO] ON [dbo].[RETAIL_ITEMS_LTD]
(
	[ACCTNO] ASC,
	[ITMORDNO] ASC,
	[LINENUM] ASC,
	[ITMNO] ASC,
	[SEQ] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF__DATA_FEED__JOB_C__6502C82F]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[DATA_FEED_CATALOG] ADD  DEFAULT ('Default') FOR [JOB_CONTEXT]
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DF__DATA_FEED__IS_MA__7BB1235D]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[DATA_FEED_MAPPING] ADD  DEFAULT ('FALSE') FOR [IS_MANDATORY]
END
GO
