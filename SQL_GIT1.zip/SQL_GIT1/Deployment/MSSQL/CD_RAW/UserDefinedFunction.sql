﻿USE [CD_RAW]
GO
DROP FUNCTION IF EXISTS [dbo].[RandomDollars]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RandomDollars]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'
CREATE FUNCTION [dbo].[RandomDollars]
(
)
RETURNS varchar(20)
AS
BEGIN
declare @rand as varchar(20)
	(select @rand = [rando] from randno)
	RETURN @rand 
END
' 
END
GO
